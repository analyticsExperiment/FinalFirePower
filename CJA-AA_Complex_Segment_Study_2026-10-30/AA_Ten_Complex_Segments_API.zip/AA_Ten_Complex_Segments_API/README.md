# Ten Adobe Analytics complex segments

Target: **Demo Data 7616** (`ngeo1xxpssincid7616`), company `eclerx3`.
Prepared and checked on 30 October 2026. No segment has been created or shared.

## Ready checks

- All ten exact payloads passed Adobe `/segments/validate` (HTTP 200, valid true).
- Inline reports accepted all ten without saving them. In 1 August to 30 October
  2026, P09 returned 2 visitors, 2 visits and 2 orders; the other nine returned zero.
  These are strict QA designs, not a promise of nonzero audiences.
- All ten names were available; the sharing search endpoint was readable.
- Eleven mock tests cover success, reruns, uncertain create/share responses,
  name collisions, invalid definitions, changed plans and transport restrictions.
- Live create/share permissions and Adobe write responses remain untested.

## Install and inspect

Python 3.10 or later. Windows Command Prompt:

```bat
py -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe migrate_segments.py plan
.venv\Scripts\python.exe migrate_segments.py validate --env-file "C:\path\to\your\.env"
.venv\Scripts\python.exe -m unittest -v test_migrate_segments.py
```

Linux: use `python3 -m venv .venv` and `.venv/bin/python` in place of
`.venv\Scripts\python.exe`.

Use your existing local AA credentials. `.env.example` contains empty credential
fields only. Do not upload the real `.env`, receipt, token or private exports.

## When migration is requested

The following command **creates the ten segments and shares them with all users
in the configured Adobe company**. It has not been executed against Adobe.

```bat
.venv\Scripts\python.exe migrate_segments.py migrate --env-file "C:\path\to\your\.env" --receipt migration_receipt.json
```

The runner validates the whole batch before any create. It records each returned
ID immediately, reads the definition back and checks its ordered rules before
sharing. It verifies an `all` share through the search endpoint. Sharing does not
grant report suite access or publish an audience to Experience Cloud.

Keep `migration_receipt.json`. Rerun with the same receipt to continue an
interrupted batch. Component POST requests are never automatically retried.
Uncertain writes are reconciled from the receipt and Adobe readback; if the
result cannot be determined, the runner stops for inspection. There is no
rollback or delete function. The receipt lock prevents concurrent local runs
using that receipt; it does not lock Adobe against another user.

Planned names and target are checksum protected. To revise a definition, review
the JSON, update `PLAN_SHA256` to the new file's SHA-256, then rerun validation and
tests. A receipt for the previous plan cannot be reused.

## API operations

Read-only preflight: `GET reportsuites/collections/suites`, `GET segments`,
`POST segments/validate` with the full segment payload and target rsid.

Migration only: `POST segments` with `name`, `rsid`, `description`, `definition`;
then `GET segments/{id}?expansion=definition`.

Sharing only after verified creation:

```json
{"componentId":"RETURNED_SEGMENT_ID","componentType":"segment","shareToType":"all"}
```

Endpoint: `POST componentmetadata/shares`. Adobe's official Swagger states that
`shareToId` is unnecessary for `all`. Readback:
`POST componentmetadata/shares/component/search`, body
`{"componentType":"segment","componentIds":["RETURNED_SEGMENT_ID"]}`.
No PUT, PATCH or DELETE method is implemented.

## Definition semantics

All ten have Visitor > Visit > Hit nesting. Visit containers in the visitor
sequence describe separate visits. Time limits attach to their specific THEN
gap. Within 10 hits is Adobe's hit restriction, not necessarily 10 page views.
No same-product, same-application or same-search-term join is assumed. Marketing
Channel is eVar1 attribution at a hit; it is not a guaranteed visit-entry source.
All visitor totals use the report's date window. Revenue thresholds use SGD.
Two different definitions can return the same audience count, especially zero;
that does not make them exact duplicates.

## Adobe references

- [Segments](https://developer.adobe.com/analytics-apis/docs/2.0/guides/endpoints/segments/)
- [API reference](https://developer.adobe.com/analytics-apis/docs/2.0/apis/)
- [Definition schema](https://developer.adobe.com/analytics-apis/docs/2.0/guides/endpoints/segments/definition)
- [Sequential containers](https://experienceleague.adobe.com/en/docs/analytics/components/segmentation/segmentation-workflow/seg-sequential-build)
- [Shares](https://developer.adobe.com/analytics-apis/docs/2.0/guides/endpoints/componentmetadata/shares)
