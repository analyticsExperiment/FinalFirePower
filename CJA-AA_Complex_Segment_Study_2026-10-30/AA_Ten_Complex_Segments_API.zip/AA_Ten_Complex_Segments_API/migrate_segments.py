"""Prepared AA complex segments. Default commands are read-only; migrate creates/shares.

No DELETE, PUT or PATCH operation is implemented. Never retries a component write.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
from urllib.parse import quote

import requests
from dotenv import dotenv_values

HOME = Path(__file__).resolve().parent
PLAN_SHA256 = '121d9c64d6d89d110bd3e89aaf4a846cfcb9d6c32202d516ef86e2d83392b384'

class MigrationError(RuntimeError):
    pass

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def logic(value):
    """Ignore display descriptions only. Preserve sequence positions and all rule values."""
    if isinstance(value, dict):
        return {k: logic(v) for k, v in value.items() if k != 'description'}
    if isinstance(value, list):
        return [logic(v) for v in value]
    return value

def load_plan(path):
    raw = Path(path).read_bytes()
    if hashlib.sha256(raw).hexdigest() != PLAN_SHA256:
        raise MigrationError('Plan changed. Review and validate it before updating the pinned checksum.')
    p = json.loads(raw)
    if len(p['segments']) != 10 or len({s['name'] for s in p['segments']}) != 10:
        raise MigrationError('Exactly ten unique planned segments are required.')
    if p['sharing'] != {'componentType': 'segment', 'shareToType': 'all'}:
        raise MigrationError('Unexpected sharing target.')
    if any(s['payload']['rsid'] != p['rsid'] or s['payload']['name'] != s['name'] for s in p['segments']):
        raise MigrationError('Segment scope or name does not match the plan.')
    return p

class API:
    def __init__(self, env_file, plan, writable=False, session=None):
        cfg = dict(dotenv_values(env_file)) if env_file else {}
        cfg.update(os.environ)
        def value(*keys):
            return next((str(cfg[k]).strip() for k in keys if cfg.get(k)), '')
        self.client_id = value('AA_CLIENT_ID', 'AA_API_KEY', 'ADOBE_CLIENT_ID')
        self.secret = value('AA_CLIENT_SECRET', 'ADOBE_CLIENT_SECRET')
        self.scopes = value('AA_SCOPES', 'ADOBE_SCOPES')
        self.token = value('AA_ACCESS_TOKEN')
        self.expires = float('inf') if self.token else 0
        self.company = value('AA_GLOBAL_COMPANY_ID') or plan['company_id']
        if self.company != plan['company_id']:
            raise MigrationError('Configured company does not match the reviewed plan.')
        if not self.client_id or not (self.token or self.secret and self.scopes):
            raise MigrationError('Configure AA client ID and token, or secret and scopes.')
        self.base = 'https://analytics.adobe.io/api/' + quote(self.company, safe='')
        self.writable = writable
        self.session = session or requests.Session()
        self.calls = []

    def headers(self):
        if self.expires <= time.time() + 90:
            try:
                r = self.session.post('https://ims-na1.adobelogin.com/ims/token/v3',
                    data={'grant_type': 'client_credentials', 'client_id': self.client_id,
                          'client_secret': self.secret, 'scope': self.scopes}, timeout=(10, 60), allow_redirects=False)
                r.raise_for_status()
                t = r.json()
                self.token = t['access_token']
                self.expires = time.time() + float(t.get('expires_in', 3600))
            except (requests.RequestException, ValueError, KeyError):
                raise MigrationError('Adobe authentication failed; credential details are hidden.') from None
        return {'Authorization': 'Bearer ' + self.token, 'x-api-key': self.client_id,
                'Accept': 'application/json', 'Content-Type': 'application/json',
                'x-proxy-global-company-id': self.company}

    def call(self, method, path, body=None, params=None):
        read_post = path in ('segments/validate', 'reports', 'componentmetadata/shares/component/search')
        write = method == 'POST' and path in ('segments', 'componentmetadata/shares')
        read_get = method == 'GET' and (path == 'segments' or path.startswith('segments/')
                    or path.startswith('reportsuites/') or path in ('metrics', 'dimensions', 'componentmetadata/shares'))
        if not (read_get or method == 'POST' and read_post or self.writable and write):
            raise MigrationError('Operation blocked by the command transport policy.')
        try:
            r = self.session.request(method, self.base + '/' + path, json=body, params=params,
                headers=self.headers(), timeout=(10, 90), allow_redirects=False)
        except requests.RequestException:
            raise MigrationError('Adobe response was lost. A write may have completed; rerun with the same receipt to reconcile. No write was retried.') from None
        self.calls.append({'method': method, 'path': path, 'status': r.status_code})
        if not 200 <= r.status_code < 300:
            raise MigrationError(f'Adobe returned HTTP {r.status_code} for {path}. No write was retried.')
        try:
            return r.json()
        except ValueError:
            raise MigrationError('Adobe returned an unreadable response; reconcile before retrying.') from None

    def names(self, name):
        out = []; seen_pages = set()
        for page in range(10000):
            d = self.call('GET', 'segments', params={'name': name, 'includeType': 'all', 'limit': 1000,
                         'page': page, 'expansion': 'definition'})
            rows = d if isinstance(d, list) else d.get('content', [])
            fingerprint = tuple(str(x.get('id')) for x in rows)
            if rows and fingerprint in seen_pages:
                raise MigrationError('Adobe repeated a segment page; name check is incomplete.')
            seen_pages.add(fingerprint)
            out.extend(x for x in rows if x.get('name') == name)
            if isinstance(d, list) or d.get('lastPage') is True or (len(rows) < 1000 and d.get('lastPage') is not False and d.get('totalPages') is None):
                return out
            if not rows:
                raise MigrationError('Adobe returned an empty non-final segment page.')
        raise MigrationError('Segment pagination did not finish.')

    def shares(self, sid):
        data = self.call('POST', 'componentmetadata/shares/component/search',
                         {'componentType': 'segment', 'componentIds': [sid]})
        # Search returns one shared-component entry per ID, containing its shares.
        rows = data if isinstance(data, list) else data.get('content', [])
        return [share for row in rows if str(row.get('componentId')) == sid for share in row.get('shares', [])]

def preflight(api, plan):
    found = False
    for page in range(10000):
        data = api.call('GET', 'reportsuites/collections/suites', params={'limit': 1000, 'page': page})
        rows = data if isinstance(data, list) else data.get('content', [])
        found = found or any(x.get('rsid') == plan['rsid'] or x.get('id') == plan['rsid'] for x in rows)
        if found or isinstance(data, list) or data.get('lastPage') is True or len(rows) < 1000:
            break
    if not found:
        raise MigrationError('Reviewed report suite is not accessible in the configured company.')
    results = []
    for s in plan['segments']:
        v = api.call('POST', 'segments/validate', s['payload'], {'rsid': plan['rsid']})
        results.append({'key': s['key'], 'valid': v.get('valid') is True})
    if not all(x['valid'] for x in results):
        raise MigrationError('At least one definition failed live validation. No segment was created.')
    return results

def save_receipt(path, state):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.tmp')
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, 'w') as f:
        json.dump(state, f, indent=2)
        f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)

def matches(row, s):
    return (row.get('name') == s['name'] and row.get('rsid') == s['payload']['rsid']
            and digest(logic(row.get('definition'))) == digest(logic(s['payload']['definition'])))

def migrate(api, plan, receipt):
    """Validate all, create sequentially, preserve IDs immediately, verify sharing."""
    if not api.writable:
        raise MigrationError('Migration requires the explicit migrate command.')
    path = Path(receipt)
    state = json.loads(path.read_text()) if path.exists() else {
        'plan_sha256': PLAN_SHA256, 'company_id': plan['company_id'], 'rsid': plan['rsid'], 'segments': {}}
    if any(state.get(k) != v for k, v in {'plan_sha256': PLAN_SHA256,
            'company_id': plan['company_id'], 'rsid': plan['rsid']}.items()):
        raise MigrationError('Receipt belongs to a different plan or target.')
    preflight(api, plan)
    candidates = {s['key']: api.names(s['name']) for s in plan['segments']}
    # Resolve every collision before any new component write.
    for s in plan['segments']:
        rec = state['segments'].get(s['key'], {})
        rows = candidates[s['key']]
        if rec.get('id'):
            row = api.call('GET', 'segments/' + quote(rec['id'], safe=''), params={'expansion': 'definition'})
            if not matches(row, s):
                raise MigrationError('Saved segment no longer matches its reviewed definition.')
        elif rows:
            if rec.get('pending_create') and len(rows) == 1 and matches(rows[0], s):
                rec.update(id=rows[0]['id'], pending_create=False)
                save_receipt(path, state)
            else:
                raise MigrationError('A planned name already exists without a matching migration receipt. Review it; nothing was overwritten.')
    save_receipt(path, state)
    for s in plan['segments']:
        rec = state['segments'].setdefault(s['key'], {})
        if not rec.get('id'):
            if rec.get('pending_create'):
                raise MigrationError('A previous create has an uncertain result. Check Adobe before clearing pending_create in the receipt.')
            rec['pending_create'] = True
            save_receipt(path, state)
            row = api.call('POST', 'segments', s['payload'])
            if not isinstance(row, dict) or not row.get('id'):
                raise MigrationError('Create did not return an ID. Receipt retained for reconciliation.')
            rec.update(id=row['id'], pending_create=False)
            save_receipt(path, state)
        sid = str(rec['id'])
        row = api.call('GET', 'segments/' + quote(sid, safe=''), params={'expansion': 'definition'})
        if not matches(row, s):
            raise MigrationError('Readback differs from the reviewed segment; sharing stopped.')
        shares = api.shares(sid)
        if not any(x.get('shareToType') == 'all' for x in shares):
            if rec.get('pending_share'):
                raise MigrationError('Previous share result is uncertain. Check Adobe before clearing pending_share in the receipt.')
            rec['pending_share'] = True
            save_receipt(path, state)
            api.call('POST', 'componentmetadata/shares', {'componentId': sid, **plan['sharing']})
            shares = api.shares(sid)
        if not any(x.get('shareToType') == 'all' for x in shares):
            raise MigrationError('Share with all users could not be verified. ID retained; no segment recreated.')
        rec.update(shared_with_all=True, pending_share=False, verified_definition_sha256=digest(logic(row['definition'])))
        save_receipt(path, state)
    return state

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=['plan', 'validate', 'migrate'])
    p.add_argument('--env-file')
    p.add_argument('--plan', default=str(HOME / 'segment_plan.json'))
    p.add_argument('--receipt', default='migration_receipt.json')
    args = p.parse_args()
    plan = load_plan(args.plan)
    if args.command == 'plan':
        print(json.dumps({'rsid': plan['rsid'], 'count': 10, 'names': [s['name'] for s in plan['segments']], 'adobe_writes': 0}, indent=2)); return
    api = API(args.env_file, plan, writable=args.command == 'migrate')
    if args.command == 'validate':
        print(json.dumps({'results': preflight(api, plan), 'component_writes': 0}, indent=2)); return
    # An exclusive local lock prevents two runs using the same receipt simultaneously.
    lock = Path(args.receipt + '.lock')
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        raise MigrationError('Migration receipt is locked. Check for another running process before removing its lock.') from None
    os.close(fd)
    try:
        result = migrate(api, plan, args.receipt)
        print(json.dumps({'created_or_resumed': len(result['segments']), 'shared_with_all': True, 'receipt': args.receipt}))
    finally:
        lock.unlink(missing_ok=True)

if __name__ == '__main__':
    try:
        main()
    except (MigrationError, OSError, ValueError, KeyError) as e:
        print('Stopped: ' + str(e), file=sys.stderr)
        sys.exit(1)
