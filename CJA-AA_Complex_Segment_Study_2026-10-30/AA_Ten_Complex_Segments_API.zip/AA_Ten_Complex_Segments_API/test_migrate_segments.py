import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import migrate_segments as m

class FakeAPI:
    writable = True
    def __init__(self):
        self.rows = {}; self.shared = set(); self.writes = []; self.invalid = False
        self.lost_create = False; self.lost_share = False; self.bad_readback = False
    def names(self, name):
        return [copy.deepcopy(x) for x in self.rows.values() if x['name'] == name]
    def shares(self, sid):
        return [{'shareToType': 'all'}] if sid in self.shared else []
    def call(self, method, path, body=None, params=None):
        if path == 'reportsuites/collections/suites':
            return {'content': [{'rsid': 'ngeo1xxpssincid7616'}], 'lastPage': True}
        if path == 'segments/validate': return {'valid': not self.invalid}
        if method == 'GET' and path.startswith('segments/'):
            row = copy.deepcopy(self.rows[path.split('/')[1]])
            if self.bad_readback: row['definition']['version'] = [9, 9, 9]
            return row
        if method == 'POST' and path == 'segments':
            self.writes.append(path)
            sid = 'test_' + str(len(self.rows)+1)
            row = {**copy.deepcopy(body), 'id': sid}; self.rows[sid] = row
            if self.lost_create:
                self.lost_create = False
                raise m.MigrationError('Simulated lost create response')
            return row
        if method == 'POST' and path == 'componentmetadata/shares':
            self.writes.append(path); self.shared.add(body['componentId'])
            if self.lost_share:
                self.lost_share = False
                raise m.MigrationError('Simulated lost share response')
            return body
        raise AssertionError((method, path))

class MigrationTests(unittest.TestCase):
    def setUp(self):
        self.plan = m.load_plan(m.HOME/'segment_plan.json')
        self.tmp = tempfile.TemporaryDirectory(); self.receipt = Path(self.tmp.name)/'receipt.json'
        self.api = FakeAPI()
    def tearDown(self): self.tmp.cleanup()
    def test_ten_created_shared_and_repeat_adds_nothing(self):
        result = m.migrate(self.api, self.plan, self.receipt)
        self.assertEqual(len(result['segments']), 10)
        self.assertEqual(len(self.api.shared), 10)
        self.assertEqual(len(self.api.writes), 20)
        m.migrate(self.api, self.plan, self.receipt)
        self.assertEqual(len(self.api.writes), 20)
    def test_invalid_preflight_makes_no_writes(self):
        self.api.invalid = True
        with self.assertRaises(m.MigrationError):m.migrate(self.api,self.plan,self.receipt)
        self.assertEqual(self.api.writes, [])
    def test_name_collision_stops_entire_batch(self):
        self.api.rows['existing'] = {**copy.deepcopy(self.plan['segments'][9]['payload']), 'id': 'existing'}
        with self.assertRaises(m.MigrationError):m.migrate(self.api,self.plan,self.receipt)
        self.assertEqual(self.api.writes, [])
    def test_lost_create_response_reconciles_without_duplicate(self):
        self.api.lost_create = True
        with self.assertRaises(m.MigrationError):m.migrate(self.api,self.plan,self.receipt)
        self.assertEqual(len(self.api.rows),1)
        m.migrate(self.api,self.plan,self.receipt)
        self.assertEqual(len(self.api.rows),10)
        self.assertEqual(self.api.writes.count('segments'),10)
    def test_lost_share_response_reconciles_without_recreation(self):
        self.api.lost_share = True
        with self.assertRaises(m.MigrationError):m.migrate(self.api,self.plan,self.receipt)
        m.migrate(self.api,self.plan,self.receipt)
        self.assertEqual(self.api.writes.count('segments'),10)
        self.assertEqual(self.api.writes.count('componentmetadata/shares'),10)
    def test_readback_mismatch_stops_before_sharing(self):
        self.api.bad_readback = True
        with self.assertRaises(m.MigrationError):m.migrate(self.api,self.plan,self.receipt)
        self.assertEqual(self.api.writes,['segments'])
    def test_wrong_receipt_target_stops(self):
        self.receipt.write_text(json.dumps({'company_id':'other'}))
        with self.assertRaises(m.MigrationError):m.migrate(self.api,self.plan,self.receipt)
        self.assertEqual(self.api.writes,[])
    def test_readonly_transport_blocks_mutations(self):
        with patch.dict('os.environ', {'AA_CLIENT_ID':'fake','AA_ACCESS_TOKEN':'fake','AA_GLOBAL_COMPANY_ID':'eclerx3'}):
            api=m.API(None,self.plan)
        for method,path in [('POST','segments'),('POST','componentmetadata/shares'),('DELETE','segments/test'),('PUT','segments/test'),('PATCH','segments/test')]:
            with self.assertRaises(m.MigrationError):api.call(method,path,{})
        self.assertEqual(api.calls,[])
    def test_altered_plan_checksum_fails(self):
        p=Path(self.tmp.name)/'plan.json';p.write_text('{}')
        with self.assertRaises(m.MigrationError):m.load_plan(p)
    def test_ordered_stream_is_preserved_in_verification(self):
        a=self.plan['segments'][0]['payload']['definition'];b=copy.deepcopy(a)
        b['container']['pred']['stream'].reverse()
        self.assertNotEqual(m.digest(m.logic(a)),m.digest(m.logic(b)))
    def test_pending_create_not_visible_stops_without_retry(self):
        state={'plan_sha256':m.PLAN_SHA256,'company_id':self.plan['company_id'],'rsid':self.plan['rsid'],
               'segments':{'P01':{'pending_create':True}}}
        m.save_receipt(self.receipt,state)
        with self.assertRaises(m.MigrationError):m.migrate(self.api,self.plan,self.receipt)
        self.assertEqual(self.api.writes,[])

if __name__=='__main__':unittest.main(verbosity=2)
