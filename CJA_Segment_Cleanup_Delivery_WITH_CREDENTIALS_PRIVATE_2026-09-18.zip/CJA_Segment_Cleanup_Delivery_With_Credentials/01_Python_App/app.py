"""
CJA Segment Finder - desktop browser application.

The Flask layer keeps Adobe credentials on the server, presents the same
data-view-first workflow as the standalone V5 HTML application, and delegates
all comparison, grouping, usage, recommendation, and export work to
cja_segment_finder.py.
"""

import logging
import os
import threading
import time
import webbrowser
from html import escape

from flask import Flask, jsonify, request

import cja_segment_finder as core

APP_DIR = os.path.dirname(os.path.abspath(__file__))
HOST = "127.0.0.1"
PORT = 5000
CACHE_TTL_SECONDS = 120

app = Flask(__name__)
logging.getLogger("werkzeug").setLevel(logging.WARNING)

_data_view_cache = {"items": None, "fetched_at": 0.0}
_segment_cache = {}
_cache_lock = threading.Lock()
_pipeline_lock = threading.Lock()

PAGE_STYLE = """
<style>
:root {
  --bg:#f5f5f5; --card:#fff; --text:#292929; --muted:#6b6b6b;
  --border:#d5d5d5; --accent:#1473e6; --accent-dark:#0d66d0;
  --green:#2e7d32; --green-bg:#edf7ed; --red:#c62828; --red-bg:#fdecea;
}
* { box-sizing:border-box; }
body { margin:0; font-family:Arial,Helvetica,sans-serif; background:var(--bg); color:var(--text); }
.container { max-width:1400px; margin:0 auto; padding:70px 20px 44px; }
.page-header { margin-bottom:24px; }
h1 { margin:0 0 6px; font-size:32px; line-height:1.2; }
.subtitle { color:var(--muted); font-size:16px; }
.panel { background:var(--card); padding:34px 20px; border-radius:8px; box-shadow:0 2px 9px rgba(0,0,0,.09); }
.panel h2 { margin:6px 0 20px; font-size:24px; }
.credentials-note { display:flex; align-items:flex-start; gap:10px; padding:13px 15px; margin-bottom:18px; border:1px solid #cfe2f8; border-radius:6px; background:#f3f8fe; color:#31506f; font-size:14px; line-height:1.45; }
.credentials-note strong { color:#23384d; }
label { display:block; margin:12px 0 7px; font-size:16px; font-weight:700; }
select, input { width:100%; height:38px; padding:8px 12px; border:1px solid #cacaca; border-radius:5px; background:#fff; color:var(--text); font:14px Arial,Helvetica,sans-serif; }
select:focus, input:focus, button:focus-visible { outline:3px solid rgba(20,115,230,.22); outline-offset:1px; border-color:var(--accent); }
select:disabled { background:#f4f4f4; color:#999; }
.hint { margin-top:7px; color:var(--muted); font-size:12px; line-height:1.45; }
.actions { display:flex; align-items:center; gap:10px; flex-wrap:wrap; margin-top:18px; }
button { border:0; border-radius:5px; padding:11px 18px; font:600 14px Arial,Helvetica,sans-serif; cursor:pointer; }
button.primary { background:var(--accent); color:#fff; }
button.primary:hover:not(:disabled) { background:var(--accent-dark); }
button.secondary { background:#5d5d5d; color:#fff; }
button.secondary:hover:not(:disabled) { background:#484848; }
button:disabled { opacity:.56; cursor:not-allowed; }
.dataview-selection { margin-top:18px; padding:18px 14px 14px; border:1px solid #d9d9d9; border-radius:6px; background:#fafafa; }
.dataview-selection[hidden] { display:none; }
.generate-row { display:flex; align-items:center; gap:12px; margin-top:16px; }
.generate-row .primary { min-width:185px; }
.status { min-height:20px; margin-top:17px; padding:0; font-size:14px; line-height:1.45; }
.status.loading { color:#31506f; }
.status.success { padding:11px 13px; border-radius:5px; color:var(--green); background:var(--green-bg); }
.status.error { padding:11px 13px; border-radius:5px; color:var(--red); background:var(--red-bg); }
.spinner { display:none; width:14px; height:14px; border:2px solid #b8d3f2; border-top-color:var(--accent); border-radius:50%; animation:spin .8s linear infinite; }
.loading .spinner { display:inline-block; vertical-align:-2px; margin-right:6px; }
.error-card { max-width:760px; margin:80px auto; }
a.back { display:inline-block; margin-top:18px; color:var(--accent); text-decoration:none; font-weight:600; }
@keyframes spin { to { transform:rotate(360deg); } }
@media (prefers-reduced-motion:reduce) { .spinner { animation:none; } }
</style>
"""


def get_creds():
    client_id = os.getenv("CJA_API_KEY")
    return {
        "api_key": client_id,
        "org_id": os.getenv("CJA_ORG_ID"),
        "access_token": core.resolve_access_token(client_id, verbose=False),
    }


def get_data_views_cached(creds):
    now = time.time()
    with _cache_lock:
        cached = _data_view_cache["items"]
        is_fresh = cached is not None and now - _data_view_cache["fetched_at"] < CACHE_TTL_SECONDS
        if is_fresh:
            return cached

    items = core.get_data_views(creds, verbose=False)
    with _cache_lock:
        _data_view_cache["items"] = items
        _data_view_cache["fetched_at"] = time.time()
    return items


def get_segments_cached(creds, data_view_id):
    cache_key = "ALL" if not data_view_id or str(data_view_id).upper() == "ALL" else str(data_view_id)
    now = time.time()
    with _cache_lock:
        cached = _segment_cache.get(cache_key)
        if cached and now - cached["fetched_at"] < CACHE_TTL_SECONDS:
            return cached["segments"]

    api_filter = None if cache_key == "ALL" else cache_key
    segments = core.get_segments(creds, data_view_id=api_filter, verbose=False)
    with _cache_lock:
        _segment_cache[cache_key] = {"segments": segments, "fetched_at": time.time()}
    return segments


@app.route("/", methods=["GET"])
def index():
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Adobe CJA Segment Finder</title>
{PAGE_STYLE}
</head>
<body>
<main class="container">
  <header class="page-header">
    <h1>Adobe CJA Segment Finder</h1>
    <div class="subtitle">Retrieve available CJA segments and identify exact / near-duplicate definitions.</div>
  </header>

  <section class="panel" aria-labelledby="dataViewsHeading">
    <h2 id="dataViewsHeading">CJA Data Views</h2>
    <div class="credentials-note">
      <span aria-hidden="true">&#128274;</span>
      <div><strong>Adobe credentials are loaded securely from the local environment.</strong><br>
      They stay on this computer and are never displayed in the browser.</div>
    </div>

    <label for="threshold">Near-duplicate threshold (%)</label>
    <input id="threshold" name="threshold" form="reportForm" type="number" min="1" max="100" step="1" value="85">
    <div class="hint">Segments at or above this similarity are flagged as near-duplicates. 85 is the recommended default.</div>

    <div class="actions">
      <button id="showDataViews" class="primary" type="button">Show Data Views</button>
      <button id="clearButton" class="secondary" type="button">Clear</button>
    </div>

    <div id="status" class="status" role="status" aria-live="polite"></div>

    <form id="reportForm" action="/generate" method="post">
      <div id="dataViewPanel" class="dataview-selection" hidden>
        <label for="dataViewSelect">CJA Data View</label>
        <select id="dataViewSelect" name="dataview_selection" disabled required>
          <option value="">-- Select a Data View --</option>
        </select>
        <div class="hint">Select one Data View to analyze only its segments, or choose <strong>All Data Views</strong> to analyze the complete accessible segment library.</div>
        <div class="generate-row">
          <button id="generateButton" class="primary" type="submit" disabled>Generate Report</button>
          <span id="selectionHint" class="hint">Choose a Data View to continue.</span>
        </div>
      </div>
    </form>
  </section>
</main>

<script>
const showButton = document.getElementById('showDataViews');
const clearButton = document.getElementById('clearButton');
const panel = document.getElementById('dataViewPanel');
const select = document.getElementById('dataViewSelect');
const generateButton = document.getElementById('generateButton');
const selectionHint = document.getElementById('selectionHint');
const statusBox = document.getElementById('status');
const reportForm = document.getElementById('reportForm');

function setStatus(message, kind = '') {{
  statusBox.className = 'status' + (kind ? ' ' + kind : '');
  statusBox.innerHTML = kind === 'loading'
    ? '<span class="spinner" aria-hidden="true"></span>' + message
    : message;
}}

function resetSelection() {{
  select.replaceChildren(new Option('-- Select a Data View --', ''));
  select.disabled = true;
  select.value = '';
  generateButton.disabled = true;
  selectionHint.textContent = 'Choose a Data View to continue.';
  panel.hidden = true;
}}

showButton.addEventListener('click', async () => {{
  showButton.disabled = true;
  resetSelection();
  setStatus('Connecting to Adobe CJA and loading Data Views...', 'loading');
  try {{
    const response = await fetch('/api/data-views', {{headers: {{'Accept':'application/json'}}}});
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || 'Unable to load Data Views.');

    select.appendChild(new Option('All Data Views', 'ALL'));
    for (const dataView of payload.dataViews || []) {{
      select.appendChild(new Option(dataView.name || dataView.id, String(dataView.id)));
    }}
    select.disabled = false;
    panel.hidden = false;
    setStatus('Loaded ' + payload.count + ' Data View(s). Please select a Data View and generate the report.', 'success');
    select.focus();
  }} catch (error) {{
    setStatus('ERROR: ' + error.message, 'error');
    panel.hidden = true;
  }} finally {{
    showButton.disabled = false;
  }}
}});

select.addEventListener('change', () => {{
  const ready = Boolean(select.value);
  generateButton.disabled = !ready;
  selectionHint.textContent = ready ? 'Ready to generate the grouped cleanup report.' : 'Choose a Data View to continue.';
}});

clearButton.addEventListener('click', () => {{
  resetSelection();
  document.getElementById('threshold').value = '85';
  setStatus('');
  showButton.focus();
}});

reportForm.addEventListener('submit', event => {{
  if (!select.value) {{
    event.preventDefault();
    setStatus('Please select a Data View before generating the report.', 'error');
    select.focus();
    return;
  }}
  generateButton.disabled = true;
  showButton.disabled = true;
  clearButton.disabled = true;
  generateButton.textContent = 'Generating Report...';
  setStatus('Loading segments, checking workspace usage, and building duplicate groups...', 'loading');
}});
</script>
</body>
</html>"""


@app.route("/api/data-views", methods=["GET"])
def api_data_views():
    try:
        creds = get_creds()
        data_views = get_data_views_cached(creds)
        clean_data_views = [
            {"id": str(item.get("id")), "name": str(item.get("name") or item.get("id"))}
            for item in data_views
            if isinstance(item, dict) and item.get("id")
        ]
        return jsonify({"dataViews": clean_data_views, "count": len(clean_data_views)})
    except Exception as error:
        print(f"ERROR loading data views: {error}")
        return jsonify({"error": "Could not connect to Adobe CJA or load the Data View list."}), 502


@app.route("/generate", methods=["POST"])
def generate():
    dataview_selection = (request.form.get("dataview_selection") or "").strip()
    if not dataview_selection:
        return error_page("Please select a Data View before generating the report.")

    try:
        threshold = float(request.form.get("threshold", "85"))
    except (TypeError, ValueError):
        threshold = 85.0
    threshold = min(100.0, max(1.0, threshold))

    try:
        creds = get_creds()
        segments = get_segments_cached(creds, dataview_selection)
    except Exception as error:
        print(f"ERROR resolving credentials/segments: {error}")
        return error_page("Could not authenticate with Adobe or fetch segments.", detail=str(error))

    print(f"\nGenerating dashboard (data view: {dataview_selection}, threshold={threshold:.0f}%)...")
    if _pipeline_lock.locked():
        print("Another dashboard is already generating - waiting for it to finish...")

    try:
        with _pipeline_lock:
            result = core.run_pipeline(
                creds,
                threshold=threshold,
                output_dir=APP_DIR,
                verbose=False,
                dataview_selection=dataview_selection,
                segments=segments,
            )
    except Exception as error:
        print(f"ERROR generating dashboard: {error}")
        return error_page("Something went wrong while generating the report.", detail=str(error))

    if not result.get("dashboard_html_path"):
        return error_page("Connected successfully, but no segments matched this selection.")

    print(f"Done: {result['segment_count']} segments, {result['match_count']} matches.")
    return result["dashboard_html"]


def error_page(message, detail=None):
    safe_message = escape(str(message))
    detail_html = f'<div class="hint" style="margin-top:10px;">{escape(str(detail))}</div>' if detail else ""
    return f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>CJA Segment Finder - Error</title>{PAGE_STYLE}</head>
<body><main class="container error-card"><section class="panel">
  <h1>Couldn\'t generate the report</h1>
  <div class="status error">{safe_message}{detail_html}</div>
  <a class="back" href="/">&larr; Back to Data Views</a>
</section></main></body></html>""", 400


def open_browser_when_ready():
    webbrowser.open(f"http://{HOST}:{PORT}")


if __name__ == "__main__":
    core.validate_config()
    print("Adobe CJA Segment Finder - Python App")
    print(f"Opening http://{HOST}:{PORT} in your browser...")
    threading.Timer(1.0, open_browser_when_ready).start()
    app.run(host=HOST, port=PORT, debug=False)
