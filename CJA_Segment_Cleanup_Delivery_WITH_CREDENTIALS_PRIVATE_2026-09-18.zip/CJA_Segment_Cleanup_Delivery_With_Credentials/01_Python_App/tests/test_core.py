import os
import tempfile
import unittest
from unittest.mock import Mock, patch

import cja_segment_finder as core


class CoreApiTest(unittest.TestCase):
    def test_normalizes_expiry_in_seconds_or_milliseconds(self):
        self.assertEqual(core.normalize_expires_in_seconds(86400), 86400)
        self.assertEqual(core.normalize_expires_in_seconds(86400000), 86400)
        self.assertEqual(core.normalize_expires_in_seconds("bad"), 23 * 60 * 60)

    @patch("cja_segment_finder.cja_get")
    def test_get_data_views_paginates_deduplicates_and_sorts(self, cja_get):
        cja_get.side_effect = [
            {"content": [{"id": "2", "name": "Zulu"}, {"id": "1", "name": "Alpha"}]},
            {"content": [{"id": "3", "name": "Beta"}], "lastPage": True},
        ]

        with patch.object(core, "DATA_VIEW_PAGE_SIZE", 2):
            result = core.get_data_views({"api_key": "a", "org_id": "o", "access_token": "t"})

        self.assertEqual([item["name"] for item in result], ["Alpha", "Beta", "Zulu"])
        self.assertIn("/data/dataviews?", cja_get.call_args_list[0].args[0])
        self.assertIn("page=1", cja_get.call_args_list[1].args[0])

    @patch("cja_segment_finder.cja_get")
    def test_get_segments_uses_dataview_filter_and_safety_filter(self, cja_get):
        cja_get.return_value = {
            "content": [
                {"id": "matching", "dataId": "dv-1"},
                {"id": "outside", "dataId": "dv-2"},
                {"id": "unscoped"},
            ],
            "lastPage": True,
        }

        result = core.get_segments(
            {"api_key": "a", "org_id": "o", "access_token": "t"}, data_view_id="dv-1"
        )

        self.assertEqual([item["id"] for item in result], ["matching", "unscoped"])
        self.assertIn("dataviewIds=dv-1", cja_get.call_args.args[0])

    @patch("cja_segment_finder.time.time", return_value=1000.0)
    @patch("cja_segment_finder.request_with_retry")
    def test_fetch_token_preserves_second_based_lifetime(self, request_with_retry, _time):
        response = Mock(status_code=200)
        response.json.return_value = {"access_token": "token", "expires_in": 86400}
        request_with_retry.return_value = response

        token, expires_at = core.fetch_new_access_token("id", "secret", "scope")

        self.assertEqual(token, "token")
        self.assertEqual(expires_at, 87400.0)

    def test_token_cache_is_private(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = os.path.join(temp_dir, "token.json")
            core.save_cached_token(path, "token", 12345)
            self.assertEqual(os.stat(path).st_mode & 0o777, 0o600)


class DashboardTest(unittest.TestCase):
    def test_dashboard_contains_grouped_views_and_navigation(self):
        first = {"id": "a", "name": "One", "dataId": "dv", "dataName": "View", "definition": {}}
        second = {"id": "b", "name": "Two", "dataId": "dv", "dataName": "View", "definition": {}}
        match = {
            "type": "Exact duplicate",
            "similarity": 100.0,
            "a": first,
            "b": second,
            "diff": {"onlyA": [], "onlyB": []},
        }

        html = core.build_dashboard_html(
            [first, second], [match], {}, False, 85.0, "segments.csv", "View"
        )

        self.assertIn("Exact Duplicate Groups", html)
        self.assertIn("Near-Duplicate Groups", html)
        self.assertIn("Change Data View", html)
        self.assertIn("Available CJA Segments", html)
        self.assertIn("Duplicate / Near-Duplicate Segments", html)
        self.assertIn("Download Comparison Results", html)


if __name__ == "__main__":
    unittest.main()
