import unittest
from unittest.mock import patch

import app as webapp


class AppRoutesTest(unittest.TestCase):
    def setUp(self):
        webapp.app.config.update(TESTING=True)
        self.client = webapp.app.test_client()
        webapp._data_view_cache.update({"items": None, "fetched_at": 0.0})
        webapp._segment_cache.clear()

    @patch("app.get_creds")
    def test_landing_page_waits_for_show_data_views(self, get_creds):
        response = self.client.get("/")

        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Adobe CJA Segment Finder", response.data)
        self.assertIn(b"Show Data Views", response.data)
        self.assertIn(b'id="dataViewPanel"', response.data)
        get_creds.assert_not_called()

    @patch("app.get_data_views_cached")
    @patch("app.get_creds", return_value={"api_key": "a", "org_id": "o", "access_token": "t"})
    def test_data_view_endpoint_returns_complete_picker_payload(self, _get_creds, get_data_views):
        get_data_views.return_value = [
            {"id": "dv-1", "name": "Alpha"},
            {"id": "dv-2", "name": "Beta"},
        ]

        response = self.client.get("/api/data-views")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["count"], 2)
        self.assertEqual(response.get_json()["dataViews"][1]["name"], "Beta")

    @patch("app.get_data_views_cached", side_effect=RuntimeError("secret diagnostic"))
    @patch("app.get_creds", return_value={"api_key": "a", "org_id": "o", "access_token": "t"})
    def test_data_view_endpoint_hides_internal_error_details(self, _get_creds, _get_data_views):
        response = self.client.get("/api/data-views")

        self.assertEqual(response.status_code, 502)
        self.assertNotIn(b"secret diagnostic", response.data)

    def test_generate_requires_a_selection(self):
        response = self.client.post("/generate", data={"threshold": "85"})

        self.assertEqual(response.status_code, 400)
        self.assertIn(b"Please select a Data View", response.data)

    @patch("app.core.run_pipeline")
    @patch("app.get_segments_cached", return_value=[{"id": "s1", "dataId": "dv-1"}])
    @patch("app.get_creds", return_value={"api_key": "a", "org_id": "o", "access_token": "t"})
    def test_generate_fetches_selected_scope_and_clamps_threshold(
        self, _get_creds, get_segments, run_pipeline
    ):
        run_pipeline.return_value = {
            "dashboard_html_path": "/tmp/report.html",
            "dashboard_html": "<h1>report</h1>",
            "segment_count": 1,
            "match_count": 0,
        }

        response = self.client.post(
            "/generate", data={"dataview_selection": "dv-1", "threshold": "500"}
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data, b"<h1>report</h1>")
        get_segments.assert_called_once_with(
            {"api_key": "a", "org_id": "o", "access_token": "t"}, "dv-1"
        )
        self.assertEqual(run_pipeline.call_args.kwargs["threshold"], 100.0)
        self.assertEqual(run_pipeline.call_args.kwargs["dataview_selection"], "dv-1")

    def test_error_page_escapes_diagnostics(self):
        response, status = webapp.error_page("bad <script>", 'detail "unsafe"')

        self.assertEqual(status, 400)
        self.assertNotIn("<script>", response)
        self.assertIn("&lt;script&gt;", response)


if __name__ == "__main__":
    unittest.main()
