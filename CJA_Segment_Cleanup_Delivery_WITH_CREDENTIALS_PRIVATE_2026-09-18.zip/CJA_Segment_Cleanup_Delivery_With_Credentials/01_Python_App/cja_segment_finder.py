"""
================================================================
CJA SEGMENT FINDER — RUN THIS FROM VS CODE
================================================================
Run this file directly. It pulls your CJA segments, compares
them, and opens the finished dashboard in your browser
automatically when it's done - no web form, no extra click.

The access token Adobe issues expires after ~24h. Instead of
pasting a fresh one manually each time, this script can fetch
its own token automatically using an OAuth Server-to-Server
credential (Client ID + Client Secret + Scopes), which don't
expire, and caches it locally until it's actually close to
expiring - see AUTOMATIC TOKEN REFRESH below.

----------------------------------------------------------------
SETUP - AUTOMATIC TOKEN REFRESH (recommended)
----------------------------------------------------------------
1. Install dependencies:
     pip install requests python-dotenv

2. In Adobe Developer Console, make sure your project's
   credential is an "OAuth Server-to-Server" credential (not
   the older JWT / OAuth Web App type). That credential's page
   shows a Client ID, a Client Secret, and a ready-made Scopes
   string - copy all three.

3. Create a ".env" file in the same folder as this script:
     CJA_API_KEY=your_client_id
     CJA_CLIENT_SECRET=your_client_secret
     CJA_SCOPES=paste_the_scopes_string_from_developer_console
     CJA_ORG_ID=XXXXXXXXXXXXXXX@AdobeOrg
     CJA_NEAR_DUPLICATE_THRESHOLD=85
     CJA_VERBOSE=0                    (set to 1 for troubleshooting detail)

   No CJA_ACCESS_TOKEN needed - the script fetches and caches
   one itself (see .cja_token_cache.json, created automatically;
   keep it out of version control, same as .env).

----------------------------------------------------------------
DATA VIEW SCOPE (compare all data views, or just one)
----------------------------------------------------------------
By default, after segments are fetched a small window pops up
with a dropdown listing every data view found among them, plus
an "All Data Views" option - pick one and click "Generate
Dashboard". (If a GUI can't be shown on this machine - no
display, Tkinter missing, etc. - it automatically falls back to
the same choice as a numbered console prompt instead.)

To skip that step entirely (e.g. for an unattended run), set in
.env:
     CJA_DATAVIEW_ID=all                     (always compare everything)
   or
     CJA_DATAVIEW_ID=Production Data View    (always scope to one,
                                               by its name or ID)

----------------------------------------------------------------
SETUP - MANUAL TOKEN (fallback, if you don't want auto-refresh)
----------------------------------------------------------------
Leave CJA_CLIENT_SECRET / CJA_SCOPES unset and provide a token
directly instead - you'll need to replace it yourself every
~24h:
     CJA_API_KEY=your_client_id
     CJA_ORG_ID=XXXXXXXXXXXXXXX@AdobeOrg
     CJA_ACCESS_TOKEN=your_oauth_access_token

----------------------------------------------------------------
RUN
----------------------------------------------------------------
VS Code "Run Without Debugging", or a terminal:
     python cja_segment_finder.py

The dashboard opens in your browser automatically once it's
ready. A CSV of the full segment list is also saved next to
this script.
================================================================
"""

import json
import os
import time
import webbrowser
from datetime import datetime

import requests
from dotenv import load_dotenv

load_dotenv()

CJA_BASE = "https://cja.adobe.io"
IMS_TOKEN_URL = "https://ims-na1.adobelogin.com/ims/token/v3"

SEGMENT_PAGE_SIZE = 1000
DATA_VIEW_PAGE_SIZE = 1000
PROJECT_PAGE_SIZE = 1000

OUTPUT_DIR = os.getcwd()
TOKEN_CACHE_PATH = os.path.join(OUTPUT_DIR, ".cja_token_cache.json")
TOKEN_REFRESH_BUFFER_SECONDS = 300  # refresh 5 min before Adobe actually expires it

# A 429 (rate limited) or 5xx (Adobe having a bad moment) is worth retrying -
# these are usually gone in a few seconds. A 401/403/404 will still be wrong
# on the next attempt, so we don't waste time on those.
MAX_HTTP_RETRIES = 3
RETRY_BACKOFF_SECONDS = 2


# ============================================================
# 1. CJA API HELPER
# ============================================================

def request_with_retry(method, url, **kwargs):
    """requests.get/post, but survives the two things that actually happen
    in practice on a bulk run: Adobe briefly rate-limiting us, or a
    transient network blip. Anything else (bad credentials, bad request)
    fails on the first try since retrying won't change the outcome."""
    last_network_error = None

    for attempt in range(1, MAX_HTTP_RETRIES + 1):
        try:
            response = requests.request(method, url, timeout=30, **kwargs)
        except requests.exceptions.RequestException as error:
            last_network_error = error
            if attempt == MAX_HTTP_RETRIES:
                raise RuntimeError(
                    f"Network error calling {url} after {MAX_HTTP_RETRIES} attempts: {error}"
                )
            time.sleep(RETRY_BACKOFF_SECONDS * attempt)
            continue

        if response.status_code == 429 or response.status_code >= 500:
            if attempt == MAX_HTTP_RETRIES:
                return response  # let the caller report the final status/body as usual
            # Adobe sometimes tells us exactly how long to wait - use it if present.
            retry_after = response.headers.get("Retry-After")
            wait_seconds = float(retry_after) if retry_after and retry_after.isdigit() else RETRY_BACKOFF_SECONDS * attempt
            time.sleep(wait_seconds)
            continue

        return response

    raise RuntimeError(str(last_network_error))


def cja_get(url, creds):
    api_key = creds.get("api_key")
    org_id = creds.get("org_id")
    access_token = creds.get("access_token")

    if not api_key or not org_id or not access_token:
        raise RuntimeError(
            "Missing CJA credentials. An API Key, Org ID and Access Token are all required."
        )

    headers = {
        "accept": "application/json",
        "Content-Type": "application/json",
        "x-api-key": api_key,
        "x-gw-ims-org-id": org_id,
        "Authorization": f"Bearer {access_token}",
    }

    response = request_with_retry("GET", url, headers=headers)

    if response.status_code != 200:
        raise RuntimeError(
            f"Adobe CJA API returned HTTP {response.status_code}\n{response.text[:500]}"
        )

    try:
        return response.json()
    except ValueError:
        # Happens when a gateway/proxy hands back an HTML error page instead
        # of the JSON body we asked for - a raw stack trace here would be
        # confusing, so surface what we actually got instead.
        raise RuntimeError(
            f"CJA API returned a 200 but the body wasn't valid JSON. "
            f"First 200 characters: {response.text[:200]!r}"
        )


def extract_list(response, *keys):
    if isinstance(response, list):
        return response
    if isinstance(response, dict):
        for key in keys:
            if isinstance(response.get(key), list):
                return response[key]
    raise RuntimeError(
        f"Unexpected CJA API response structure: {json.dumps(response)[:300]}"
    )


# ============================================================
# 1b. AUTOMATIC ACCESS TOKEN (OAuth Server-to-Server)
# ============================================================
# Adobe access tokens expire (~24h). Rather than pasting a fresh one into
# .env before every run, this fetches a new one automatically using a
# Client Secret (which does NOT expire), and caches it locally so we're
# not requesting a brand new token on every single run - only once it's
# actually close to expiring.

def fetch_new_access_token(client_id, client_secret, scopes):
    response = request_with_retry(
        "POST",
        IMS_TOKEN_URL,
        data={
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
            "scope": scopes,
        },
    )

    if response.status_code != 200:
        raise RuntimeError(
            f"Adobe IMS token request failed (HTTP {response.status_code}): {response.text}\n"
            "Double-check CJA_API_KEY, CJA_CLIENT_SECRET and CJA_SCOPES in .env - these must "
            "come from an OAuth Server-to-Server credential, not the older JWT/OAuth Web App type."
        )

    try:
        data = response.json()
    except ValueError:
        raise RuntimeError(f"Adobe IMS returned a non-JSON response: {response.text[:200]!r}")

    access_token = data.get("access_token")
    if not access_token:
        raise RuntimeError(f"Adobe IMS response did not include an access_token: {data}")

    # Adobe IMS responses have appeared with expires_in expressed in either
    # seconds or milliseconds. Treat values larger than seven days as
    # milliseconds; ordinary OAuth lifetimes stay in seconds. This avoids
    # needlessly asking IMS for a fresh token on every page action.
    expires_in_seconds = normalize_expires_in_seconds(data.get("expires_in"))

    expires_at = time.time() + expires_in_seconds
    return access_token, expires_at


def load_cached_token(cache_path):
    if not os.path.exists(cache_path):
        return None, None
    try:
        with open(cache_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("access_token"), data.get("expires_at")
    except (json.JSONDecodeError, OSError, ValueError):
        return None, None


def save_cached_token(cache_path, access_token, expires_at):
    try:
        with open(cache_path, "w", encoding="utf-8") as f:
            json.dump({"access_token": access_token, "expires_at": expires_at}, f)
        try:
            os.chmod(cache_path, 0o600)
        except OSError:
            pass
    except OSError:
        pass  # caching is a convenience only - a failure here shouldn't stop the run


def normalize_expires_in_seconds(value):
    """Normalize OAuth ``expires_in`` values from seconds or milliseconds."""
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return 23 * 60 * 60

    if numeric <= 0:
        return 23 * 60 * 60
    return numeric / 1000.0 if numeric > 7 * 24 * 60 * 60 else numeric


def get_access_token(client_id, client_secret, scopes, cache_path=None, verbose=False):
    """Returns a valid access token, reusing the cached one if it's not
    close to expiring yet, otherwise fetching (and caching) a new one."""
    cache_path = cache_path or TOKEN_CACHE_PATH

    cached_token, cached_expires_at = load_cached_token(cache_path)
    if cached_token and cached_expires_at and time.time() < (cached_expires_at - TOKEN_REFRESH_BUFFER_SECONDS):
        if verbose:
            remaining_hours = (cached_expires_at - time.time()) / 3600
            print(f"Reusing cached access token (valid for another {remaining_hours:.1f}h).")
        return cached_token

    print("Fetching a new access token from Adobe IMS...")
    access_token, expires_at = fetch_new_access_token(client_id, client_secret, scopes)
    save_cached_token(cache_path, access_token, expires_at)
    print("New access token obtained and cached (valid ~24h).")
    return access_token


# ============================================================
# 2. FETCH DATA VIEWS + SEGMENTS (paginated)
# ============================================================

def get_data_views(creds, verbose=False):
    """Return every accessible CJA data view, including empty data views."""
    all_data_views = []
    page = 0

    while True:
        url = (
            f"{CJA_BASE}/data/dataviews"
            f"?expansion=name,owner,organization,description"
            f"&limit={DATA_VIEW_PAGE_SIZE}&page={page}"
        )
        if verbose:
            print(f"Loading data view API page {page + 1}...")
        response = cja_get(url, creds)
        content = extract_list(response, "content", "dataViews", "dataviews")
        all_data_views.extend(content)

        total_pages = response.get("totalPages") if isinstance(response, dict) else None
        last_page = isinstance(response, dict) and response.get("lastPage") is True
        try:
            reached_total_pages = total_pages is not None and page + 1 >= int(total_pages)
        except (TypeError, ValueError):
            reached_total_pages = False

        if len(content) < DATA_VIEW_PAGE_SIZE or last_page or reached_total_pages:
            break
        page += 1

    unique = {}
    for data_view in all_data_views:
        data_view_id = data_view.get("id") if isinstance(data_view, dict) else None
        if data_view_id:
            unique[str(data_view_id)] = data_view

    return sorted(
        unique.values(),
        key=lambda item: str(item.get("name") or item.get("id") or "").lower(),
    )


def get_segments(creds, data_view_id=None, verbose=False):
    all_segments = []
    page = 0

    while True:
        url = (
            f"{CJA_BASE}/segments"
            f"?includeType=all&page={page}&limit={SEGMENT_PAGE_SIZE}"
            f"&expansion=definition,tags,compatibility,dataName,dataId,owner,ownerFullName"
        )
        if data_view_id and str(data_view_id).upper() != "ALL":
            url += f"&dataviewIds={data_view_id}"
        if verbose:
            print(f"Loading segment API page {page + 1}... (collected so far: {len(all_segments)})")
        response = cja_get(url, creds)
        content = extract_list(response, "content", "segments")

        if not content:
            break

        all_segments.extend(content)

        total_pages = response.get("totalPages") if isinstance(response, dict) else None
        last_page = isinstance(response, dict) and response.get("lastPage") is True
        try:
            reached_total_pages = total_pages is not None and page + 1 >= int(total_pages)
        except (TypeError, ValueError):
            reached_total_pages = False

        if len(content) < SEGMENT_PAGE_SIZE or last_page or reached_total_pages:
            break
        page += 1

    if data_view_id and str(data_view_id).upper() != "ALL":
        requested_id = str(data_view_id)
        filtered_segments = []
        for segment in all_segments:
            segment_data_id = (
                segment.get("dataId")
                or segment.get("dataID")
                or segment.get("data_id")
            )
            # Preserve genuinely unscoped payloads, matching the V5 tool's
            # safety-net behavior, but exclude a positively different owner.
            if segment_data_id is None or str(segment_data_id) == requested_id:
                filtered_segments.append(segment)
        all_segments = filtered_segments

    return all_segments


# ============================================================
# 3. FETCH WORKSPACE PROJECTS (paginated) + USAGE MAPPING
# ============================================================

def get_workspace_projects(creds, verbose=False):
    all_projects = []
    page = 0

    while True:
        url = (
            f"{CJA_BASE}/projects"
            f"?includeType=all&locale=en_US&limit={PROJECT_PAGE_SIZE}&page={page}"
            f"&expansion=externalReferences,definition,ownerFullName,shares"
        )
        if verbose:
            print(f"Loading workspace dashboard page {page + 1}...")
        response = cja_get(url, creds)
        content = extract_list(response, "content", "projects")
        all_projects.extend(content)

        last_page = isinstance(response, dict) and response.get("lastPage") is True
        number_of_elements = (
            response.get("numberOfElements") if isinstance(response, dict) else None
        )

        if (
            len(content) < PROJECT_PAGE_SIZE
            or last_page
            or (number_of_elements is not None and number_of_elements < PROJECT_PAGE_SIZE)
        ):
            break
        page += 1

    return all_projects


def project_is_shared_or_published(project):
    shares = project.get("shares")
    if isinstance(shares, (list, dict)):
        has_shares = len(shares) > 0
    else:
        has_shares = False

    return (
        has_shares
        or project.get("approved") is True
        or project.get("isCurated") is True
        or (project.get("definition") or {}).get("isCurated") is True
    )


def collect_segment_ids_from_project(project, known_segment_ids):
    """Walk a project's externalReferences/definition looking for any
    segment id that also appears in our known segment list."""
    found = set()
    visited = set()

    def walk(value):
        if value is None:
            return

        if isinstance(value, str):
            if value in known_segment_ids:
                found.add(value)
            return

        if isinstance(value, list):
            obj_id = id(value)
            if obj_id in visited:
                return
            visited.add(obj_id)
            for item in value:
                walk(item)
            return

        if isinstance(value, dict):
            obj_id = id(value)
            if obj_id in visited:
                return
            visited.add(obj_id)

            comp_type = str(
                value.get("componentType") or value.get("type") or value.get("resourceType") or ""
            ).lower()
            comp_id = (
                value.get("id")
                or value.get("segmentId")
                or value.get("componentId")
                or (value.get("component") or {}).get("id")
            )
            if "segment" in comp_type and isinstance(comp_id, str) and comp_id in known_segment_ids:
                found.add(comp_id)

            for key in value:
                walk(value[key])
            return

    walk(project.get("externalReferences"))
    walk(project.get("definition"))
    return found


def load_workspace_usage(segments, creds, verbose=False):
    """Returns (usage_map, loaded_ok).
    usage_map: segment_id -> {count, sharedPublishedCount, projectNames, sharedPublishedProjectNames}
    """
    usage = {}
    known_segment_ids = {str(s.get("id")) for s in segments if s.get("id")}

    try:
        projects = get_workspace_projects(creds, verbose=verbose)
    except Exception as error:
        print(f"WARNING: Unable to load CJA workspace project usage: {error}")
        return usage, False

    for project in projects:
        ids = collect_segment_ids_from_project(project, known_segment_ids)
        shared = project_is_shared_or_published(project)
        for seg_id in ids:
            u = usage.setdefault(
                seg_id,
                {
                    "count": 0,
                    "sharedPublishedCount": 0,
                    "projectNames": [],
                    "sharedPublishedProjectNames": [],
                },
            )
            u["count"] += 1
            if shared:
                u["sharedPublishedCount"] += 1
            name = project.get("name")
            if name:
                u["projectNames"].append(name)
                if shared:
                    u["sharedPublishedProjectNames"].append(name)

    return usage, True


def get_segment_usage(usage_map, segment):
    return usage_map.get(
        str(segment.get("id", "")),
        {"count": 0, "sharedPublishedCount": 0, "projectNames": [], "sharedPublishedProjectNames": []},
    )


def get_data_view_name(segment):
    """Per Adobe's CJA Segments API docs, each segment includes 'reportSuiteName'
    (the data view's friendly name) and 'rsid' (the data view's ID) directly.
    Older/partial payloads may not include those, so fall back to the same
    defensive field-guessing as before."""
    return (
        segment.get("reportSuiteName")
        or segment.get("dataName")
        or segment.get("dataViewName")
        or (segment.get("dataview") or {}).get("name")
        or (segment.get("dataView") or {}).get("name")
        or (segment.get("dataSource") or {}).get("name")
        or segment.get("rsid")
        or segment.get("dataId")
        or "-"
    )


def get_data_view_id(segment):
    """The data view ID a segment belongs to. Per Adobe's CJA Segments API
    docs this is the 'rsid' field; older/partial payloads may not include
    it, so fall back to other common field shapes. Used to filter segments
    down to a single data view."""
    return (
        segment.get("rsid")
        or segment.get("dataId")
        or (segment.get("dataview") or {}).get("id")
        or (segment.get("dataView") or {}).get("id")
        or (segment.get("dataSource") or {}).get("id")
        or None
    )


def get_owner_name(segment):
    """Adobe payloads can expose owner information under different fields
    depending on the endpoint and which expansions were requested. Keep
    this defensive so the export works across common CJA API shapes."""
    owner = segment.get("owner") or {}
    user = segment.get("user") or {}
    created_by = segment.get("createdBy")

    created_by_name = None
    if isinstance(created_by, dict):
        created_by_name = created_by.get("name") or created_by.get("displayName")
    elif isinstance(created_by, str):
        created_by_name = created_by

    owner_id = owner.get("id") or owner.get("ownerId")

    return (
        owner.get("name")
        or owner.get("displayName")
        or owner.get("login")
        or segment.get("ownerFullName")
        or segment.get("ownerName")
        or created_by_name
        or user.get("name")
        or user.get("displayName")
        or (f"Owner ID: {owner_id}" if owner_id else None)
        or "-"
    )


def get_distinct_dataviews(segments):
    """Returns the distinct data views actually present among the fetched
    segments, as a sorted list of {"id", "name"}. We derive this from the
    segments themselves (they already carry dataId/dataName) rather than
    calling a separate data views endpoint, so there's no guessing at an
    unfamiliar API shape - just what's really there."""
    seen = {}
    for segment in segments:
        dv_id = get_data_view_id(segment)
        dv_name = get_data_view_name(segment)
        key = dv_id or dv_name  # fall back to name as the key if no id is present
        if key and key not in seen:
            seen[key] = {"id": key, "name": dv_name}
    return sorted(seen.values(), key=lambda d: d["name"].lower())


def prompt_dataview_via_form(dataviews):
    """Shows a small native window - a dropdown listing 'All Data Views'
    plus every data view found, and a 'Generate Dashboard' button - so
    picking a scope feels like a simple form rather than typing into a
    terminal. This is what actually shows on screen for the person running
    it (or a client watching over their shoulder).

    Raises on any failure (no display, Tkinter missing, etc.) so the
    caller can fall back to the console menu instead of crashing the run.
    """
    import tkinter as tk
    from tkinter import ttk

    options = ["All Data Views"] + [dv["name"] for dv in dataviews]
    result = {"choice": options[0]}

    root = tk.Tk()
    root.title("CJA Segment Cleanup")
    root.resizable(False, False)

    frame = tk.Frame(root, padx=28, pady=24)
    frame.pack(fill="both", expand=True)

    tk.Label(frame, text="CJA Segment Cleanup", font=("Segoe UI", 14, "bold")).pack(anchor="w")
    tk.Label(
        frame, text="Select the data view to analyze:", font=("Segoe UI", 10)
    ).pack(anchor="w", pady=(8, 8))

    selected_var = tk.StringVar(value=options[0])
    combo = ttk.Combobox(
        frame, textvariable=selected_var, values=options, state="readonly", width=42
    )
    combo.pack(fill="x")

    def on_generate():
        result["choice"] = selected_var.get()
        root.destroy()

    def on_close():
        root.destroy()  # leave result["choice"] at the default (All Data Views)

    root.protocol("WM_DELETE_WINDOW", on_close)

    button = tk.Button(
        frame,
        text="Generate Dashboard",
        command=on_generate,
        bg="#315efb",
        fg="white",
        activebackground="#2748c9",
        activeforeground="white",
        font=("Segoe UI", 10, "bold"),
        relief="flat",
        padx=10,
        pady=8,
    )
    button.pack(fill="x", pady=(20, 0))

    root.update_idletasks()
    root.eval("tk::PlaceWindow . center")
    root.lift()
    root.attributes("-topmost", True)
    root.after(250, lambda: root.attributes("-topmost", False))
    root.mainloop()

    choice = result["choice"]
    if choice == "All Data Views":
        return None, "All Data Views"

    for dv in dataviews:
        if dv["name"] == choice:
            return dv["id"], dv["name"]

    return None, "All Data Views"


def resolve_dataview_selection(dataviews, selection):
    """selection: "prompt" (interactive form, falling back to a console
    menu if a GUI can't be shown), "all"/""/None (no filter), or a
    specific data view id/name (non-interactive - used for CJA_DATAVIEW_ID
    in .env). Returns (selected_key_or_None, display_label). selected_key
    matches the "id" produced by get_distinct_dataviews()."""
    if not dataviews:
        return None, "All Data Views"

    if selection is None or str(selection).strip().lower() in ("all", ""):
        return None, "All Data Views"

    if selection != "prompt":
        for dv in dataviews:
            if str(selection) == str(dv["id"]) or str(selection).lower() == str(dv["name"]).lower():
                return dv["id"], dv["name"]
        available = ", ".join(f"{dv['name']} ({dv['id']})" for dv in dataviews)
        raise RuntimeError(
            f"CJA_DATAVIEW_ID '{selection}' did not match any data view found among the "
            f"fetched segments. Available: {available}"
        )

    # No point prompting if there's only one data view in play anyway.
    if len(dataviews) == 1:
        return None, "All Data Views"

    try:
        return prompt_dataview_via_form(dataviews)
    except Exception as error:
        print(f"Could not show the selection form ({error}); falling back to a console prompt.")

    print("\nMultiple data views were found among the fetched segments:")
    print("  0. All Data Views (no filter)")
    for index, dv in enumerate(dataviews, start=1):
        print(f"  {index}. {dv['name']}  ({dv['id']})")

    while True:
        try:
            choice = input("\nSelect a data view to compare [0 = All]: ").strip()
        except EOFError:
            print("No interactive input available - defaulting to All Data Views.")
            return None, "All Data Views"

        if choice in ("", "0"):
            return None, "All Data Views"

        if choice.isdigit() and 1 <= int(choice) <= len(dataviews):
            dv = dataviews[int(choice) - 1]
            return dv["id"], dv["name"]

        print("Invalid selection - enter a number from the list above.")


# ============================================================
# 4. NORMALIZE / TOKENIZE / SIMILARITY
# ============================================================

def canonicalize(value):
    if value is None or not isinstance(value, (dict, list)):
        return value
    if isinstance(value, list):
        return [canonicalize(item) for item in value]
    return {key: canonicalize(value[key]) for key in sorted(value.keys())}


def normalized_definition(segment):
    definition = segment.get("definition") or {}
    return json.dumps(canonicalize(definition), separators=(",", ":"), ensure_ascii=False)


def flatten_to_path_tokens(value, path, tokens):
    """Walks a canonicalized definition and emits 'key.path=value' tokens
    instead of a flat bag of words. This keeps a value tied to the
    field/predicate it actually belongs to, so (for example) an
    event-count threshold of 0 in one segment can no longer be silently
    matched against an unrelated '1' that happens to sit somewhere else
    in another segment's JSON - the old tokenizer split everything into
    bare words like "0"/"1"/"streq" with no memory of which field they
    came from, so two segments could score 100% similar even when their
    actual comparison values differed.

    Arrays are walked without embedding the numeric index into the path,
    so legitimately reordering rules/predicates within a container still
    counts as a match (preserves the existing "array order shouldn't
    count as a real difference" behavior) - but every leaf value still
    carries the chain of object keys above it, so it can only match a
    token from the same field in the other segment.
    """
    if value is None or not isinstance(value, (dict, list)):
        tokens.add((path or "value") + "=" + str(value))
        return

    if isinstance(value, list):
        if not value:
            tokens.add(path + "=[]")
        for item in value:
            flatten_to_path_tokens(item, path, tokens)
        return

    keys = sorted(value.keys())
    if not keys:
        tokens.add(path + "={}")
    for key in keys:
        child_path = f"{path}.{key}" if path else key
        flatten_to_path_tokens(value[key], child_path, tokens)


def tokenize(segment):
    definition = canonicalize(segment.get("definition") or {})
    tokens = set()
    flatten_to_path_tokens(definition, "", tokens)
    return tokens


def similarity_from_tokens(tokens_a, tokens_b):
    smaller, larger = (tokens_a, tokens_b) if len(tokens_a) <= len(tokens_b) else (tokens_b, tokens_a)
    intersection = sum(1 for token in smaller if token in larger)
    union = len(tokens_a) + len(tokens_b) - intersection
    return 100.0 if union == 0 else (intersection / union) * 100


def differences_from_tokens(tokens_a, tokens_b):
    return {
        "onlyA": sorted(tokens_a - tokens_b),
        "onlyB": sorted(tokens_b - tokens_a),
    }


# ============================================================
# 5. FIND DUPLICATES (exact hash-match + near-duplicate via
#    inverted index — same approach as the HTML tool so this
#    stays fast on large segment libraries)
# ============================================================

def find_duplicate_segments(segments, threshold=85, verbose=False):
    prepared = [
        {
            "index": idx,
            "segment": segment,
            "normalized": normalized_definition(segment),
            "tokens": tokenize(segment),
        }
        for idx, segment in enumerate(segments)
    ]

    matches = []

    # --- Exact duplicates via hash grouping ---
    # Segments with no real rules (missing/blank definition) all normalize
    # to the same empty string and would otherwise get flagged as "100%
    # duplicates" of each other - which isn't a useful cleanup signal, just
    # noise from broken/placeholder segments. Leave them out of grouping
    # entirely; they still count toward "segments analyzed", just never
    # match anything.
    exact_groups = {}
    for item in prepared:
        if not item["tokens"]:
            continue
        exact_groups.setdefault(item["normalized"], []).append(item)

    exact_pairs = set()
    for group in exact_groups.values():
        if len(group) > 1:
            for x in range(len(group)):
                for y in range(x + 1, len(group)):
                    a, b = group[x], group[y]
                    exact_pairs.add((a["index"], b["index"]))
                    matches.append(
                        {
                            "type": "Exact duplicate",
                            "similarity": 100.0,
                            "a": a["segment"],
                            "b": b["segment"],
                            "diff": differences_from_tokens(a["tokens"], b["tokens"]),
                        }
                    )

    # --- Near duplicates via inverted index (candidate generation) ---
    # A segment with zero tokens never gets added to this index (the inner
    # loop just doesn't run), so it can never surface as a candidate for
    # anyone else either - same "don't match empty against empty" rule as
    # above, it just falls out naturally here rather than needing a check.
    inverted = {}
    for item in prepared:
        for token in item["tokens"]:
            inverted.setdefault(token, []).append(item["index"])

    total = len(prepared)
    for item in prepared:
        if verbose and item["index"] % 100 == 0:
            print(f"Comparing segment definitions... {item['index']} / {total}")

        candidates = set()
        for token in item["tokens"]:
            for idx in inverted.get(token, []):
                if idx > item["index"]:
                    candidates.add(idx)

        for j in candidates:
            if (item["index"], j) in exact_pairs or (j, item["index"]) in exact_pairs:
                continue

            a = prepared[item["index"]]
            b = prepared[j]
            score = similarity_from_tokens(a["tokens"], b["tokens"])

            if score >= threshold:
                # A 100% token-overlap score means the two definitions contain
                # the exact same set of rules/metrics/dimensions/operators -
                # they only differ (if at all) in the ORDER those items appear
                # in an array (e.g. metric/dimension sequence within a rule).
                # That's still a true exact duplicate for practical purposes,
                # even though the raw JSON string hash didn't match because
                # canonicalize() preserves array order. Treat it as such
                # instead of "Near duplicate".
                is_exact = score >= 99.995  # guard against float rounding

                matches.append(
                    {
                        "type": "Exact duplicate" if is_exact else "Near duplicate",
                        "similarity": 100.0 if is_exact else score,
                        "a": a["segment"],
                        "b": b["segment"],
                        "diff": differences_from_tokens(a["tokens"], b["tokens"]),
                    }
                )

    matches.sort(key=lambda m: m["similarity"], reverse=True)
    return matches


# ============================================================
# 6. DELETION RECOMMENDATION
# ============================================================

def get_deletion_recommendation(match, usage_map, usage_loaded):
    if not usage_loaded:
        return {
            "text": "Unable to verify - workspace usage not loaded",
            "detail": "Workspace project usage could not be verified with the current credentials.",
        }

    usage_a = get_segment_usage(usage_map, match["a"])
    usage_b = get_segment_usage(usage_map, match["b"])

    if match["type"] == "Exact duplicate":
        if usage_a["count"] == 0 and usage_b["count"] == 0:
            return {
                "text": "Can be deleted: both unused",
                "detail": (
                    "Exact duplicate pair; neither segment is referenced by a workspace "
                    "dashboard. Retain one and remove the other after owner/business confirmation."
                ),
            }
        if usage_a["count"] == 0 and usage_b["count"] > 0:
            return {
                "text": "Delete Segment A",
                "detail": f"Exact duplicate. A has 0 dashboard references; B is used in {usage_b['count']} dashboard(s).",
            }
        if usage_b["count"] == 0 and usage_a["count"] > 0:
            return {
                "text": "Delete Segment B",
                "detail": f"Exact duplicate. B has 0 dashboard references; A is used in {usage_a['count']} dashboard(s).",
            }
        return {
            "text": "Do not delete — both are used",
            "detail": (
                "Both exact duplicates are referenced by workspace dashboards. "
                "Review owner and dashboard impact before consolidation."
            ),
        }

    # Near duplicate
    if usage_a["count"] == 0 and usage_b["count"] == 0:
        return {
            "text": "Review: both unused",
            "detail": (
                "Near duplicate only. Neither segment is referenced by a workspace "
                "dashboard; validate business intent before deleting either."
            ),
        }
    if usage_a["count"] == 0 and usage_b["count"] > 0:
        return {
            "text": "Review Segment A",
            "detail": (
                "A is unused in dashboards while B is used. Because this is a near "
                "duplicate, confirm definition/owner before deletion."
            ),
        }
    if usage_b["count"] == 0 and usage_a["count"] > 0:
        return {
            "text": "Review Segment B",
            "detail": (
                "B is unused in dashboards while A is used. Because this is a near "
                "duplicate, confirm definition/owner before deletion."
            ),
        }
    return {
        "text": "Do not delete — both are used",
        "detail": "Both near-duplicate segments are referenced by workspace dashboards.",
    }


def get_recommendation_bucket(recommendation_text):
    """Buckets a recommendation's text into one of: cleanup, review, keep, unknown.
    Used for the summary cards / chart on the HTML dashboard."""
    text = recommendation_text.lower()
    if text.startswith("delete") or text.startswith("can be deleted"):
        return "cleanup"
    if text.startswith("review"):
        return "review"
    if text.startswith("do not delete"):
        return "keep"
    return "unknown"


# ============================================================
# 6b. DUPLICATE GROUPING (connected components across match pairs)
# ============================================================
# Same grouping logic as the HTML tool: two segments that were directly
# compared and matched are an "edge" between them. If A~B and B~C (same
# match type), A, B and C all belong to the same group/row, even though A
# and C were never directly compared to each other. This is plain
# union-find over the match pairs.

def get_match_segment_key(segment):
    return str(segment.get("id") or segment.get("name") or "")


def count_distinct_segments_in_matches(matches, match_type):
    """Counts distinct segments (not pairwise rows) that appear as either
    side of a match of the given type."""
    ids = set()
    for match in matches or []:
        if match["type"] != match_type:
            continue
        ids.add(get_match_segment_key(match["a"]))
        ids.add(get_match_segment_key(match["b"]))
    return len(ids)


def build_duplicate_groups(matches, match_type):
    """Builds duplicate "clusters" for a given match type using union-find:
    if A~B and B~C, A, B and C all land in the same group even though A and
    C may never have been directly compared to each other."""
    edges = [m for m in (matches or []) if m["type"] == match_type]
    if not edges:
        return []

    parent = {}
    segment_by_key = {}

    def find(key):
        root = key
        while parent[root] != root:
            root = parent[root]
        # Path compression.
        current = key
        while parent[current] != root:
            nxt = parent[current]
            parent[current] = root
            current = nxt
        return root

    def union(key_a, key_b):
        root_a, root_b = find(key_a), find(key_b)
        if root_a != root_b:
            parent[root_a] = root_b

    def ensure(segment):
        key = get_match_segment_key(segment)
        if key not in parent:
            parent[key] = key
        if key not in segment_by_key:
            segment_by_key[key] = segment
        return key

    for match in edges:
        key_a = ensure(match["a"])
        key_b = ensure(match["b"])
        union(key_a, key_b)

    groups = {}
    for key, segment in segment_by_key.items():
        root = find(key)
        groups.setdefault(root, []).append(segment)

    return sorted(
        (group for group in groups.values() if len(group) > 1),
        key=lambda group: len(group),
        reverse=True,
    )


def get_group_deletion_recommendation(group_segments, is_exact, usage_map, usage_loaded):
    """Group-level deletion recommendation: looks at workspace dashboard
    usage across every segment in the cluster, not just a single pair."""
    if not usage_loaded:
        return {
            "text": "Unable to verify — workspace usage not loaded",
            "class_name": "recommend-review",
        }

    usage_info = [(segment, get_segment_usage(usage_map, segment)) for segment in group_segments]
    used = [item for item in usage_info if item[1]["count"] > 0]
    unused = [item for item in usage_info if item[1]["count"] == 0]

    if not used:
        text = (
            f"Can be deleted: all {len(group_segments)} segments unused — retain one, remove the rest"
            if is_exact
            else f"Review: all {len(group_segments)} segments unused — validate business intent before deleting"
        )
        return {"text": text, "class_name": "recommend-delete" if is_exact else "recommend-review"}

    if not unused:
        return {
            "text": f"Do not delete — all {len(group_segments)} segments are used",
            "class_name": "recommend-keep",
        }

    unused_names = ", ".join(segment.get("name", "(No name)") for segment, _ in unused)
    used_names = ", ".join(segment.get("name", "(No name)") for segment, _ in used)

    text = ("Delete unused: " if is_exact else "Review unused: ") + unused_names + " | Keep (in use): " + used_names
    return {"text": text, "class_name": "recommend-delete" if is_exact else "recommend-review"}


def render_duplicate_group_rows(groups, is_exact, usage_map, usage_loaded):
    """Renders the <tr> rows for one Duplicate Groups table (exact or
    near). Mirrors renderDuplicateGroupRows() in the HTML tool."""
    if not groups:
        label = "exact-duplicate" if is_exact else "near-duplicate"
        return (
            '<tr><td colspan="4">'
            f'<span class="badge strong">No {label} groups found.</span>'
            "</td></tr>"
        )

    rows = []
    for index, group in enumerate(groups):
        names_html = "".join(
            f'<span class="group-segment-name">{esc(segment.get("name", "(No name)"))}</span>'
            for segment in group
        )

        distinct_dataviews = []
        seen_dv = set()
        for segment in group:
            dv_name = get_data_view_name(segment)
            if dv_name not in seen_dv:
                seen_dv.add(dv_name)
                distinct_dataviews.append(dv_name)
        dataviews_html = "".join(
            f'<span class="group-segment-name">{esc(name)}</span>' for name in distinct_dataviews
        )

        recommendation = get_group_deletion_recommendation(group, is_exact, usage_map, usage_loaded)

        rows.append(
            "<tr>"
            f"<td>{index + 1}</td>"
            f"<td>{names_html}</td>"
            f"<td>{dataviews_html}</td>"
            f'<td><span class="{recommendation["class_name"]}">{esc(recommendation["text"])}</span></td>'
            "</tr>"
        )

    return "".join(rows)


# ============================================================
# 7. CONSOLE REPORT
# ============================================================

def display_cleanup_analysis(matches, total_segments, usage_map, usage_loaded, verbose=False):
    exact_count = sum(1 for m in matches if m["type"] == "Exact duplicate")
    near_count = sum(1 for m in matches if m["type"] == "Near duplicate")

    # Minimal by default - the dashboard is where the outcome actually gets
    # reviewed. This block stays on the console purely so a run can be
    # sanity-checked without opening a browser (e.g. did it find anything at
    # all, did usage load). Full per-match detail only prints in verbose
    # mode, for troubleshooting a specific run.
    print(
        f"Analysis complete: {total_segments} segments checked, "
        f"{len(matches)} duplicate/near-duplicate match(es) "
        f"({exact_count} exact, {near_count} near)."
    )
    if not usage_loaded:
        print("NOTE: Workspace dashboard usage could not be verified this run - "
              "recommendations default to 'Review' until usage is confirmed.")

    if not verbose:
        return

    if not matches:
        print("No duplicate or near-duplicate segments were identified.")
        return

    print("\n" + "=" * 100)
    print("DUPLICATE / NEAR-DUPLICATE DETAILS (verbose)")
    print("=" * 100)

    # Same reasoning as the segment listing: a bulk org can easily produce
    # hundreds of matches, and printing full detail for every single one
    # floods the terminal without helping anyone. Cap the console detail
    # and point to the dashboard (which paginates) for the rest.
    MATCH_LISTING_LIMIT = 50
    matches_to_print = matches[:MATCH_LISTING_LIMIT]
    if len(matches) > MATCH_LISTING_LIMIT:
        print(
            f"\nShowing the first {MATCH_LISTING_LIMIT} of {len(matches)} matches here. "
            "Open the HTML dashboard for the full, paginated list."
        )

    for index, match in enumerate(matches_to_print, start=1):
        segment_a = match["a"]
        segment_b = match["b"]
        usage_a = get_segment_usage(usage_map, segment_a)
        usage_b = get_segment_usage(usage_map, segment_b)
        recommendation = get_deletion_recommendation(match, usage_map, usage_loaded)

        print("\n" + "-" * 100)
        print(f"MATCH #{index}")
        print("-" * 100)

        print("\nSEGMENT A")
        print(f"Name : {segment_a.get('name', '(No name)')}")
        print(f"ID   : {segment_a.get('id', '(No ID)')}")
        print(f"Dashboard usage : {usage_a['count']} (shared/published: {usage_a['sharedPublishedCount']})")

        print("\nSEGMENT B")
        print(f"Name : {segment_b.get('name', '(No name)')}")
        print(f"ID   : {segment_b.get('id', '(No ID)')}")
        print(f"Dashboard usage : {usage_b['count']} (shared/published: {usage_b['sharedPublishedCount']})")

        print("\nANALYSIS")
        print(f"Match Type   : {match['type']}")
        print(f"Similarity   : {match['similarity']:.1f}%")

        only_a = match["diff"]["onlyA"]
        only_b = match["diff"]["onlyB"]

        print("\nKEY DIFFERENCES")
        print("Values only found in Segment A: " + (", ".join(only_a[:20]) if only_a else "None"))
        print("Values only found in Segment B: " + (", ".join(only_b[:20]) if only_b else "None"))

        print("\nDELETION RECOMMENDATION")
        print(f"  >>> {recommendation['text']}")
        print(f"      {recommendation['detail']}")

    print("\n" + "=" * 100)


# ============================================================
# 8. FILE EXPORTS
# ============================================================

def export_segment_csv(segments, path):
    import csv

    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(
            ["#", "Segment Name", "Segment ID", "Data View Name", "Owner", "Description", "Definition (JSON)"]
        )
        for idx, segment in enumerate(segments, start=1):
            writer.writerow(
                [
                    idx,
                    segment.get("name", "(No name)"),
                    segment.get("id", "(No ID)"),
                    get_data_view_name(segment),
                    get_owner_name(segment),
                    segment.get("description", ""),
                    json.dumps(segment.get("definition") or {}, ensure_ascii=False),
                ]
            )
    print(f"\nSegment list written to: {path}")


# NOTE: There is no export_comparison_excel() writing a physical .xlsx file.
# The comparison results are only ever produced on demand, in-browser, via
# the "Download Comparison Results (Excel)" button on the dashboard (see
# downloadComparisonExcel() in build_dashboard_html below). This avoids
# creating a duplicate file on every run that the user may never open.


# ============================================================
# 9. HTML ESCAPE HELPER
# ============================================================

def esc(value):
    text = "" if value is None else str(value)
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;")
    )


# ============================================================
# 10. CLIENT-FRIENDLY HTML DASHBOARD
# ============================================================
# The CSS and JS live in plain (non-f) strings so they can use { } freely -
# only the surrounding HTML skeleton is an f-string, and it contains no
# literal braces of its own.

# Per-match recommendation colour, keyed by the bucket that
# get_recommendation_bucket() already derives from the recommendation text.
REC_CLASS_BY_BUCKET = {
    "cleanup": "recommend-delete",
    "review": "recommend-review",
    "keep": "recommend-keep",
    "unknown": "recommend-review",
}

# A near-duplicate pair can differ by hundreds of tokens. The table shows the
# first N so a row stays readable; the Excel export always carries the full
# list for anyone who needs to audit the whole difference.
DIFF_DISPLAY_LIMIT = 30

DASHBOARD_CSS = """
:root {
  --bg:#f4f7fb; --card:#fff; --text:#172033; --muted:#687386;
  --border:#dfe5ee; --accent:#315efb; --green:#137a4b;
  --greenbg:#e8f7ef; --amber:#996c00; --amberbg:#fff5d9;
  --blue:#1e5bd6; --bluebg:#eaf1ff;
}
* { box-sizing:border-box; }
body { margin:0; font-family:Segoe UI,Arial,sans-serif; background:var(--bg); color:var(--text); }
.container { max-width:1500px; margin:0 auto; padding:32px; }
.header { margin-bottom:24px; }
h1 { margin:0 0 8px; font-size:28px; }
.subtitle { color:var(--muted); font-size:15px; }
.meta { margin-top:10px; color:var(--muted); font-size:13px; }
.toolbar { display:flex; gap:12px; flex-wrap:wrap; margin-top:18px; }
.toolbar button {
  display:inline-flex; align-items:center; gap:6px;
  background:var(--accent); color:#fff; border:0; cursor:pointer;
  font-family:inherit; padding:10px 16px; border-radius:8px; font-size:13px; font-weight:600;
}
.toolbar button.secondary { background:var(--green); }
.toolbar a.change-view {
  display:inline-flex; align-items:center; gap:6px; text-decoration:none;
  background:#5a6575; color:#fff; padding:10px 16px; border-radius:8px;
  font-size:13px; font-weight:600;
}
.toolbar button:hover { opacity:.9; }
.toolbar a.change-view:hover { opacity:.9; }
.cards { display:flex; flex-wrap:wrap; gap:16px; margin:24px 0; }
.card { background:var(--card); border:1px solid var(--border); border-radius:14px; padding:18px; box-shadow:0 2px 8px rgba(30,50,80,.04); flex:1 1 190px; }
.card .label { color:var(--muted); font-size:12.5px; }
.card .value { font-size:27px; font-weight:700; margin-top:6px; }
.card .value.exact-value { color:#c62828; }
.card .value.near-value { color:#ef6c00; }
.section { background:var(--card); border:1px solid var(--border); border-radius:14px; padding:22px; margin-top:20px; }
.section h2 { margin:0 0 15px; font-size:20px; }
.section.highlight { background:#fbfcfe; border:1px solid var(--border); }
.table-wrap { overflow-x:auto; }
table { width:100%; border-collapse:collapse; font-size:13px; }
th { text-align:left; background:#f7f9fc; color:#4d586a; padding:12px; border-bottom:2px solid var(--border); white-space:nowrap; }
td { padding:14px 12px; border-bottom:1px solid var(--border); vertical-align:top; line-height:1.45; }
.muted { color:var(--muted); font-size:11px; word-break:break-all; }
.score { font-weight:700; font-size:16px; }
.badge { display:inline-block; padding:6px 9px; border-radius:999px; font-size:11px; font-weight:700; white-space:nowrap; }
.badge.strong { background:var(--greenbg); color:var(--green); }
.badge.review { background:var(--amberbg); color:var(--amber); }
.badge.keep { background:var(--bluebg); color:var(--blue); }
.badge.exact { background:#fdecec; color:#c62828; }
.badge.near { background:#fff3e0; color:#ef6c00; }
.usage-badge { display:inline-block; padding:3px 8px; margin:2px 0; border-radius:6px; background:#f1f4f9; color:#3c4658; font-size:11.5px; }
.usage-note { color:var(--muted); font-size:11.5px; margin-top:6px; }
.empty { padding:30px; text-align:center; color:var(--muted); background:#f8fafc; border-radius:10px; }
.note { color:var(--muted); font-size:13px; line-height:1.6; }
.duplicate-groups-section { margin-top:4px; }
.duplicate-groups-section h3 { margin-bottom:4px; margin-top:22px; }
.group-subtitle { color:var(--muted); font-size:13px; margin-bottom:6px; }
.group-table td { vertical-align:top; }
.group-segment-name { display:block; padding:2px 0; }
.recommend-delete { color:#c62828; font-weight:700; }
.recommend-keep { color:#2e7d32; font-weight:700; }
.recommend-review { color:#ef6c00; font-weight:700; }

/* Collapsible section headers */
h2.card-header-row { display:flex; align-items:center; justify-content:space-between; gap:10px; cursor:pointer; user-select:none; }
h2.card-header-row:hover { color:var(--accent); }
.collapse-toggle { font-size:12.5px; font-weight:600; color:#4d586a; border:1px solid var(--border); border-radius:6px; padding:3px 10px; background:#f7f9fc; white-space:nowrap; }
.collapsible-body.collapsed { display:none; }

/* Per-section toolbar: search, rows-per-page, actions */
.table-toolbar { display:flex; align-items:flex-end; justify-content:space-between; gap:14px; flex-wrap:wrap; margin-bottom:14px; }
.search-box { flex:1 1 340px; }
.search-box input { width:100%; padding:9px 12px; border:1px solid var(--border); border-radius:8px; font-size:13px; font-family:inherit; }
.page-size-control { display:flex; align-items:center; gap:8px; }
.page-size-control label { font-size:12.5px; color:var(--muted); white-space:nowrap; }
.page-size-control select { padding:9px 10px; border:1px solid var(--border); border-radius:8px; font-size:13px; font-family:inherit; background:#fff; }
.btn { border:0; cursor:pointer; font-family:inherit; font-size:12.5px; font-weight:600; padding:9px 14px; border-radius:8px; color:#fff; background:var(--accent); }
.btn:hover { opacity:.9; }
.btn.grey { background:#5a6575; }
.btn.green { background:var(--green); }

/* Numbered pagination */
.pagination { display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; margin-top:14px; }
.pagination-info { color:var(--muted); font-size:12.5px; }
.pagination-buttons { display:flex; gap:5px; flex-wrap:wrap; }
.pagination-buttons button { background:#fff; border:1px solid var(--border); color:var(--text); padding:7px 12px; border-radius:7px; font-size:12.5px; font-family:inherit; cursor:pointer; }
.pagination-buttons button:hover:not(:disabled) { background:#f0f4fb; }
.pagination-buttons button.active { background:var(--accent); border-color:var(--accent); color:#fff; }
.pagination-buttons button:disabled { color:#b7bfcc; cursor:not-allowed; }

/* Long segment names / difference lists wrap instead of forcing the wide
   tables into a horizontal scrollbar. */
table.fixed { table-layout:fixed; }
table.fixed th, table.fixed td { white-space:normal; overflow-wrap:anywhere; word-break:break-word; }

@media(max-width:1100px) {
  .card { flex-basis:45%; }
}
@media(max-width:600px) {
  .container { padding:16px; }
  .card { flex-basis:100%; }
  table.fixed th, table.fixed td { padding:8px 6px; font-size:12px; }
}
"""

DASHBOARD_JS = """
// --- Shared helpers -------------------------------------------------

function escapeHtmlJs(value) {
    const div = document.createElement("div");
    div.textContent = String(value ?? "");
    return div.innerHTML;
}

function csvEscape(value) {
    return '"' + String(value ?? "").replace(/"/g, '""') + '"';
}

function xmlEscape(value) {
    return String(value ?? "")
        .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

function xmlCell(value) {
    return `<Cell><Data ss:Type="String">${xmlEscape(value)}</Data></Cell>`;
}

function timestamp() {
    return new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
}

function downloadBlob(content, filename, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
}

// SpreadsheetML 2003 opens straight into Excel and needs no JS library, so
// the dashboard stays a single self-contained file.
function downloadWorkbook(sheetName, header, rows, filenamePrefix) {
    const body = rows.map(row => `<Row>${row.map(xmlCell).join("")}</Row>`).join("");
    const xml = `<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
<Worksheet ss:Name="${xmlEscape(sheetName)}">
<Table>
<Row>${header.map(xmlCell).join("")}</Row>
${body}
</Table>
</Worksheet>
</Workbook>`;
    downloadBlob(xml, filenamePrefix + timestamp() + ".xls", "application/vnd.ms-excel");
}

function toggleSection(sectionId) {
    const body = document.getElementById(sectionId + "-body");
    const icon = document.getElementById(sectionId + "-icon");
    if (!body) return;
    const collapsed = body.classList.toggle("collapsed");
    if (icon) icon.textContent = collapsed ? "\\u25B8 Expand" : "\\u25BE Collapse";
}

function renderPagination(containerId, page, totalPages, totalItems, startIndex, visibleCount, callbackName) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const from = totalItems ? startIndex + 1 : 0;
    const to = startIndex + visibleCount;

    const buttons = [
        `<button ${page <= 1 ? "disabled" : ""} onclick="${callbackName}(${page - 1})">Previous</button>`
    ];

    const maxButtons = 7;
    const last = Math.min(totalPages, Math.max(1, page - 3) + maxButtons - 1);
    const first = Math.max(1, last - maxButtons + 1);

    for (let p = first; p <= last; p++) {
        buttons.push(`<button class="${p === page ? "active" : ""}" onclick="${callbackName}(${p})">${p}</button>`);
    }

    buttons.push(`<button ${page >= totalPages ? "disabled" : ""} onclick="${callbackName}(${page + 1})">Next</button>`);

    container.innerHTML =
        `<div class="pagination-info">Showing ${from}-${to} of ${totalItems}</div>` +
        `<div class="pagination-buttons">${buttons.join("")}</div>`;
}

// --- Available CJA segments ----------------------------------------

const segmentState = { filtered: SEGMENTS_DATA.slice(), page: 1, pageSize: 10 };

function renderSegmentPage() {
    const total = segmentState.filtered.length;
    const totalPages = Math.max(1, Math.ceil(total / segmentState.pageSize));
    if (segmentState.page > totalPages) segmentState.page = totalPages;

    const start = (segmentState.page - 1) * segmentState.pageSize;
    const pageItems = segmentState.filtered.slice(start, start + segmentState.pageSize);

    document.getElementById("segmentBody").innerHTML = total === 0
        ? '<tr><td colspan="5"><div class="empty">No segments match this search.</div></td></tr>'
        : pageItems.map((s, i) => `<tr>
            <td>${start + i + 1}</td>
            <td><b>${escapeHtmlJs(s.name)}</b><div class="muted">${escapeHtmlJs(s.id)}</div></td>
            <td>${escapeHtmlJs(s.dataView)}</td>
            <td>${escapeHtmlJs(s.owner)}</td>
            <td>${escapeHtmlJs(s.description || "-")}</td>
          </tr>`).join("");

    renderPagination("segmentPagination", segmentState.page, totalPages, total,
                     start, pageItems.length, "gotoSegmentPage");
}

function gotoSegmentPage(page) {
    segmentState.page = page;
    renderSegmentPage();
}

function filterSegments() {
    const search = (document.getElementById("segmentSearch").value || "").trim().toLowerCase();
    segmentState.filtered = SEGMENTS_DATA.filter(s => String(s.name || "").toLowerCase().includes(search));
    segmentState.page = 1;
    renderSegmentPage();
}

function clearSegmentSearch() {
    document.getElementById("segmentSearch").value = "";
    filterSegments();
}

function changeSegmentPageSize() {
    segmentState.pageSize = Number(document.getElementById("segmentPageSize").value) || 10;
    segmentState.page = 1;
    renderSegmentPage();
}

function downloadSegmentsExcel() {
    if (!segmentState.filtered.length) {
        alert("There is no segment data available to download.");
        return;
    }
    downloadWorkbook(
        "Available Segments",
        ["Segment Name", "Segment ID", "Data View Name", "Owner", "Description"],
        segmentState.filtered.map(s => [s.name, s.id, s.dataView, s.owner, s.description]),
        "CJA_Available_Segments_"
    );
}

// --- Duplicate / near-duplicate comparison --------------------------

const comparisonState = { filtered: MATCHES_DATA.slice(), page: 1, pageSize: 10 };

function renderComparisonPage() {
    const total = comparisonState.filtered.length;
    const totalPages = Math.max(1, Math.ceil(total / comparisonState.pageSize));
    if (comparisonState.page > totalPages) comparisonState.page = totalPages;

    const start = (comparisonState.page - 1) * comparisonState.pageSize;
    const pageItems = comparisonState.filtered.slice(start, start + comparisonState.pageSize);

    document.getElementById("comparisonBody").innerHTML = total === 0
        ? '<tr><td colspan="8"><div class="empty">No duplicate or near-duplicate segments were identified.</div></td></tr>'
        : pageItems.map((m, i) => `<tr>
            <td>${start + i + 1}</td>
            <td><span class="badge ${m.type === "Exact duplicate" ? "exact" : "near"}">${escapeHtmlJs(m.type)}</span></td>
            <td><span class="score">${m.similarity.toFixed(1)}%</span></td>
            <td><b>${escapeHtmlJs(m.aName)}</b><div class="muted">${escapeHtmlJs(m.aId)}</div></td>
            <td><b>${escapeHtmlJs(m.bName)}</b><div class="muted">${escapeHtmlJs(m.bId)}</div></td>
            <td>
              <span class="usage-badge">A: <b>${m.aCount}</b> dashboard(s)</span><br>
              <span class="usage-badge">B: <b>${m.bCount}</b> dashboard(s)</span><br>
              <span class="usage-badge">A shared/published: <b>${m.aShared}</b></span><br>
              <span class="usage-badge">B shared/published: <b>${m.bShared}</b></span>
            </td>
            <td>
              <span class="${m.recClass}">${escapeHtmlJs(m.recText)}</span>
              <div class="usage-note">${escapeHtmlJs(m.recDetail)}</div>
            </td>
            <td>
              <b>Only in A:</b> ${escapeHtmlJs(m.onlyADisplay || "None")}
              <br><br>
              <b>Only in B:</b> ${escapeHtmlJs(m.onlyBDisplay || "None")}
            </td>
          </tr>`).join("");

    renderPagination("comparisonPagination", comparisonState.page, totalPages, total,
                     start, pageItems.length, "gotoComparisonPage");
}

function gotoComparisonPage(page) {
    comparisonState.page = page;
    renderComparisonPage();
}

function filterComparisonResults() {
    const search = (document.getElementById("comparisonSearch").value || "").trim().toLowerCase();
    comparisonState.filtered = MATCHES_DATA.filter(m =>
        String(m.aName || "").toLowerCase().includes(search) ||
        String(m.bName || "").toLowerCase().includes(search)
    );
    comparisonState.page = 1;
    renderComparisonPage();
}

function clearComparisonSearch() {
    document.getElementById("comparisonSearch").value = "";
    filterComparisonResults();
}

function changeComparisonPageSize() {
    comparisonState.pageSize = Number(document.getElementById("comparisonPageSize").value) || 10;
    comparisonState.page = 1;
    renderComparisonPage();
}

function comparisonRows(matches) {
    return matches.map(m => [
        m.type, m.similarity.toFixed(1), m.aName, m.aId, m.aCount, m.aShared,
        m.bName, m.bId, m.bCount, m.bShared, m.recText, m.recDetail, m.onlyA, m.onlyB,
    ]);
}

const COMPARISON_HEADER = [
    "Type", "Similarity (%)", "Segment A Name", "Segment A ID",
    "Segment A Dashboard Count", "Segment A Shared/Published Count",
    "Segment B Name", "Segment B ID", "Segment B Dashboard Count",
    "Segment B Shared/Published Count", "Deletion Recommendation",
    "Recommendation Detail", "Only in A", "Only in B",
];

function downloadComparisonExcel(matches) {
    const rows = matches || MATCHES_DATA;
    if (!rows.length) {
        alert("There is no comparison data available to download.");
        return;
    }
    downloadWorkbook("Comparison Results", COMPARISON_HEADER, comparisonRows(rows),
                     "CJA_Segment_Comparison_");
}

function downloadFilteredComparisonExcel() {
    downloadComparisonExcel(comparisonState.filtered);
}

// --- Full segment list (includes the definition JSON, which the Excel
// --- export above deliberately leaves out to stay readable) ----------

function downloadSegmentsCsv() {
    const header = ["#", "Segment Name", "Segment ID", "Data View Name", "Owner", "Description", "Definition (JSON)"]
        .map(csvEscape).join(",");

    const rows = SEGMENTS_DATA.map((s, i) =>
        [i + 1, s.name, s.id, s.dataView, s.owner, s.description, s.definition].map(csvEscape).join(",")
    );

    downloadBlob(header + "\\n" + rows.join("\\n") + "\\n",
                 "CJA_Segment_List_" + timestamp() + ".csv", "text/csv;charset=utf-8;");
}

renderSegmentPage();
renderComparisonPage();
"""


def build_dashboard_html(
    segments,
    matches,
    usage_map,
    usage_loaded,
    threshold,
    segment_csv_filename,
    scope_label="All Data Views",
):
    total_segments = len(segments)

    # Data embedded directly in the page so the downloads, search and
    # pagination all work purely in-browser, regardless of how many segments
    # there are or where the HTML file is opened from. This avoids the
    # file:// "download" attribute restriction that browsers apply to plain
    # links pointing at local files, and lets both big tables render a page
    # at a time instead of as one giant static table.
    segments_for_js = [
        {
            "name": s.get("name", "(No name)"),
            "id": s.get("id", "(No ID)"),
            "dataView": get_data_view_name(s),
            "owner": get_owner_name(s),
            "description": s.get("description", "") or "",
            "definition": json.dumps(s.get("definition") or {}, ensure_ascii=False),
        }
        for s in segments
    ]

    matches_for_js = []

    for match in matches:
        a, b = match["a"], match["b"]
        usage_a = get_segment_usage(usage_map, a)
        usage_b = get_segment_usage(usage_map, b)
        recommendation = get_deletion_recommendation(match, usage_map, usage_loaded)
        bucket = get_recommendation_bucket(recommendation["text"])

        only_a = match["diff"]["onlyA"]
        only_b = match["diff"]["onlyB"]

        matches_for_js.append(
            {
                "type": match["type"],
                "similarity": round(match["similarity"], 1),
                "aName": a.get("name", ""),
                "aId": a.get("id", ""),
                "aCount": usage_a["count"],
                "aShared": usage_a["sharedPublishedCount"],
                "bName": b.get("name", ""),
                "bId": b.get("id", ""),
                "bCount": usage_b["count"],
                "bShared": usage_b["sharedPublishedCount"],
                "recText": recommendation["text"],
                "recDetail": recommendation["detail"],
                "recClass": REC_CLASS_BY_BUCKET[bucket],
                "onlyA": ", ".join(only_a),
                "onlyB": ", ".join(only_b),
                "onlyADisplay": ", ".join(only_a[:DIFF_DISPLAY_LIMIT]),
                "onlyBDisplay": ", ".join(only_b[:DIFF_DISPLAY_LIMIT]),
                "bucket": bucket,
            }
        )

    # Scorecards show the count of DISTINCT segments involved in each
    # duplicate type, not the number of pairwise comparison rows - same as
    # countDistinctSegmentsInMatches() in the HTML tool. A segment that
    # appears in several duplicate pairs is only counted once, and a
    # segment can count toward both "exact" and "near" if it has both.
    exact_distinct_count = count_distinct_segments_in_matches(matches, "Exact duplicate")
    near_distinct_count = count_distinct_segments_in_matches(matches, "Near duplicate")

    # Duplicate "clusters" via connected components - same grouping logic
    # as the HTML tool: if A=B and B=C, A, B and C are shown as one group
    # instead of two separate pairwise rows.
    exact_groups = build_duplicate_groups(matches, "Exact duplicate")
    near_groups = build_duplicate_groups(matches, "Near duplicate")
    exact_group_rows_html = render_duplicate_group_rows(exact_groups, True, usage_map, usage_loaded)
    near_group_rows_html = render_duplicate_group_rows(near_groups, False, usage_map, usage_loaded)

    usage_status = (
        "Loaded successfully"
        if usage_loaded
        else "Could not be verified this run (recommendations default to Review)"
    )
    generated = datetime.now().strftime("%d %b %Y, %I:%M %p")

    def js_safe(data):
        # Prevent a literal "</script>" inside embedded JSON from closing
        # the surrounding <script> tag early.
        return json.dumps(data, ensure_ascii=False).replace("</", "<\\/")

    segments_json = js_safe(segments_for_js)
    matches_json = js_safe(matches_for_js)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CJA Segment Cleanup Dashboard</title>
<style>{DASHBOARD_CSS}</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>CJA Segment Cleanup Dashboard</h1>
    <div class="subtitle">Duplicate and near-duplicate segment analysis, cross-checked against live workspace dashboard usage</div>
    <div class="meta">
      Generated: {generated} &nbsp; | &nbsp; Scope: {esc(scope_label)} &nbsp; | &nbsp;
      Segments analyzed: {total_segments} &nbsp; | &nbsp;
      Similarity threshold: {threshold:.0f}% &nbsp; | &nbsp; Workspace usage: {usage_status}
    </div>
    <div class="toolbar">
      <a class="change-view" href="/">&#8592; Change Data View</a>
      <button onclick="downloadSegmentsCsv()">&#11015; Download Full Segment List (CSV)</button>
      <button class="secondary" onclick="downloadComparisonExcel()">&#11015; Download Comparison Results (Excel)</button>
    </div>
  </div>

  <div class="section highlight">
    <h2>CJA Segment Summary</h2>
    <div class="cards">
      <div class="card"><div class="label">Total segments</div><div class="value">{total_segments}</div></div>
      <div class="card"><div class="label">Exact duplicates</div><div class="value exact-value">{exact_distinct_count}</div></div>
      <div class="card"><div class="label">Near duplicates</div><div class="value near-value">{near_distinct_count}</div></div>
    </div>

    <div class="duplicate-groups-section">
      <h3>Exact Duplicate Groups</h3>
      <div class="group-subtitle">
        Segments chained together through exact-duplicate matches are grouped into a single row
        (e.g. if A = B and B = C, then A, B and C appear together).
      </div>
      <div class="table-wrap">
        <table class="group-table">
          <thead>
            <tr>
              <th style="width:5%">#</th>
              <th style="width:35%">Segment Names</th>
              <th style="width:20%">Data View Name</th>
              <th style="width:40%">Deletion Recommendation</th>
            </tr>
          </thead>
          <tbody>{exact_group_rows_html}</tbody>
        </table>
      </div>

      <h3>Near-Duplicate Groups</h3>
      <div class="group-subtitle">
        Same grouping logic applied to near-duplicate matches (based on the similarity threshold).
      </div>
      <div class="table-wrap">
        <table class="group-table">
          <thead>
            <tr>
              <th style="width:5%">#</th>
              <th style="width:35%">Segment Names</th>
              <th style="width:20%">Data View Name</th>
              <th style="width:40%">Deletion Recommendation</th>
            </tr>
          </thead>
          <tbody>{near_group_rows_html}</tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="section">
    <h2 class="card-header-row" onclick="toggleSection('segmentsCard')">
      <span>Available CJA Segments</span>
      <span class="collapse-toggle" id="segmentsCard-icon">&#9656; Expand</span>
    </h2>
    <div class="collapsible-body collapsed" id="segmentsCard-body">
      <div class="table-toolbar">
        <div class="search-box">
          <input id="segmentSearch" type="text" placeholder="Search by segment name..." oninput="filterSegments()">
        </div>
        <div class="page-size-control">
          <label for="segmentPageSize">Rows per page</label>
          <select id="segmentPageSize" onchange="changeSegmentPageSize()">
            <option value="10" selected>10</option>
            <option value="20">20</option>
            <option value="30">30</option>
            <option value="40">40</option>
            <option value="50">50</option>
            <option value="100">100</option>
          </select>
        </div>
        <button class="btn grey" onclick="clearSegmentSearch()">Clear Search</button>
        <button class="btn green" onclick="downloadSegmentsExcel()">Download Excel</button>
      </div>
      <div class="table-wrap">
        <table class="fixed">
          <thead>
            <tr>
              <th style="width:5%">#</th>
              <th style="width:27%">Segment Name</th>
              <th style="width:18%">Data View Name</th>
              <th style="width:17%">Owner</th>
              <th style="width:33%">Description</th>
            </tr>
          </thead>
          <tbody id="segmentBody"></tbody>
        </table>
      </div>
      <div class="pagination" id="segmentPagination"></div>
    </div>
  </div>

  <div class="section">
    <h2 class="card-header-row" onclick="toggleSection('comparisonCard')">
      <span>Duplicate / Near-Duplicate Segments</span>
      <span class="collapse-toggle" id="comparisonCard-icon">&#9656; Expand</span>
    </h2>
    <div class="collapsible-body collapsed" id="comparisonCard-body">
      <div class="table-toolbar">
        <div class="search-box">
          <input id="comparisonSearch" type="text" placeholder="Search comparison results by segment name..." oninput="filterComparisonResults()">
        </div>
        <div class="page-size-control">
          <label for="comparisonPageSize">Rows per page</label>
          <select id="comparisonPageSize" onchange="changeComparisonPageSize()">
            <option value="10" selected>10</option>
            <option value="20">20</option>
            <option value="30">30</option>
            <option value="40">40</option>
            <option value="50">50</option>
            <option value="100">100</option>
          </select>
        </div>
        <button class="btn grey" onclick="clearComparisonSearch()">Clear Search</button>
        <button class="btn green" onclick="downloadFilteredComparisonExcel()">Download Excel</button>
      </div>
      <div class="table-wrap">
        <table class="fixed">
          <thead>
            <tr>
              <th style="width:5%">#</th>
              <th style="width:11%">Type</th>
              <th style="width:8%">Similarity</th>
              <th style="width:15%">Segment A</th>
              <th style="width:15%">Segment B</th>
              <th style="width:14%">Workspace Dashboard Usage</th>
              <th style="width:15%">Deletion Recommendation</th>
              <th style="width:17%">Differences</th>
            </tr>
          </thead>
          <tbody id="comparisonBody"></tbody>
        </table>
      </div>
      <div class="pagination" id="comparisonPagination"></div>
    </div>
  </div>

  <div class="section">
    <h2>Reviewing the full segment library</h2>
    <p class="note">
      "Available CJA Segments" above lists every segment pulled from CJA, including ones with no
      duplicate match. Its Excel download covers the rows currently shown by the search filter.
      For a full offline review that also includes each segment's <b>definition JSON</b>, use the
      "Download Full Segment List (CSV)" button at the top of the page.
    </p>
  </div>
</div>

<script>
const SEGMENTS_DATA = {segments_json};
const MATCHES_DATA = {matches_json};
</script>
<script>{DASHBOARD_JS}</script>

</body>
</html>"""


def export_dashboard_html(html_content, path):
    with open(path, "w", encoding="utf-8") as f:
        f.write(html_content)


# ============================================================
# 11. RUN PIPELINE (shared by the CLI below and app.py)
# ============================================================

def run_pipeline(creds, threshold=85.0, output_dir=None, verbose=False, dataview_selection="prompt", segments=None):
    """Runs the full segment-cleanup analysis for one org/market and
    writes the segment CSV + dashboard HTML. Returns a small summary
    dict describing what happened, so a caller (CLI or web UI) can
    report it without needing to know the internals.

    creds: {"api_key": ..., "org_id": ..., "access_token": ...}
    dataview_selection: "prompt" (ask via a form/console menu - default),
        "all" (compare across every data view, no filter), or a specific
        data view name/id to filter to non-interactively.
    segments: pass an already-fetched segment list to skip re-fetching
        from CJA (e.g. the web form fetches once to populate the data
        view dropdown, then hands that same list to run_pipeline instead
        of both requests fetching independently). Leave as None for the
        normal "fetch fresh every time" behavior.
    """
    output_dir = output_dir or OUTPUT_DIR
    segment_csv_path = os.path.join(output_dir, "CJA_Segment_List.csv")
    dashboard_html_path = os.path.join(output_dir, "CJA_Segment_Cleanup_Dashboard.html")

    if verbose:
        print("CJA Segment Finder Started")
        print("Run time:", datetime.now().strftime("%d %b %Y, %I:%M %p"))
        print("Near-duplicate threshold:", threshold)

    if segments is None:
        all_segments = get_segments(creds, verbose=verbose)
        print(f"Segments fetched: {len(all_segments)}")
    else:
        all_segments = segments
        print(f"Using {len(all_segments)} already-fetched segment(s).")

    if not all_segments:
        print("Connected successfully, but no segments were returned.")
        return {
            "segment_count": 0,
            "match_count": 0,
            "usage_loaded": False,
            "segment_csv_path": None,
            "dashboard_html_path": None,
        }

    dataviews = get_distinct_dataviews(all_segments)
    selected_dataview_id, selected_dataview_label = resolve_dataview_selection(dataviews, dataview_selection)

    if selected_dataview_id is None:
        segments = all_segments
        print(f"Comparing across: {selected_dataview_label} ({len(segments)} segment(s)).")
    else:
        segments = [
            s for s in all_segments
            if (get_data_view_id(s) or get_data_view_name(s)) == selected_dataview_id
        ]
        print(f"Comparing within data view: {selected_dataview_label} ({len(segments)} of {len(all_segments)} segment(s)).")

    if not segments:
        print("No segments matched the selected data view.")
        return {
            "segment_count": 0,
            "match_count": 0,
            "usage_loaded": False,
            "segment_csv_path": None,
            "dashboard_html_path": None,
        }

    export_segment_csv(segments, segment_csv_path)

    usage_map, usage_loaded = load_workspace_usage(segments, creds, verbose=verbose)
    if usage_loaded:
        used_count = sum(1 for s in segments if get_segment_usage(usage_map, s)["count"] > 0)
        print(f"Workspace usage loaded: {used_count} of {len(segments)} segments are referenced by at least one dashboard.")
    else:
        print("Workspace usage could not be loaded (recommendations default to 'Review').")

    matches = find_duplicate_segments(segments, threshold=threshold, verbose=verbose)

    display_cleanup_analysis(matches, len(segments), usage_map, usage_loaded, verbose=verbose)

    dashboard_html = build_dashboard_html(
        segments,
        matches,
        usage_map,
        usage_loaded,
        threshold,
        segment_csv_filename=os.path.basename(segment_csv_path),
        scope_label=selected_dataview_label,
    )
    export_dashboard_html(dashboard_html, dashboard_html_path)
    print(f"Dashboard ready: {dashboard_html_path}")

    return {
        "segment_count": len(segments),
        "match_count": len(matches),
        "exact_count": sum(1 for m in matches if m["type"] == "Exact duplicate"),
        "near_count": sum(1 for m in matches if m["type"] == "Near duplicate"),
        "usage_loaded": usage_loaded,
        "segment_csv_path": segment_csv_path,
        "dashboard_html_path": dashboard_html_path,
        "dashboard_html": dashboard_html,
    }


# ============================================================
# 12. CLI ENTRY POINT (terminal / VS Code use)
# ============================================================

def validate_config():
    """Checks .env has enough to actually run before we make any API calls,
    so a typo shows up as one clear message up front instead of a confusing
    failure three functions deep. Doesn't check the values are *correct* -
    just that something was provided."""
    missing = []

    if not os.getenv("CJA_API_KEY"):
        missing.append("CJA_API_KEY")
    if not os.getenv("CJA_ORG_ID"):
        missing.append("CJA_ORG_ID")

    has_auto_refresh_setup = os.getenv("CJA_CLIENT_SECRET") and os.getenv("CJA_SCOPES")
    has_manual_token = os.getenv("CJA_ACCESS_TOKEN")
    if not has_auto_refresh_setup and not has_manual_token:
        missing.append("CJA_CLIENT_SECRET + CJA_SCOPES (recommended), or CJA_ACCESS_TOKEN")

    if missing:
        raise RuntimeError(
            "Missing required .env setting(s): " + "; ".join(missing) + ". "
            "See the setup notes at the top of this file for what each one should be."
        )


def resolve_access_token(client_id, verbose=False):
    """Automatic (preferred): if CJA_CLIENT_SECRET + CJA_SCOPES are set,
    fetch/cache a token via OAuth Server-to-Server - no manual step.
    Manual (fallback): otherwise use CJA_ACCESS_TOKEN as-is, same as before."""
    client_secret = os.getenv("CJA_CLIENT_SECRET")
    scopes = os.getenv("CJA_SCOPES")

    if client_secret and scopes:
        return get_access_token(client_id, client_secret, scopes, verbose=verbose)

    manual_token = os.getenv("CJA_ACCESS_TOKEN")
    if manual_token:
        if verbose:
            print("CJA_CLIENT_SECRET/CJA_SCOPES not set - using manually provided CJA_ACCESS_TOKEN.")
        return manual_token

    raise RuntimeError(
        "No access token available. Either set CJA_CLIENT_SECRET and CJA_SCOPES in .env "
        "for automatic token refresh, or set CJA_ACCESS_TOKEN manually."
    )


def main():
    validate_config()

    client_id = os.getenv("CJA_API_KEY")
    threshold = float(os.getenv("CJA_NEAR_DUPLICATE_THRESHOLD", "85"))
    verbose = os.getenv("CJA_VERBOSE", "0") == "1"
    # "prompt" (default) shows a data-view picker (a form window, falling
    # back to a console menu if a GUI can't be shown) listing every data
    # view found among your segments. Set CJA_DATAVIEW_ID=all in .env to
    # always compare everything with no prompt, or CJA_DATAVIEW_ID=<name
    # or id> to always scope to one specific data view non-interactively
    # (e.g. for an unattended run).
    dataview_selection = os.getenv("CJA_DATAVIEW_ID", "prompt")

    access_token = resolve_access_token(client_id, verbose=verbose)

    creds = {
        "api_key": client_id,
        "org_id": os.getenv("CJA_ORG_ID"),
        "access_token": access_token,
    }

    result = run_pipeline(
        creds,
        threshold=threshold,
        output_dir=OUTPUT_DIR,
        verbose=verbose,
        dataview_selection=dataview_selection,
    )

    if result["dashboard_html_path"]:
        dashboard_url = "file://" + os.path.abspath(result["dashboard_html_path"])
        print("Opening dashboard in your browser...")
        webbrowser.open(dashboard_url)


if __name__ == "__main__":
    main()
