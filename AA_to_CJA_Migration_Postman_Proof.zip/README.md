# AA to CJA Segment Migration - Postman Proof

This package is prepared for the completed **Last 14 days** Adobe Analytics to CJA migration POC.

## Files

- `AA_to_CJA_Segment_Migration_API_Proof.postman_collection.json`
- `AA_to_CJA_Migration_Proof_Local_Secrets.postman_environment.json`

## Import and run

1. Import both JSON files into Postman.
2. Select **AA to CJA Migration Proof - Local Secrets** as the environment.
3. Enter `client_id`, `client_secret`, `org_id` and `scopes` from the approved local `.env` file. Do not share or export the filled environment.
4. Run **00 - Generate Server-to-Server Access Token**.
5. Run folders **01**, **02** (only the completed-summary GET), **03** and **04** in order.
6. Open **Visualize** on **04.01 - Verify Copied Segment Share** to show the summary dashboard.

## Verified POC result

- Adobe migration status: **COMPLETED**
- Source Adobe Analytics project: **create metrics 1**
- Source segment: **Last 14 days**
- Target Data View: **CJA - MCP Analysis - SD**
- CJA migrated project ID: `6a96bd8c510564690d279f6f`
- Migrated project mapped: **1 metric, 5 segments, 2 dimensions and 6 calculated metrics**
- Unmapped items reported by the completed migration: **0**
- API-owned copied segment: **POC_SEG_CLEANUP_MIGRATION_Last 14 days - Shared Copy**
- Copied segment share: **one verified user; not shared to all**

## Important safety note

The request **02.02 - DO NOT RUN - Migration Submit (Protected Reference)** documents the payload used by the POC. It is blocked while `run_migration=false`, which is the correct default. Do not unlock it for this already-completed migration.

API-visible counts and UI-visible counts can differ because Adobe applies ownership, sharing, report-suite and product-profile access. A successful API response does not by itself mean that every component will appear in another user's UI.

No client secret or access token is stored in these exported files. The non-secret Adobe component IDs are included so the completed POC can be read back directly.
