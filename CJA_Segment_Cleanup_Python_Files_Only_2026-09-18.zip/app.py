"""
CJA Segment Finder - desktop browser application.

The Flask layer keeps Adobe credentials on the server, presents the same
data-view-first workflow as the standalone V5 HTML application, and delegates
all comparison, grouping, usage, recommendation, and export work to
cja_segment_finder.py.
"""

import logging
import os
import threading
import time
import webbrowser
from html import escape

from flask import Flask, jsonify, request

import cja_segment_finder as core

APP_DIR = os.path.dirname(os.path.abspath(__file__))
HOST = "127.0.0.1"
PORT = 5000
CACHE_TTL_SECONDS = 120

app = Flask(__name__)
logging.getLogger("werkzeug").setLevel(logging.WARNING)

_data_view_cache = {"items": None, "fetched_at": 0.0}
_segment_cache = {}
_cache_lock = threading.Lock()
_pipeline_lock = threading.Lock()

PAGE_STYLE = """
<style>
:root {
  --bg:#f4f7fb; --card:#fff; --text:#1d2939; --muted:#667085;
  --border:#d8e0ea; --accent:#4169f6; --accent-dark:#3158e6;
  --green:#2e7d32; --green-bg:#edf7ed; --red:#c62828; --red-bg:#fdecea;
}
* { box-sizing:border-box; }
body { margin:0; min-height:100vh; font-family:Arial,Helvetica,sans-serif; background:var(--bg); color:var(--text); }
.container { max-width:1400px; margin:0 auto; padding:70px 20px 44px; }
.panel { background:var(--card); padding:34px 20px; border-radius:8px; box-shadow:0 2px 9px rgba(0,0,0,.09); }
.panel h2 { margin:6px 0 20px; font-size:24px; }
.landing-shell { display:flex; justify-content:center; align-items:flex-start; min-height:100vh; padding:88px 24px 48px; }
.landing-card { width:100%; max-width:590px; padding:32px; border:1px solid #dde4ed; border-radius:12px; background:var(--card); box-shadow:0 4px 16px rgba(29,41,57,.08); }
.landing-card h1 { margin:0 0 5px; font-size:25px; line-height:1.25; font-weight:700; letter-spacing:-.2px; }
.landing-subtitle { margin:0 0 26px; color:var(--muted); font-size:14px; line-height:1.45; }
.field + .field { margin-top:18px; }
label { display:block; margin:0 0 7px; font-size:13px; line-height:1.3; font-weight:700; }
select, input { width:100%; height:42px; padding:9px 12px; border:1px solid var(--border); border-radius:7px; background:#fff; color:var(--text); font:14px Arial,Helvetica,sans-serif; }
select:focus, input:focus, button:focus-visible { outline:3px solid rgba(20,115,230,.22); outline-offset:1px; border-color:var(--accent); }
select:disabled { background:#f4f4f4; color:#999; }
.hint { margin-top:7px; color:var(--muted); font-size:12px; line-height:1.45; }
button { border:0; border-radius:7px; padding:11px 18px; font:600 14px Arial,Helvetica,sans-serif; cursor:pointer; }
button.primary { background:var(--accent); color:#fff; }
button.primary:hover:not(:disabled) { background:var(--accent-dark); }
button:disabled { opacity:.56; cursor:not-allowed; }
.generate-row { margin-top:23px; }
.generate-row .primary { width:100%; height:44px; }
.status { margin:0 0 18px; padding:0; font-size:13px; line-height:1.45; }
.status:empty { display:none; }
.status.error { padding:11px 13px; border-radius:5px; color:var(--red); background:var(--red-bg); }
.error-card { max-width:760px; margin:80px auto; }
a.back { display:inline-block; margin-top:18px; color:var(--accent); text-decoration:none; font-weight:600; }
</style>
"""


def get_creds():
    client_id = os.getenv("CJA_API_KEY")
    return {
        "api_key": client_id,
        "org_id": os.getenv("CJA_ORG_ID"),
        "access_token": core.resolve_access_token(client_id, verbose=False),
    }


def get_data_views_cached(creds):
    now = time.time()
    with _cache_lock:
        cached = _data_view_cache["items"]
        is_fresh = cached is not None and now - _data_view_cache["fetched_at"] < CACHE_TTL_SECONDS
        if is_fresh:
            return cached

    items = core.get_data_views(creds, verbose=False)
    with _cache_lock:
        _data_view_cache["items"] = items
        _data_view_cache["fetched_at"] = time.time()
    return items


def get_segments_cached(creds, data_view_id):
    cache_key = "ALL" if not data_view_id or str(data_view_id).upper() == "ALL" else str(data_view_id)
    now = time.time()
    with _cache_lock:
        cached = _segment_cache.get(cache_key)
        if cached and now - cached["fetched_at"] < CACHE_TTL_SECONDS:
            return cached["segments"]

    api_filter = None if cache_key == "ALL" else cache_key
    segments = core.get_segments(creds, data_view_id=api_filter, verbose=False)
    with _cache_lock:
        _segment_cache[cache_key] = {"segments": segments, "fetched_at": time.time()}
    return segments


@app.route("/", methods=["GET"])
def index():
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CJA Segment Cleanup</title>
{PAGE_STYLE}
</head>
<body>
<main class="landing-shell">
  <section class="landing-card" aria-labelledby="cleanupHeading">
    <h1 id="cleanupHeading">CJA Segment Cleanup</h1>
    <p class="landing-subtitle">Select a data view and generate the dashboard.</p>
    <div id="status" class="status" role="status" aria-live="polite"></div>

    <form id="reportForm" action="/generate" method="post">
      <div id="dataViewPanel">
        <div class="field">
        <label for="dataViewSelect">Data View</label>
        <select id="dataViewSelect" name="dataview_selection" disabled required>
          <option value="">Loading Data Views...</option>
        </select>
        </div>

        <div class="field">
        <label for="threshold">Similarity Threshold (%)</label>
        <input id="threshold" name="threshold" type="number" min="1" max="100" step="1" value="85">
        <div class="hint">Segments at or above this similarity are flagged as near-duplicates. 85 is a good default.</div>
        </div>

        <div class="generate-row">
          <button id="generateButton" class="primary" type="submit" disabled>Generate Dashboard</button>
        </div>
      </div>
    </form>
  </section>
</main>

<script>
const select = document.getElementById('dataViewSelect');
const generateButton = document.getElementById('generateButton');
const statusBox = document.getElementById('status');
const reportForm = document.getElementById('reportForm');

function setStatus(message, kind = '') {{
  statusBox.className = 'status' + (kind ? ' ' + kind : '');
  statusBox.textContent = message;
}}

async function loadDataViews() {{
  select.replaceChildren(new Option('Loading Data Views...', ''));
  select.disabled = true;
  generateButton.disabled = true;
  setStatus('');
  try {{
    const response = await fetch('/api/data-views', {{headers: {{'Accept':'application/json'}}}});
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || 'Unable to load Data Views.');

    select.replaceChildren(new Option('All Data Views', 'ALL'));
    for (const dataView of payload.dataViews || []) {{
      select.appendChild(new Option(dataView.name || dataView.id, String(dataView.id)));
    }}
    select.disabled = false;
    select.value = 'ALL';
    generateButton.disabled = false;
    setStatus('');
  }} catch (error) {{
    setStatus('ERROR: ' + error.message, 'error');
    select.replaceChildren(new Option('Unable to load Data Views', ''));
  }}
}}

select.addEventListener('change', () => {{
  const ready = Boolean(select.value);
  generateButton.disabled = !ready;
}});

reportForm.addEventListener('submit', event => {{
  if (!select.value) {{
    event.preventDefault();
    setStatus('Please select a Data View before generating the report.', 'error');
    select.focus();
    return;
  }}
  generateButton.disabled = true;
  generateButton.textContent = 'Generating...';
  setStatus('');
}});

loadDataViews();
</script>
</body>
</html>"""


@app.route("/api/data-views", methods=["GET"])
def api_data_views():
    try:
        creds = get_creds()
        data_views = get_data_views_cached(creds)
        clean_data_views = [
            {"id": str(item.get("id")), "name": str(item.get("name") or item.get("id"))}
            for item in data_views
            if isinstance(item, dict) and item.get("id")
        ]
        return jsonify({"dataViews": clean_data_views, "count": len(clean_data_views)})
    except Exception as error:
        print(f"ERROR loading data views: {error}")
        return jsonify({"error": "Could not connect to Adobe CJA or load the Data View list."}), 502


@app.route("/generate", methods=["POST"])
def generate():
    dataview_selection = (request.form.get("dataview_selection") or "").strip()
    if not dataview_selection:
        return error_page("Please select a Data View before generating the report.")

    try:
        threshold = float(request.form.get("threshold", "85"))
    except (TypeError, ValueError):
        threshold = 85.0
    threshold = min(100.0, max(1.0, threshold))

    try:
        creds = get_creds()
        segments = get_segments_cached(creds, dataview_selection)
    except Exception as error:
        print(f"ERROR resolving credentials/segments: {error}")
        return error_page("Could not authenticate with Adobe or fetch segments.", detail=str(error))

    print(f"\nGenerating dashboard (data view: {dataview_selection}, threshold={threshold:.0f}%)...")
    if _pipeline_lock.locked():
        print("Another dashboard is already generating - waiting for it to finish...")

    try:
        with _pipeline_lock:
            result = core.run_pipeline(
                creds,
                threshold=threshold,
                output_dir=APP_DIR,
                verbose=False,
                dataview_selection=dataview_selection,
                segments=segments,
            )
    except Exception as error:
        print(f"ERROR generating dashboard: {error}")
        return error_page("Something went wrong while generating the report.", detail=str(error))

    if not result.get("dashboard_html_path"):
        return error_page("Connected successfully, but no segments matched this selection.")

    print(f"Done: {result['segment_count']} segments, {result['match_count']} matches.")
    return result["dashboard_html"]


def error_page(message, detail=None):
    safe_message = escape(str(message))
    detail_html = f'<div class="hint" style="margin-top:10px;">{escape(str(detail))}</div>' if detail else ""
    return f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>CJA Segment Finder - Error</title>{PAGE_STYLE}</head>
<body><main class="container error-card"><section class="panel">
  <h1>Couldn\'t generate the report</h1>
  <div class="status error">{safe_message}{detail_html}</div>
  <a class="back" href="/">&larr; Back to Data Views</a>
</section></main></body></html>""", 400


def open_browser_when_ready():
    webbrowser.open(f"http://{HOST}:{PORT}")


if __name__ == "__main__":
    core.validate_config()
    print("Adobe CJA Segment Finder - Python App")
    print(f"Opening http://{HOST}:{PORT} in your browser...")
    threading.Timer(1.0, open_browser_when_ready).start()
    app.run(host=HOST, port=PORT, debug=False)
