# Verification — 28 October 2026

All eight observations are addressed in V4 and V5.

- 173 regression tests passed per version (346 total), with unmocked external HTTP blocked.
- Synthetic desktop browser checks passed for both products in both versions: searchable
  selectors, wheel/keyboard selection, return-link and browser-Back reset, group pagination,
  member expansion, empty scopes, product-specific approval/confirmation controls and
  provider failure recovery.
- Summary alignment was checked at 1440, 1280 and 1024 pixels. No mobile view was tested.
- Simulated deletion passed cancel, fresh preview, owner/confirmation checks, successful
  refresh, partial failure, pending outcomes and retaining one exact copy. No real Adobe
  segment was deleted.
- Nineteen comparison/usage/pipeline functions have unchanged syntax trees.
- All pairs, scores, full token differences and groups match the independent 26 October
  captured-data oracle: CJA 161 segments / 45 exact pairs / 11 near pairs; AA 1,828 segments /
  3,993 exact pairs / 1,378 near pairs. Thresholds 85, 90, 95 and 100 were checked.
  These are historical test counts, not current live inventory counts.
- Large-report browser checks used CJA - MCP Analysis - SD (133 captured segments)
  and AA Demo Data 7616 (1,722 captured segments / 5,334 flagged pairs).
- Downloaded CSV/SpreadsheetML files were parsed and checked for complete rows, pair IDs,
  scores, full differences, group membership and CJA-only approval columns.
- A current live read-only check loaded 6 CJA Data Views and 267 AA Report Suites.
  CJA fresh preflight passed for three current candidates while live deletion was disabled.
  Publication and outside dependencies still require owner review when metadata is missing.

Limitations: native Windows, native Microsoft Excel, organisation-wide dependency visibility,
audience equivalence, production load and actual Adobe DELETE permissions were not certified.
Live resource writes were forbidden. Stored captures and private browser evidence are excluded.
