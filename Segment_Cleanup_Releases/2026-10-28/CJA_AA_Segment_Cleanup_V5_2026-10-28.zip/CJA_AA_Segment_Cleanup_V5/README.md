# Segment Cleanup V5 — updated 28 October 2026

Separate CJA and Adobe Analytics tabs. The application folder still has only three Python files.

## Windows: first-time setup

Extract the complete ZIP. Open Command Prompt in this main folder, where
requirements.txt is present. Python must already be installed.

~~~bat
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
copy .env.example application\.env
~~~

Fill application\.env with your authorised credentials. Configure only the product
you need. Keep both deletion flags at 0 for normal testing. Then run:

~~~bat
.venv\Scripts\python.exe application\app.py
~~~

Open http://127.0.0.1:5005. Keep Command Prompt open. For the next run, only the
last command is needed. Windows execution has not been tested on a Windows machine.

If upgrading an existing installation, stop the old app first. Back up its three
Python files. Replace all three together, keep your local .env unchanged and restart.
Do not mix updated app.py with older finder files.

## Linux

~~~bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
cp .env.example application/.env
.venv/bin/python application/app.py
~~~

Fill application/.env before starting. Desktop testing used Python 3.13 on Linux.
No Node.js or browser automation package is needed to run the application.

## Changes

1. Summary scorecards have equal widths, heights and aligned values.
2. Returning from a report clears the previous Data View/Report Suite selection.
   The available options remain in the list. Generate stays disabled until a choice is made.
3. Both selectors support name/ID search, keyboard selection and stable wheel scrolling.
4. Exact and near groups have separate search, pagination and page-size controls.
   Long groups have expandable members. Group downloads include every filtered member,
   not only the current page or the first three preview members.
5. AA approval columns, badges, counters and export columns are removed. CJA retains them.
6. AA does not use approval status for deletion eligibility. It still requires confirmed
   unpublished status, an assessable definition, complete accessible Workspace usage,
   no positive references/shares and explicit owner/dependency review.
7. CJA deletion uses the colleague's approval and usage checks, with fresh server reads.
   It requires explicit Not Approved status. Unknown approval and known/ambiguous positive
   publication/sharing evidence remain blocked. When CJA does not return publication
   metadata, this is disclosed; the owner must check publication and outside dependencies.
8. The typed DELETE field is removed from AA only. Its review checkbox and final
   confirmation button remain. CJA keeps typed DELETE confirmation.

## Safety

Live deletion is disabled by default and was not exercised against Adobe.
To use live deletion later, an authorised operator must deliberately configure the
correct product flag and have the required Adobe permissions. A duplicate match is
not permission to delete. Do not enable writes just for analysis testing.

Freshness checks, report-bound preview plans, local-only access, per-product isolation,
audit logging, keep-one-exact-copy protection and the 200-ID batch limit remain.
Failures and pending responses are not reported as successful deletions. Writes are
not atomic and are never retried automatically.

The CJA API account used for verification did not supply publishingStatus. Missing
publication is not labelled "unpublished". Zero references in accessible Workspace
projects is not proof of global non-use.

## Verification and tests

See VERIFICATION.md. This ZIP passed 173 offline regression tests after fresh extraction.
The runtime files match the repaired local version byte for byte. Tests are outside
application/ and do not add runtime modules. The package-local hash fixture replaces
the development-only cross-version sibling-folder check.

~~~bat
set PYTHONPATH=application
.venv\Scripts\python.exe -B -m unittest discover -s tests -t . -v
~~~

For Linux: PYTHONPATH=application .venv/bin/python -B -m unittest discover -s tests -t . -v

Comparison rules and scores are unchanged. Similarity means definition similarity,
not audience overlap. Near groups are connected matches; not every pair inside a
near group is necessarily above the threshold. CSV and Excel-compatible SpreadsheetML
(.xls) exports remain available; these are not native .xlsx files.

No credentials, token caches, private inventories, generated reports, audit logs,
screenshots or virtual environment are included. Keep your real .env private.
