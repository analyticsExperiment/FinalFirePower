"""The eight review observations. All deletion effects are synthetic."""
from pathlib import Path
import csv
import json
import re
import tempfile
import unittest
from unittest.mock import patch
import app
import aa_segment_finder as aa
import cja_segment_finder as cja
from tests.fixtures import segment
from tests.test_deletion import FakeClient
from tests.test_client import Session


class ReviewTests(unittest.TestCase):
    def report(self, module):
        raw=[segment('a',approved=False,publishingStatus=False),segment('b',approved=False,publishingStatus=False)]
        records=module.prepare_segments([module.normalize_segment(s,module.PROVIDER_ID,{}) for s in raw])
        return module.build_dashboard_html(records,module.find_duplicate_segments(records),{},True,85,'test.csv',tool=module.PROVIDER_ID)

    def data(self, html, name):
        return json.loads(re.search(r'const '+name+r' = (.*);\n',html).group(1))

    def test_summary_alignment_grid(self):
        for module in (aa,cja):
            self.assertIn('grid-template-columns:repeat(4,minmax(0,1fr))',module.DASHBOARD_CSS)
            self.assertIn('min-height:34px',module.DASHBOARD_CSS)
            self.assertEqual(self.report(module).count('class="card"'),4)

    def test_approval_summary_only_in_cja(self):
        self.assertIn('class="approval-summary"',self.report(cja))
        self.assertNotIn('class="approval-summary"',self.report(aa))

    def test_aa_approval_not_in_actual_headers_or_embedded_data(self):
        html=self.report(aa)
        self.assertNotRegex(html,r'<th[^>]*>Approved Status</th>')
        self.assertNotIn('<th>Approval</th>',html)
        self.assertNotIn('approval',self.data(html,'SEGMENTS_DATA')[0])
        self.assertNotIn('aApproval',self.data(html,'MATCHES_DATA')[0])
        self.assertNotIn('approval',self.data(html,'GROUPS_DATA')['exact'][0]['members'][0])
        self.assertIn('"showApproval": false',html)

    def test_cja_approval_metadata_kept(self):
        html=self.report(cja)
        self.assertRegex(html,r'<th[^>]*>Approved Status</th>')
        self.assertEqual(self.data(html,'GROUPS_DATA')['exact'][0]['members'][0]['approval'],'Not Approved')

    def test_only_aa_typed_input_removed(self):
        self.assertNotIn('id="cleanupType"',self.report(aa))
        self.assertIn('id="cleanupType"',self.report(cja))
        self.assertIn('id="cleanupOwner"',self.report(aa))

    def test_csv_columns_per_product(self):
        with tempfile.TemporaryDirectory() as directory:
            for module in (aa,cja):
                path=Path(directory)/('segments-'+module.PROVIDER_ID+'.csv')
                module.export_segment_csv([segment()],path,tool=module.PROVIDER_ID)
                with path.open(encoding='utf-8-sig',newline='') as stream:rows=list(csv.reader(stream))
                self.assertEqual('Approved Status' in rows[0],module is cja)
                self.assertEqual(len(rows[0]),len(rows[1]))

    def test_group_paging_controls_and_members(self):
        html=self.report(cja)
        for kind in ('exact','near'):
            for suffix in ('GroupSearch','GroupPageSize','GroupPagination','GroupList'):
                self.assertIn('id="'+kind+suffix+'"',html)
        group=self.data(html,'GROUPS_DATA')['exact'][0]
        self.assertEqual({s['id'] for s in group['members']},{'a','b'})
        self.assertIn('group.members.slice(0,3)',html)
        self.assertIn('does not guarantee A ~ C',html)

    def test_aa_all_approval_states_ignored_for_eligibility(self):
        for metadata in ({},{'approved':True},{'approved':False},{'tags':[{'name':'Approved'}]}):
            row=segment(publishingStatus=False,**metadata)
            self.assertEqual(aa.deletion_block_reason(row,{},True),'')
            self.assertFalse(aa.is_protected(row))

    def test_aa_other_safeguards_unchanged(self):
        base=segment(publishingStatus=False)
        for values,usage,loaded in [({'publishingStatus':True},{},True),
            ({'publishingStatus':None},{},True),({}, {},False),({}, {'s1':{'count':1}},True),
            ({'usedIn':[{'componentId':'p'}]},{},True),({'shares':[{'id':'p'}]},{},True)]:
            self.assertTrue(aa.deletion_block_reason({**base,**values},usage,loaded))

    def test_cja_missing_publication_uses_original_policy_and_owner_review(self):
        row=segment(approved=False)
        self.assertEqual(cja.deletion_block_reason(row,{},True),'')
        self.assertIn('the owner must check it',self.report(cja))
        self.assertIn('have checked publication',self.report(cja))

    def test_cja_approval_and_positive_publication_still_block_preview(self):
        for metadata in ({'approved':True},{'publishingStatus':True}):
            self.assertTrue(cja.deletion_block_reason(segment(approved=False)|metadata,{},True))
        self.assertTrue(cja.deletion_block_reason(segment(),{},True))

    def test_cja_known_or_ambiguous_publication_still_blocks(self):
        for value in (True,'published',{}, {'published':True},'unknown'):
            self.assertTrue(cja.deletion_block_reason(segment(approved=False,publishingStatus=value),{},True))
        for value in (False,'unpublished',{'published':False},None):
            self.assertEqual(cja.deletion_block_reason(segment(approved=False,publishingStatus=value),{},True),'')

    def test_cja_positive_usage_or_shares_still_blocks(self):
        for metadata in ({'shares':[{'id':'owner'}]}, {'usedIn':[{'id':'p'}]}, {'usageSummary':{'count':1}}):
            self.assertTrue(cja.deletion_block_reason(segment(approved=False,**metadata),{},True))
        self.assertTrue(cja.deletion_block_reason(segment(approved=False),{},False))

    def test_cja_cannot_use_aa_confirmation_instead_of_typed_confirmation(self):
        with tempfile.TemporaryDirectory() as directory:
            client=FakeClient([segment('b',approved=False)])
            manager,token=self.workflow(cja,client,directory)
            plan=manager.preview(token,'cja',{'ids':['b']})
            with self.assertRaises(app.DeletionError):
                manager.execute(token,'cja',{'ids':plan['ids'],'plan':plan['plan'],'delete_confirmed':True,'owner_review_confirmed':True})
            self.assertEqual(client.deleted,[])

    def workflow(self, module, client, directory):
        records=module.prepare_segments([module.normalize_segment(s,module.PROVIDER_ID,{}) for s in client.records.values()])
        manager=app.DeletionWorkflow(module,lambda:Path(directory))
        token=manager.register(module.PROVIDER_ID,client,{'segments':records,'matches':[],'threshold':85},'demo_suite')
        return manager,token

    def test_cja_missing_publication_fresh_read_then_mock_execute(self):
        with tempfile.TemporaryDirectory() as directory:
            client=FakeClient([segment('b',approved=False)])
            manager,token=self.workflow(cja,client,directory)
            plan=manager.preview(token,'cja',{'ids':['b']})
            self.assertEqual(plan['ids'],['b']);self.assertEqual(client.deleted,[])
            self.assertIn('publication status is unavailable',plan['results'][0]['reason'])
            result=manager.execute(token,'cja',{'ids':plan['ids'],'plan':plan['plan'],'confirmation':'DELETE','owner_review_confirmed':True})
            self.assertTrue(result['success']);self.assertEqual(client.deleted,['b'])

    def test_cja_missing_or_changed_approval_remains_blocked(self):
        for approval in (None,True):
            with tempfile.TemporaryDirectory() as directory:
                client=FakeClient([segment('b',approved=approval)])
                manager,token=self.workflow(cja,client,directory)
                self.assertEqual(manager.preview(token,'cja',{'ids':['b']})['ids'],[])
                self.assertEqual(client.deleted,[])

    def test_aa_explicit_button_confirmation_not_magic_text(self):
        with tempfile.TemporaryDirectory() as directory:
            client=FakeClient([segment('b',publishingStatus=False)])
            manager,token=self.workflow(aa,client,directory)
            plan=manager.preview(token,'aa',{'ids':['b']})
            self.assertEqual(plan['ids'],['b'])
            with self.assertRaises(app.DeletionError):
                manager.execute(token,'aa',{'ids':plan['ids'],'plan':plan['plan'],'confirmation':'DELETE','owner_review_confirmed':True})
            result=manager.execute(token,'aa',{'ids':plan['ids'],'plan':plan['plan'],'delete_confirmed':True,'owner_review_confirmed':True})
            self.assertTrue(result['success'])

    def test_blank_scope_and_bfcache_return(self):
        source=Path(app.__file__).read_text()
        self.assertIn("new Option('Choose a '",source)
        self.assertIn("scopeSelect.value = ''" if 'V4' in str(app.__file__) else "select.value=''",source)
        self.assertIn('event.persisted',source)
        self.assertNotIn('restore(tool)?.scope',source)

    def test_searchable_picker_has_product_specific_labels(self):
        source=Path(app.__file__).read_text()
        self.assertIn('setLabels(singular, plural)',source)
        self.assertIn("'Search ' + plural",source)
