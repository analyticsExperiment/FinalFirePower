from contextlib import redirect_stdout, redirect_stderr
from io import StringIO
import json
import unittest
from unittest.mock import patch
import app as cli
from aa_segment_finder import AdobeError


class CliTests(unittest.TestCase):
    def test_tool_scope_and_json_forwarded(self):
        payload = {"tool": "cja", "segment_count": 2, "segments": [], "matches": [], "usage_map": {}, "dashboard_html": "html"}
        output = StringIO()
        with patch("sys.argv", ["app.py", "--tool", "cja", "--scope", "dv1", "--json"]), \
             patch("app.make_client"), patch("app.run_pipeline", return_value=payload) as run, redirect_stdout(output):
            self.assertEqual(cli.main(), 0)
        self.assertEqual(run.call_args.kwargs["tool"], "cja")
        self.assertEqual(run.call_args.kwargs["scope_selection"], "dv1")
        result = json.loads(output.getvalue())
        self.assertEqual(result["tool"], "cja")
        self.assertNotIn("dashboard_html", result)

    def test_cli_error_json(self):
        output = StringIO()
        with patch("sys.argv", ["app.py", "--tool", "aa"]), patch("app.make_client", side_effect=AdobeError("Configuration missing.")), redirect_stderr(output):
            self.assertEqual(cli.main(), 1)
        self.assertEqual(json.loads(output.getvalue()), {"error": "Configuration missing."})
