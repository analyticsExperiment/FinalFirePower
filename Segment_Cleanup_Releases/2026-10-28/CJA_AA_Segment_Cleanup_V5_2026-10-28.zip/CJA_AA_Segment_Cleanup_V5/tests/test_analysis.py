from copy import deepcopy
from pathlib import Path
import json
import tempfile
import unittest
from aa_segment_finder import AdobeError
import aa_segment_finder as core
from aa_segment_finder import build_dashboard_html
from tests.fixtures import FixtureClient, predicate, definition, segment


class AnalysisTests(unittest.TestCase):
    def test_owner_metadata_fallbacks(self):
        for payload, expected in [({}, "-"), ({"owner": {"fullName": "Full Name"}}, "Full Name"),
                                  ({"owner": {"id": 23}}, "Owner ID: 23"),
                                  ({"ownerName": "Owner"}, "Owner"),
                                  ({"createdBy": {"displayName": "Creator"}}, "Creator"),
                                  ({"createdBy": "Creator"}, "Creator"),
                                  ({"user": {"name": "User"}}, "User"),
                                  ({"owner": "Owner"}, "Owner"),
                                  ({"owner": {"id": 23}, "ownerFullName": "Full Name"}, "Full Name")]:
            with self.subTest(payload=payload):
                self.assertEqual(core.get_owner_name(payload), expected)

    def test_exact_ignores_name_and_object_key_order(self):
        a, b = segment("a"), segment("b", name="Different business name")
        b["definition"] = dict(reversed(list(b["definition"].items())))
        result = core.find_duplicate_segments([a, b])
        self.assertEqual([m["type"] for m in result], ["Exact duplicate"])

    def test_boolean_predicate_order_normalises(self):
        p = [predicate("variables/evar1", "x"), predicate("variables/evar2", "y")]
        a, b = segment("a", {"func": "and", "preds": p}), segment("b", {"func": "and", "preds": p[::-1]})
        self.assertEqual(core.find_duplicate_segments([a, b])[0]["type"], "Exact duplicate")

    def test_sequence_order_never_exact(self):
        steps = [definition(predicate(value="a"))["container"], definition(predicate(value="b"))["container"]]
        a = segment("a", {"func": "sequence", "stream": steps})
        b = segment("b", {"func": "sequence", "stream": steps[::-1]})
        matches = core.find_duplicate_segments([a, b], threshold=1)
        self.assertEqual(matches[0]["type"], "Near duplicate")
        self.assertLess(matches[0]["similarity"], 100)
        self.assertTrue(matches[0]["diff"]["onlyA"])

    def test_predicate_value_swaps_never_exact(self):
        a = segment("a", {"func": "and", "preds": [predicate("variables/evar1", "x"), predicate("variables/evar2", "y")]})
        b = segment("b", {"func": "and", "preds": [predicate("variables/evar1", "y"), predicate("variables/evar2", "x")]})
        self.assertNotEqual(core.normalized_definition(a), core.normalized_definition(b))
        self.assertLess(core.similarity_from_tokens(core.tokenize(a), core.tokenize(b)), 100)

    def test_metric_dimension_and_context_preserved(self):
        a = segment("a", {"func": "gt", "val": {"func": "total", "evt": {"func": "event", "name": "metrics/event1"}}, "num": 2})
        b = deepcopy(a)
        b["id"] = "b"
        b["definition"]["container"]["pred"]["val"] = {"func": "attr", "name": "variables/event1"}
        c = deepcopy(a)
        c["id"] = "c"
        c["definition"]["container"]["context"] = "visitors"
        self.assertEqual({m["type"] for m in core.find_duplicate_segments([a, b, c], 1)}, {"Near duplicate"})

    def test_types_numeric_thresholds_and_negation_preserved(self):
        a, b = segment("a"), segment("b")
        b["definition"]["container"]["pred"]["str"] = 1
        a["definition"]["container"]["pred"]["str"] = "1"
        self.assertNotEqual(core.tokenize(a), core.tokenize(b))
        b["definition"]["container"]["pred"]["str"] = True
        a["definition"]["container"]["pred"]["str"] = 1
        self.assertNotEqual(core.tokenize(a), core.tokenize(b))
        b["definition"]["container"]["pred"] = {"func": "without", "pred": predicate()}
        self.assertNotEqual(core.normalized_definition(a), core.normalized_definition(b))

    def test_array_multiplicity_not_discarded(self):
        p = predicate()
        a, b = segment("a", {"func": "and", "preds": [p]}), segment("b", {"func": "and", "preds": [p, p]})
        self.assertNotEqual(core.tokenize(a), core.tokenize(b))

    def test_missing_invalid_definitions_not_unique_or_duplicates(self):
        bad = [segment(str(i), definition=value) for i, value in enumerate((None, {}, [], "not json", {"func": "segment"}))]
        prepared = core.prepare_segments(bad)
        self.assertEqual(core.find_duplicate_segments(prepared), [])
        self.assertEqual(core.count_unique_segments(prepared, []), 0)
        self.assertTrue(all(core.definition_issue(s) for s in prepared))

    def test_json_string_definition_parsed(self):
        a, b = segment("a"), segment("b", definition=json.dumps(definition()))
        self.assertEqual(core.find_duplicate_segments(core.prepare_segments([a, b]))[0]["type"], "Exact duplicate")

    def test_no_cross_suite_exact_or_near(self):
        self.assertEqual(core.find_duplicate_segments([segment("a"), segment("b", rsid="different")], 1), [])

    def test_threshold_validation(self):
        for invalid in ("nan", "inf", "bad", 0, 101, None):
            with self.assertRaises(ValueError):
                core.find_duplicate_segments([], invalid)

    def test_jaccard_known_result(self):
        self.assertEqual(core.similarity_from_tokens({"a", "b"}, {"b", "c"}), 100 / 3)
        self.assertEqual(core.similarity_from_tokens(set(), set()), 0)

    def test_group_transitive_but_pairwise_not_invented(self):
        a, b, c = segment("a"), segment("b"), segment("c")
        matches = [{"type": "Near duplicate", "a": a, "b": b}, {"type": "Near duplicate", "a": b, "b": c}]
        self.assertEqual(len(core.build_duplicate_groups(matches, "Near duplicate")[0]), 3)
        self.assertEqual(len(matches), 2)

    def test_usage_count_is_distinct_project_not_occurrences(self):
        c = FixtureClient()
        usage, loaded = core.load_workspace_usage(c.get_segments(), c)
        self.assertTrue(loaded)
        self.assertEqual(usage["exact0"]["count"], 1)
        self.assertEqual(usage["near0"]["sharedPublishedCount"], 1)

    def test_usage_failure_is_unknown_not_unused(self):
        class Failed(FixtureClient):
            def get_projects(self):
                raise AdobeError("Denied")
        usage, loaded = core.load_workspace_usage([segment()], Failed())
        self.assertFalse(loaded)
        self.assertIn("Unable to verify", core.get_deletion_recommendation({"a": segment(), "b": segment("b"), "type": "Exact duplicate"}, usage, loaded)["text"])

    def test_project_detail_missing_means_incomplete(self):
        class Partial(FixtureClient):
            def get_projects(self):
                return [{"id": "missing"}]
            def get_project(self, project_id):
                return {"id": project_id}
        self.assertFalse(core.load_workspace_usage([segment()], Partial())[1])

    def test_aa_publishing_protected_without_using_approval(self):
        for protected in (segment(publishingStatus="published"),):
            rec = core.get_deletion_recommendation({"a": protected, "b": segment("b"), "type": "Exact duplicate"}, {}, True)
            self.assertIn("Do not delete", rec["text"])
        for metadata in ({'approved':True}, {'tags':[{'name':'Approved'}]}, {}):
            rec = core.get_deletion_recommendation({"a":segment(**metadata), "b":segment("b"), "type":"Exact duplicate"}, {}, True)
            self.assertTrue(rec['text'].startswith('Review'))

    def test_no_usage_is_review_not_delete(self):
        rec = core.get_deletion_recommendation({"a": segment(), "b": segment("b"), "type": "Exact duplicate"}, {}, True)
        self.assertTrue(rec["text"].startswith("Review"))

    def test_exports_safe_and_empty_run_success(self):
        with tempfile.TemporaryDirectory() as directory:
            result = core.run_pipeline(FixtureClient(), scope_selection="empty_suite", output_dir=directory)
            self.assertEqual(result["segment_count"], 0)
            self.assertTrue(Path(result["dashboard_html_path"]).is_file())
            path = Path(directory) / "safe.csv"
            core.export_segment_csv([segment(name="=1+1")], path)
            self.assertIn("'=1+1", path.read_text(encoding="utf-8-sig"))

    def test_html_injection_escaped_no_secrets(self):
        malicious = segment(name='</script><script>window.HACKED=true</script>')
        html = build_dashboard_html([malicious], [], {}, False, 85, "segments.csv")
        self.assertNotIn('</script><script>window.HACKED', html)
        self.assertIn('Unknown', build_dashboard_html([segment(), segment("b")], core.find_duplicate_segments([segment(), segment("b")]), {}, False, 85, "segments.csv"))

    def test_full_pipeline_counts_and_rsid_selection(self):
        with tempfile.TemporaryDirectory() as directory:
            result = core.run_pipeline(FixtureClient(), output_dir=directory)
            self.assertEqual(result["segment_count"], 23)
            self.assertEqual(result["unassessed_count"], 1)
            self.assertEqual(result["exact_count"], 3)
            self.assertEqual(result["near_count"], 12)
            self.assertEqual(result["unique_count"], 16)
            selected = core.run_pipeline(FixtureClient(), scope_selection="other_suite", output_dir=directory)
            self.assertEqual(selected["segment_count"], 1)
            self.assertEqual(selected["match_count"], 0)
            with self.assertRaises(ValueError):
                core.run_pipeline(FixtureClient(), scope_selection="fake", output_dir=directory)


if __name__ == "__main__":
    unittest.main()
