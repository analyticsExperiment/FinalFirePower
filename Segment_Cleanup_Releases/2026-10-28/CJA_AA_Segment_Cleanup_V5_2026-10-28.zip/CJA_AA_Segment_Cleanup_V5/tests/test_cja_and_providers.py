from copy import deepcopy
from pathlib import Path
import csv
import json
import os
import tempfile
import unittest
from unittest.mock import patch

from aa_segment_finder import AA_BASE
from cja_segment_finder import Config, AdobeError
import aa_segment_finder as aa_module
from cja_segment_finder import CjaClient, CJA_BASE, data_view_id
from app import normalize_segment, get_provider, make_client
import cja_segment_finder as core
from aa_segment_finder import build_dashboard_html
from tests.test_client import Session, Response
from tests.fixtures import CjaFixtureClient, FixtureClient, segment


def client(responses):
    session = Session([r if isinstance(r, Response) else Response(r) for r in responses])
    return CjaClient(Config(client_id="fixture", access_token="fake-token", org_id="fixture-org", provider="cja"), session, page_size=2)


class CjaClientTests(unittest.TestCase):
    def test_deletion_preflight_accepts_cja_aliases_and_legacy_structure(self):
        from app import DeletionWorkflow
        from tests.test_deletion import FakeClient
        raw=segment('legacy', approved=False, publishingStatus={'published':False})
        raw.pop('rsid')
        raw['dataView']={'id':'dv_legacy'}
        raw['definition']['func']='segment-def'
        raw['definition']['container']['func']='segment'
        prepared=core.prepare_segments([normalize_segment(raw,'cja',{})])
        fake=FakeClient([raw])
        with tempfile.TemporaryDirectory() as directory:
            manager=DeletionWorkflow(core,lambda:Path(directory))
            token=manager.register('cja',fake,{'segments':prepared,'matches':[],'threshold':85},'dv_legacy')
            self.assertEqual(manager.preview(token,'cja',{'ids':['legacy']})['ids'],['legacy'])
            self.assertEqual(fake.deleted,[])

    def test_data_views_use_cja_host_org_header_no_discovery(self):
        c = client([{"content": [{"id": "dv1", "name": "Demo"}], "lastPage": True}])
        self.assertEqual(c.get_scopes()[0]["id"], "dv1")
        method, url, options = c.session.calls[0]
        self.assertEqual((method, url), ("GET", CJA_BASE + "/data/dataviews"))
        self.assertEqual(options["headers"]["x-gw-ims-org-id"], "fixture-org")
        self.assertNotIn("discovery", url)

    def test_cja_rsids_query_and_defensive_filter(self):
        c = client([{"content": [{"id": "a", "rsid": "dv1", "definition": {"func": "segment"}},
                                  {"id": "b", "dataId": "dv2", "definition": {"func": "segment"}}], "lastPage": True}])
        self.assertEqual([s["id"] for s in c.get_segments("dv1")], ["a"])
        self.assertEqual(c.session.calls[0][2]["params"]["rsids"], "dv1")
        self.assertNotIn("rsid", c.session.calls[0][2]["params"])
        self.assertNotIn("dataviewIds", c.session.calls[0][2]["params"])

    def test_missing_definition_and_scope_hydrated(self):
        c = client([{"content": [{"id": "a"}], "lastPage": True},
                    {"id": "a", "rsid": "dv1", "definition": {"func": "segment"}}])
        self.assertEqual(data_view_id(c.get_segments("dv1")[0]), "dv1")
        self.assertEqual(c.session.calls[1][1], CJA_BASE + "/segments/a")

    def test_unknown_scope_kept_but_not_comparable(self):
        c = client([{"content": [{"id": "a"}], "lastPage": True}, Response({}, 403)])
        raw = c.get_segments("dv1")[0]
        prepared = normalize_segment(raw, "cja", {})
        self.assertTrue(core.definition_issue(prepared))
        self.assertFalse(core.tokenize(prepared))

    def test_cja_projects_use_shares_expansion(self):
        c = client([{"content": [], "lastPage": True}])
        self.assertEqual(c.get_projects(), [])
        self.assertIn("shares", c.session.calls[0][2]["params"]["expansion"])

    def test_no_cross_provider_host_or_write(self):
        c = client([])
        for method, url in [("GET", AA_BASE + "/api/x/segments"), ("DELETE", CJA_BASE + "/segments/a"),
                            ("POST", CJA_BASE + "/segments"), ("PUT", CJA_BASE + "/projects/a")]:
            with self.assertRaises(AdobeError):
                c._request(method, url)
        self.assertEqual(c.session.calls, [])

    def test_cja_does_not_offer_company_or_report_suite_calls(self):
        c = client([])
        with self.assertRaises(AdobeError): c.resolve_company()
        with self.assertRaises(AdobeError): c.get_report_suites()
        with self.assertRaises(AdobeError): c.get("reportsuites/collections/suites")


class ProviderAnalysisTests(unittest.TestCase):
    def test_cja_metadata_aliases_and_no_definition_rewrite(self):
        original = segment()
        original["dataId"] = original.pop("rsid")
        original["dataName"] = "View name"
        normalized = normalize_segment(original, "cja", {})
        self.assertEqual(core.get_scope_id(normalized), "demo_suite")
        self.assertEqual(core.get_scope_name(normalized), "View name")
        self.assertIs(normalized["definition"], original["definition"])

    def test_no_cross_product_pair_even_if_ids_and_scope_collide(self):
        a = normalize_segment(segment("a"), "aa", {})
        b = normalize_segment(segment("b"), "cja", {})
        self.assertEqual(core.find_duplicate_segments([a, b], 1), [])

    def test_documented_cja_segment_def_shape_supported_without_rewrite(self):
        a = normalize_segment(segment("a"), "cja", {})
        a["definition"]["func"] = "segment-def"
        a["definition"]["container"]["func"] = "segment"
        b = deepcopy(a); b["id"] = "b"
        self.assertEqual(core.find_duplicate_segments([a, b])[0]["type"], "Exact duplicate")
        self.assertEqual(a["definition"]["func"], "segment-def")

    def test_cja_full_pipeline_and_labels_exports(self):
        with tempfile.TemporaryDirectory() as directory:
            result = core.run_pipeline(CjaFixtureClient(), tool="cja", output_dir=directory)
            self.assertEqual((result["segment_count"], result["exact_count"], result["near_count"], result["unique_count"]), (23, 3, 12, 16))
            self.assertIn("CJA Segment Cleanup Dashboard", result["dashboard_html"])
            self.assertIn('href="/?tool=cja"', result["dashboard_html"])
            self.assertIn("Change Data View", result["dashboard_html"])
            self.assertIn("Change Tool", result["dashboard_html"])
            self.assertIn("Keep literal Adobe Analytics and Report Suite", result["dashboard_html"])
            with open(result["segment_csv_path"], encoding="utf-8-sig") as handle:
                rows = list(csv.DictReader(handle))
            self.assertIn("Data View ID", rows[0])
            self.assertNotIn("Report Suite ID", rows[0])
            self.assertTrue(Path(result["dashboard_html_path"]).name.startswith("CJA_"))

    def test_cja_individual_scope_and_empty_view(self):
        with tempfile.TemporaryDirectory() as directory:
            one = core.run_pipeline(CjaFixtureClient(), tool="cja", scope_selection="dv_two", output_dir=directory)
            self.assertEqual(one["segment_count"], 1)
            empty = core.run_pipeline(CjaFixtureClient(), tool="cja", scope_selection="dv_empty", output_dir=directory)
            self.assertEqual(empty["segment_count"], 0)
            self.assertIn("No exact-duplicate groups found", empty["dashboard_html"])

    def test_provider_validation(self):
        for value in ("", "both", "analytics", "<script>"):
            with self.assertRaises(ValueError): get_provider(value)


class ConfigurationIsolationTests(unittest.TestCase):
    def test_provider_values_and_token_caches_stay_separate(self):
        with patch.dict(os.environ, {"CJA_API_KEY": "cja-id", "CJA_CLIENT_SECRET": "cja-secret", "CJA_SCOPES": "cja-scope", "CJA_ORG_ID": "cja-org",
                                     "AA_CLIENT_ID": "aa-id", "AA_CLIENT_SECRET": "aa-secret", "AA_SCOPES": "aa-scope", "AA_GLOBAL_COMPANY_ID": "aa-company"}, clear=True), \
             patch("aa_segment_finder.dotenv_values", return_value={}), patch("cja_segment_finder.dotenv_values", return_value={}):
            cja, aa = Config.load("cja"), aa_module.Config.load("aa")
        self.assertEqual((cja.client_id, cja.org_id, cja.provider), ("cja-id", "cja-org", "cja"))
        self.assertEqual((aa.client_id, aa.company_id, aa.provider), ("aa-id", "aa-company", "aa"))
        self.assertNotEqual(cja.token_cache, aa.token_cache)
        self.assertEqual(cja.company_id, "")

    def test_missing_cja_does_not_borrow_aa_credentials(self):
        with patch.dict(os.environ, {"AA_CLIENT_ID": "aa-id", "AA_ACCESS_TOKEN": "aa-token"}, clear=True), \
             patch("aa_segment_finder.dotenv_values", return_value={}), patch("cja_segment_finder.dotenv_values", return_value={}):
            self.assertTrue(aa_module.Config.load("aa").client_id)
            with self.assertRaises(AdobeError): Config.load("cja")

    def test_missing_aa_does_not_borrow_cja_credentials(self):
        with patch.dict(os.environ, {"CJA_CLIENT_ID": "cja-id", "CJA_ACCESS_TOKEN": "cja-token", "CJA_ORG_ID": "cja-org"}, clear=True), \
             patch("aa_segment_finder.dotenv_values", return_value={}), patch("cja_segment_finder.dotenv_values", return_value={}):
            self.assertTrue(Config.load("cja").client_id)
            with self.assertRaises(aa_module.AdobeError): aa_module.Config.load("aa")
