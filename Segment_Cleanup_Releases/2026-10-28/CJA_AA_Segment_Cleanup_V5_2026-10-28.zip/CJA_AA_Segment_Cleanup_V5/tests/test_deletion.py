"""No live requests: all deletion effects use fakes or mocked HTTP sessions."""
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import json
import re
import tempfile
import time
import unittest
from unittest.mock import patch
import requests
import aa_segment_finder as core
from app import DeletionWorkflow, DeletionError
from aa_segment_finder import approval_status, unpublished_confirmed
from tests.fixtures import segment
from tests.test_client import client, Response


class FakeClient:
    cache_identity = 'fake-integration'
    def __init__(self, records, enabled=True):
        self.records = {s['id']:deepcopy(s) for s in records}
        self.config = SimpleNamespace(deletion_enabled=enabled)
        self.projects, self.calls, self.deleted = [], [], []
        self.outcomes = {}
        self.fail_usage = False
    def get_segment(self, sid):
        self.calls.append(('GET',sid))
        return deepcopy(self.records[sid])
    def get_projects(self):
        if self.fail_usage:
            try:
                from aa_segment_finder import AdobeError
            except ImportError:
                from aa_client import AdobeError
            raise AdobeError('fixture failure')
        return deepcopy(self.projects)
    def get_project(self, sid):
        raise AssertionError('No expanded project available')
    def delete_segment(self, sid):
        self.calls.append(('DELETE',sid));self.deleted.append(sid)
        return self.outcomes.get(sid, {'status':'deleted','error':None})
    def get_segments(self, scope=None):
        return list(deepcopy(self.records).values())
    def get_scopes(self):
        return [{'id':'demo_suite','name':'Synthetic Suite'}]
    def get_report_suites(self):
        return self.get_scopes()


class DeletionTests(unittest.TestCase):
    def setUp(self):
        self.directory=tempfile.TemporaryDirectory()
        self.manager=DeletionWorkflow(core,lambda:Path(self.directory.name))
        self.records=[segment(i, approved=False, publishingStatus={'published':False}) for i in ('a','b','c')]
        self.client=FakeClient(self.records)
        self.register()
    def tearDown(self):
        self.directory.cleanup()
    def register(self, matches=None, tool='aa'):
        self.token=self.manager.register(tool,self.client,{'segments':self.records,'matches':matches or [],'threshold':85},'demo_suite')
        return self.token
    def preview(self, ids=None):
        return self.manager.preview(self.token,'aa',{'ids':ids or ['b']})
    def execute(self, plan, **overrides):
        payload={'ids':plan['ids'],'plan':plan['plan'],'delete_confirmed':True,'owner_review_confirmed':True,**overrides}
        return self.manager.execute(self.token,'aa',payload)
    def test_tri_state_approval(self):
        self.assertEqual(approval_status({}),'Unknown')
        self.assertEqual(approval_status({'approved':False}),'Not Approved')
        self.assertEqual(approval_status({'approved':True}),'Approved')
        self.assertEqual(approval_status({'approved':False,'tags':[{'name':'Approved'}]}),'Approved')
    def test_missing_publishing_not_unpublished(self):
        self.assertFalse(unpublished_confirmed({}))
        self.assertFalse(unpublished_confirmed({'publishingStatus':{'published':True}}))
        self.assertTrue(unpublished_confirmed({'publishingStatus':{'published':False}}))
    def test_preview_only_reads(self):
        result=self.preview()
        self.assertEqual(result['ids'],['b']);self.assertEqual(self.client.deleted,[])
        self.assertTrue(all(method=='GET' for method,_ in self.client.calls))
    def test_disabled_live_writes(self):
        self.client.config.deletion_enabled=False
        plan=self.preview()
        self.assertFalse(plan['enabled'])
        with self.assertRaisesRegex(DeletionError,'disabled'):self.execute(plan)
        self.assertEqual(self.client.deleted,[])
    def test_success_audit_and_single_use(self):
        plan=self.preview();result=self.execute(plan)
        self.assertTrue(result['success']);self.assertTrue(result['refresh_required'])
        self.assertEqual(self.client.deleted,['b'])
        with self.assertRaises(DeletionError):self.execute(plan)
        path=Path(self.directory.name)/'output/audit/segment-deletions.jsonl'
        events=[json.loads(line) for line in path.read_text().splitlines()]
        self.assertEqual([e['phase'] for e in events],['preflight','intent','result'])
        self.assertEqual(path.stat().st_mode&0o777,0o600)
        self.assertNotIn(self.token,path.read_text())
    def test_wrong_token_or_provider(self):
        for token,tool in [('bad','aa'),(self.token,'cja')]:
            with self.assertRaises(DeletionError):self.manager.preview(token,tool,{'ids':['a']})
    def test_expired_report(self):
        self.manager.reports[self.token]['expires']=0
        with self.assertRaises(DeletionError):self.preview()
    def test_identity_change(self):
        self.client.cache_identity='new-integration'
        with self.assertRaises(DeletionError):self.preview()
    def test_invalid_batch(self):
        for value in ([],None,'a',[12],['a b'],['.'],['..'],['x\n'],['x'*201],['a']*201):
            with self.assertRaises(DeletionError):self.manager.preview(self.token,'aa',{'ids':value})
        self.assertEqual(self.client.calls,[])
    def test_outside_report(self):
        with self.assertRaises(DeletionError):self.preview(['foreign'])
        self.assertEqual(self.client.calls,[])
    def test_duplicate_ids_one_write(self):
        plan=self.preview(['b','b']);self.execute(plan)
        self.assertEqual(self.client.deleted,['b'])
    def test_fresh_identity_mismatch(self):
        self.client.records['b']['id']='foreign'
        self.assertEqual(self.preview()['ids'],[])
    def test_fresh_identity_missing(self):
        del self.client.records['b']['id']
        self.assertEqual(self.preview()['ids'],[])
    def test_scope_change(self):
        self.client.records['b']['rsid']='other'
        self.assertEqual(self.preview()['ids'],[])
    def test_definition_changed_since_report(self):
        self.client.records['b']['definition']['container']['context']='hits'
        self.assertEqual(self.preview()['ids'],[])
    def test_fresh_json_definition_uses_report_normalisation(self):
        self.client.records['b']['definition']=json.dumps(self.client.records['b']['definition'])
        self.assertEqual(self.preview()['ids'],['b'])
    def test_aa_approval_unknown_is_not_an_eligibility_condition(self):
        for s in self.records:s.pop('approved')
        self.client=FakeClient(self.records);self.register()
        self.assertEqual(self.preview()['ids'],['b'])
    def test_aa_approved_metadata_does_not_block(self):
        self.records[1]['approved']=True
        self.client=FakeClient(self.records);self.register()
        self.assertEqual(self.preview()['ids'],['b'])
    def test_published_blocked(self):
        self.records[1]['publishingStatus']={'published':True}
        self.client=FakeClient(self.records);self.register()
        self.assertEqual(self.preview()['ids'],[])
    def test_publication_unknown_blocked(self):
        self.records[1].pop('publishingStatus')
        self.client=FakeClient(self.records);self.register()
        self.assertEqual(self.preview()['ids'],[])
    def test_positive_usage_and_new_usage(self):
        plan=self.preview()
        self.client.projects=[{'id':'p','definition':{'segment':'b'}}]
        result=self.execute(plan)
        self.assertFalse(result['results'][0]['success']);self.assertEqual(self.client.deleted,[])
    def test_usage_failure(self):
        self.client.fail_usage=True
        self.assertEqual(self.preview()['ids'],[])
    def test_incomplete_project(self):
        self.client.projects=[{'id':'p'}]
        self.assertEqual(self.preview()['ids'],[])
    def test_approval_changes_after_preview(self):
        plan=self.preview();self.client.records['b']['approved']=True
        self.execute(plan);self.assertEqual(self.client.deleted,[])
    def test_keep_one_exact_copy(self):
        self.register(core.find_duplicate_segments(self.records))
        plan=self.preview(['a','b','c']);self.assertEqual(plan['ids'],['b','c'])
        self.execute(plan);self.assertEqual(self.client.deleted,['b','c'])
    def test_confirmation_required(self):
        for confirmation,owner in [(False,True),(None,True),('true',True),(True,False),(True,'true')]:
            plan=self.preview()
            with self.assertRaises(DeletionError):self.execute(plan,delete_confirmed=confirmation,owner_review_confirmed=owner)
        self.assertEqual(self.client.deleted,[])
    def test_plan_cannot_change_selection(self):
        plan=self.preview()
        with self.assertRaises(DeletionError):self.execute(plan,ids=['c'])
    def test_expired_plan(self):
        plan=self.preview();report=self.manager.reports[self.token]
        report['plans'][plan['plan']]=(0,plan['ids'])
        with self.assertRaises(DeletionError):self.execute(plan)
    def test_preview_plans_are_bounded(self):
        first=self.preview()
        for _ in range(12):self.preview()
        self.assertEqual(len(self.manager.reports[self.token]['plans']),12)
        with self.assertRaises(DeletionError):self.execute(first)
    def test_audit_failure_prevents_writes(self):
        plan=self.preview()
        with patch.object(self.manager,'record',side_effect=OSError('cannot write')):
            with self.assertRaises(OSError):self.execute(plan)
        self.assertEqual(self.client.deleted,[])
    def test_late_audit_failure_invalidates_old_report(self):
        plan=self.preview()
        other=self.register()
        # Both contexts belong to the same integration and must be invalidated.
        original_record=self.manager.record
        def record(tool,data):
            if data['phase']=='result':raise OSError('disk full after response')
            original_record(tool,data)
        with patch.object(self.manager,'record',side_effect=record):
            with self.assertRaises(OSError):
                self.manager.execute(next(k for k in self.manager.reports if k!=other),'aa',
                    {'ids':plan['ids'],'plan':plan['plan'],'delete_confirmed':True,'owner_review_confirmed':True})
        self.assertEqual(self.client.deleted,['b'])
        self.assertEqual(self.manager.reports,{})
        self.assertNotIn('b',[s['id'] for s in self.manager.view_client('aa',self.client).get_segments()])
    def test_confirmed_tombstone_no_cross_provider_hiding(self):
        self.execute(self.preview())
        self.assertNotIn('b',[s['id'] for s in self.manager.view_client('aa',self.client).get_segments()])
        self.assertIn('b',[s['id'] for s in self.manager.view_client('cja',self.client).get_segments()])
    def test_pending_not_falsely_successful_or_hidden(self):
        self.client.outcomes['b']={'status':'pending','error':'Not finished'}
        result=self.execute(self.preview())
        self.assertFalse(result['success'])
        self.assertIn('b',[s['id'] for s in self.manager.view_client('aa',self.client).get_segments()])
        self.register();self.assertEqual(self.preview()['ids'],[])
    def test_partial_failure_per_id(self):
        self.client.outcomes['c']={'status':'failed','error':'Forbidden'}
        result=self.execute(self.preview(['b','c']))
        self.assertFalse(result['success']);self.assertEqual([r['status'] for r in result['results']],['deleted','failed'])
    def test_all_old_report_contexts_invalidated_after_attempt(self):
        old=self.token;self.register();self.execute(self.preview())
        with self.assertRaises(DeletionError):self.manager.preview(old,'aa',{'ids':['c']})


class TransportDeletionTests(unittest.TestCase):
    def test_default_blocked_even_direct_method(self):
        c=client([])
        with self.assertRaisesRegex(ValueError,'disabled'):c.delete_segment('a')
        self.assertEqual(c.session.calls,[])
    def test_aa_exact_url_and_no_redirects(self):
        c=client([{'status':'ok'}],deletion_enabled=True)
        self.assertEqual(c.delete_segment('s@org_x')['status'],'deleted')
        method,url,options=c.session.calls[0]
        self.assertEqual(method,'DELETE');self.assertTrue(url.endswith('/fixture-company/segments/s%40org_x'))
        self.assertFalse(options['allow_redirects'])
    def test_statuses_are_not_optimistically_success(self):
        for response,status in [(Response({},204),'deleted'),(Response({},202),'pending'),(Response({},403),'failed'),
                                (Response({},500),'unknown'),(Response({},200),'unknown')]:
            c=client([response],deletion_enabled=True)
            self.assertEqual(c.delete_segment('a')['status'],status)
            self.assertEqual(len(c.session.calls),1)
    def test_network_timeout_not_retried(self):
        c=client([],deletion_enabled=True)
        with patch.object(c.session,'request',side_effect=requests.Timeout('private bearer')) as request:
            result=c.delete_segment('a')
        self.assertEqual(result['status'],'unknown');request.assert_called_once()
        self.assertNotIn('private',result['error'])
    def test_cja_uses_org_header_without_company_discovery(self):
        try:
            from cja_segment_finder import CjaClient
            from aa_segment_finder import Config
            from tests.test_client import Session
        except ImportError:
            self.skipTest('Standalone supports Analytics only')
        c=CjaClient(Config(client_id='fixture',access_token='fake',provider='cja',org_id='fake-org',deletion_enabled=True),Session([Response({'status':'ok'})]))
        self.assertEqual(c.delete_segment('s@org_x')['status'],'deleted')
        method,url,options=c.session.calls[0]
        self.assertEqual(url,'https://cja.adobe.io/segments/s%40org_x')
        self.assertEqual(options['headers']['x-gw-ims-org-id'],'fake-org')


class DeletionRouteTests(unittest.TestCase):
    def setUp(self):
        import app
        self.web=app;self.http=app.app.test_client()
        self.unified=hasattr(app,'_clients')
        self.directory=tempfile.TemporaryDirectory()
        self.path=patch.object(app,'APP_DIR',Path(self.directory.name));self.path.start()
        records=[segment(i,approved=False,publishingStatus={'published':False}) for i in ('a','b','c')]
        self.client=FakeClient(records)
        self.web._cleanups["aa"].reports.clear();self.web._cleanups["aa"].recent.clear();self.web._cleanups["aa"].pending.clear()
        if self.unified:
            app._clients.clear();app._scope_cache.clear();app._clients['aa']=self.client
            self.params={'tool':'aa','scope_selection':'demo_suite','threshold':'85'}
        else:
            self.client_patch=patch.object(app,'_client',self.client);self.client_patch.start();app._suite_cache.clear()
            self.params={'report_suite_selection':'demo_suite','threshold':'85'}
        self.html=self.http.post('/generate',data=self.params,base_url='http://127.0.0.1').get_data(as_text=True)
        match=re.search(r'context=(\{[^\n]+?\});',self.html)
        self.assertIsNotNone(match)
        self.context=json.loads(match.group(1));self.token=self.context['token']
    def tearDown(self):
        if not self.unified:self.client_patch.stop()
        self.path.stop();self.directory.cleanup()
    def post(self,path,payload,**headers):
        return self.http.post(path,json=payload,headers={'X-Cleanup-Token':self.token,**headers},base_url='http://127.0.0.1')
    def test_rendered_features_and_export_token_is_inactive(self):
        self.assertIn('Segment Deletion',self.html)
        self.assertNotRegex(self.html,r'<th[^>]*>Approved Status</th>')
        self.assertNotIn('class="approval-summary"',self.html)
        self.assertNotIn('id="cleanupType"',self.html)
        targets=list(Path(self.directory.name).rglob('*Dashboard.html'))
        self.assertEqual(len(targets),1)
        self.assertIn('/*CLEANUP_CONTEXT*/null',targets[0].read_text())
        self.assertNotIn(self.token,targets[0].read_text())
    def test_full_preview_execute_refresh_flow(self):
        plan=self.post('/api/segments/delete-preview',{'tool':'aa','ids':['b']})
        self.assertEqual(plan.status_code,200)
        payload={**plan.json,'tool':'aa','delete_confirmed':True,'owner_review_confirmed':True}
        result=self.post('/api/segments/delete',payload)
        self.assertEqual(result.status_code,200);self.assertTrue(result.json['success'])
        refreshed=self.http.get(self.context['refresh'],base_url='http://127.0.0.1')
        self.assertEqual(refreshed.status_code,200)
        self.assertNotIn('"id": "b"',refreshed.get_data(as_text=True))
    def test_default_disabled_no_write(self):
        self.client.config.deletion_enabled=False
        plan=self.post('/api/segments/delete-preview',{'tool':'aa','ids':['b']}).json
        response=self.post('/api/segments/delete',{**plan,'tool':'aa','delete_confirmed':True,'owner_review_confirmed':True})
        self.assertEqual(response.status_code,403);self.assertEqual(self.client.deleted,[])
    def test_without_report_token(self):
        response=self.http.post('/api/segments/delete-preview',json={'tool':'aa','ids':['b']},base_url='http://127.0.0.1')
        self.assertEqual(response.status_code,409)
    def test_cross_origin_or_cross_site_refused(self):
        for headers in ({'Origin':'https://evil.invalid'},{'Sec-Fetch-Site':'cross-site'}):
            self.assertEqual(self.post('/api/segments/delete-preview',{'tool':'aa','ids':['b']},**headers).status_code,403)
        self.assertEqual(self.client.deleted,[])
    def test_malformed_json_or_tool(self):
        for payload in ([],{'tool':[]},{'tool':'invalid'}):
            self.assertEqual(self.post('/api/segments/delete-preview',payload).status_code,400)
    def test_navigation_cannot_delete(self):
        self.assertIn(self.http.get('/api/segments/delete',base_url='http://127.0.0.1').status_code,(404,405))
        self.assertEqual(self.client.deleted,[])
    def test_provider_mismatch_token(self):
        response=self.post('/api/segments/delete-preview',{'tool':'cja','ids':['b']})
        self.assertEqual(response.status_code,409 if self.unified else 400)
    def test_payload_too_large(self):
        response=self.http.post('/api/segments/delete-preview',data='x'*70000,content_type='application/json',base_url='http://127.0.0.1')
        self.assertEqual(response.status_code,413)


if __name__=='__main__':unittest.main()
