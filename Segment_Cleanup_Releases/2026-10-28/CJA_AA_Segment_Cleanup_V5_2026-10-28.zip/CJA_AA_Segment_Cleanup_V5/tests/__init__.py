"""Offline tests; no real credentials or Adobe writes."""
