"""Desktop dashboard ported from the existing Adobe Analytics app; no network or secrets here."""
import json
from datetime import datetime
from html import escape as esc
from governance import approval_status
from deletion_ui import augment_report
from segment_analysis import (
    get_report_suite_name, get_report_suite_id, get_owner_name, get_segment_usage, get_deletion_recommendation,
    get_recommendation_bucket, count_distinct_segments_in_matches, count_unique_segments,
    build_duplicate_groups, render_duplicate_group_rows, definition_issue,
)

REC_CLASS_BY_BUCKET = {
    "cleanup": "recommend-delete",
    "review": "recommend-review",
    "keep": "recommend-keep",
    "unknown": "recommend-review",
}

# A near-duplicate pair can differ by hundreds of tokens. The table shows the
# first N so a row stays readable; the Excel export always carries the full
# list for anyone who needs to audit the whole difference.
DIFF_DISPLAY_LIMIT = 30

DASHBOARD_CSS = """
:root {
  --bg:#f4f7fb; --card:#fff; --text:#172033; --muted:#687386;
  --border:#dfe5ee; --accent:#315efb; --green:#137a4b;
  --greenbg:#e8f7ef; --amber:#996c00; --amberbg:#fff5d9;
  --blue:#1e5bd6; --bluebg:#eaf1ff;
}
* { box-sizing:border-box; }
body { margin:0; font-family:Segoe UI,Arial,sans-serif; background:var(--bg); color:var(--text); }
.container { max-width:1500px; margin:0 auto; padding:32px; }
.header { margin-bottom:24px; }
h1 { margin:0 0 8px; font-size:28px; }
.subtitle { color:var(--muted); font-size:15px; }
.meta { margin-top:10px; color:var(--muted); font-size:13px; }
.toolbar { display:flex; gap:12px; flex-wrap:wrap; margin-top:18px; }
.toolbar button {
  display:inline-flex; align-items:center; gap:6px;
  background:var(--accent); color:#fff; border:0; cursor:pointer;
  font-family:inherit; padding:10px 16px; border-radius:8px; font-size:13px; font-weight:600;
}
.toolbar button.secondary { background:var(--green); }
.toolbar a.change-view {
  display:inline-flex; align-items:center; gap:6px; text-decoration:none;
  background:#5a6575; color:#fff; padding:10px 16px; border-radius:8px;
  font-size:13px; font-weight:600;
}
.toolbar button:hover { opacity:.9; }
.toolbar a.change-view:hover { opacity:.9; }
.cards { display:flex; flex-wrap:wrap; gap:16px; margin:24px 0; }
.card { background:var(--card); border:1px solid var(--border); border-radius:14px; padding:18px; box-shadow:0 2px 8px rgba(30,50,80,.04); flex:1 1 190px; }
.card .label { color:var(--muted); font-size:12.5px; }
.card .value { font-size:27px; font-weight:700; margin-top:6px; }
.card .value.exact-value { color:#c62828; }
.card .value.near-value { color:#ef6c00; }
.card .value.unique-value { color:#137a4b; }
.section { background:var(--card); border:1px solid var(--border); border-radius:14px; padding:22px; margin-top:20px; }
.section h2 { margin:0 0 15px; font-size:20px; }
.section.highlight { background:#fbfcfe; border:1px solid var(--border); }
.table-wrap { overflow-x:auto; }
table { width:100%; border-collapse:collapse; font-size:13px; }
th { text-align:left; background:#f7f9fc; color:#4d586a; padding:12px; border-bottom:2px solid var(--border); white-space:nowrap; }
td { padding:14px 12px; border-bottom:1px solid var(--border); vertical-align:top; line-height:1.45; }
.muted { color:var(--muted); font-size:11px; word-break:break-all; }
.score { font-weight:700; font-size:16px; }
.badge { display:inline-block; padding:6px 9px; border-radius:999px; font-size:11px; font-weight:700; white-space:nowrap; }
.badge.strong { background:var(--greenbg); color:var(--green); }
.badge.review { background:var(--amberbg); color:var(--amber); }
.badge.keep { background:var(--bluebg); color:var(--blue); }
.badge.exact { background:#fdecec; color:#c62828; }
.badge.near { background:#fff3e0; color:#ef6c00; }
.usage-badge { display:inline-block; padding:3px 8px; margin:2px 0; border-radius:6px; background:#f1f4f9; color:#3c4658; font-size:11.5px; }
.usage-note { color:var(--muted); font-size:11.5px; margin-top:6px; }
.empty { padding:30px; text-align:center; color:var(--muted); background:#f8fafc; border-radius:10px; }
.note { color:var(--muted); font-size:13px; line-height:1.6; }
.duplicate-groups-section { margin-top:4px; }
.duplicate-groups-section h3 { margin-bottom:4px; margin-top:22px; }
.group-subtitle { color:var(--muted); font-size:13px; margin-bottom:6px; }
.group-table td { vertical-align:top; }
.group-segment-name { display:block; padding:2px 0; }
.recommend-delete { color:#c62828; font-weight:700; }
.recommend-keep { color:#2e7d32; font-weight:700; }
.recommend-review { color:#ef6c00; font-weight:700; }

/* Collapsible section headers */
h2.card-header-row { display:flex; align-items:center; justify-content:space-between; gap:10px; cursor:pointer; user-select:none; }
h2.card-header-row:hover { color:var(--accent); }
.collapse-toggle { font-size:12.5px; font-weight:600; color:#4d586a; border:1px solid var(--border); border-radius:6px; padding:3px 10px; background:#f7f9fc; white-space:nowrap; }
.collapsible-body.collapsed { display:none; }

/* Per-section toolbar: search, rows-per-page, actions */
.table-toolbar { display:flex; align-items:flex-end; justify-content:space-between; gap:14px; flex-wrap:wrap; margin-bottom:14px; }
.search-box { flex:1 1 340px; }
.search-box input { width:100%; padding:9px 12px; border:1px solid var(--border); border-radius:8px; font-size:13px; font-family:inherit; }
.page-size-control { display:flex; align-items:center; gap:8px; }
.page-size-control label { font-size:12.5px; color:var(--muted); white-space:nowrap; }
.page-size-control select { padding:9px 10px; border:1px solid var(--border); border-radius:8px; font-size:13px; font-family:inherit; background:#fff; }
.btn { border:0; cursor:pointer; font-family:inherit; font-size:12.5px; font-weight:600; padding:9px 14px; border-radius:8px; color:#fff; background:var(--accent); }
.btn:hover { opacity:.9; }
.btn.grey { background:#5a6575; }
.btn.green { background:var(--green); }

/* Numbered pagination */
.pagination { display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; margin-top:14px; }
.pagination-info { color:var(--muted); font-size:12.5px; }
.pagination-buttons { display:flex; gap:5px; flex-wrap:wrap; }
.pagination-buttons button { background:#fff; border:1px solid var(--border); color:var(--text); padding:7px 12px; border-radius:7px; font-size:12.5px; font-family:inherit; cursor:pointer; }
.pagination-buttons button:hover:not(:disabled) { background:#f0f4fb; }
.pagination-buttons button.active { background:var(--accent); border-color:var(--accent); color:#fff; }
.pagination-buttons button:disabled { color:#b7bfcc; cursor:not-allowed; }

/* Long segment names / difference lists wrap instead of forcing the wide
   tables into a horizontal scrollbar. */
table.fixed { table-layout:fixed; }
table.fixed th, table.fixed td { white-space:normal; overflow-wrap:anywhere; word-break:break-word; }

@media(max-width:1100px) {
  .card { flex-basis:45%; }
}
@media(max-width:600px) {
  .container { padding:16px; }
  .card { flex-basis:100%; }
  table.fixed th, table.fixed td { padding:8px 6px; font-size:12px; }
}
"""

DASHBOARD_JS = """
// --- Shared helpers -------------------------------------------------

function escapeHtmlJs(value) {
    const div = document.createElement("div");
    div.textContent = String(value ?? "");
    return div.innerHTML;
}

function csvEscape(value) {
    let text = String(value ?? "");
    if (/^[\\s]*[=+@-]/.test(text) || /^[\\t\\r\\n]/.test(text)) text = "'" + text;
    value = text;
    return '"' + String(value ?? "").replace(/"/g, '""') + '"';
}

function xmlEscape(value) {
    return String(value ?? "").replace(/[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]/g, "")
        .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

function xmlCell(value) {
    return `<Cell><Data ss:Type="String">${xmlEscape(value)}</Data></Cell>`;
}

function timestamp() {
    return new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
}

function downloadBlob(content, filename, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
}

// SpreadsheetML 2003 opens straight into Excel and needs no JS library, so
// the dashboard stays a single self-contained file.
function downloadWorkbook(sheetName, header, rows, filenamePrefix) {
    const body = rows.map(row => `<Row>${row.map(xmlCell).join("")}</Row>`).join("");
    const xml = `<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
<Worksheet ss:Name="${xmlEscape(sheetName)}">
<Table>
<Row>${header.map(xmlCell).join("")}</Row>
${body}
</Table>
</Worksheet>
</Workbook>`;
    downloadBlob(xml, filenamePrefix + timestamp() + ".xls", "application/vnd.ms-excel");
}

function toggleSection(sectionId) {
    const body = document.getElementById(sectionId + "-body");
    const icon = document.getElementById(sectionId + "-icon");
    if (!body) return;
    const heading = document.querySelector('[aria-controls="' + sectionId + '-body"]');
    if (heading) heading.setAttribute('aria-expanded', String(body.classList.contains('collapsed')));
    const collapsed = body.classList.toggle("collapsed");
    if (icon) icon.textContent = collapsed ? "\\u25B8 Expand" : "\\u25BE Collapse";
}

function renderPagination(containerId, page, totalPages, totalItems, startIndex, visibleCount, callbackName) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const from = totalItems ? startIndex + 1 : 0;
    const to = startIndex + visibleCount;

    const buttons = [
        `<button ${page <= 1 ? "disabled" : ""} onclick="${callbackName}(${page - 1})">Previous</button>`
    ];

    const maxButtons = 7;
    const last = Math.min(totalPages, Math.max(1, page - 3) + maxButtons - 1);
    const first = Math.max(1, last - maxButtons + 1);

    for (let p = first; p <= last; p++) {
        buttons.push(`<button class="${p === page ? "active" : ""}" onclick="${callbackName}(${p})">${p}</button>`);
    }

    buttons.push(`<button ${page >= totalPages ? "disabled" : ""} onclick="${callbackName}(${page + 1})">Next</button>`);

    container.innerHTML =
        `<div class="pagination-info">Showing ${from}-${to} of ${totalItems}</div>` +
        `<div class="pagination-buttons">${buttons.join("")}</div>`;
}

// --- Available Adobe Analytics segments ----------------------------------------

const segmentState = { filtered: SEGMENTS_DATA.slice(), page: 1, pageSize: 10 };

function renderSegmentPage() {
    const total = segmentState.filtered.length;
    const totalPages = Math.max(1, Math.ceil(total / segmentState.pageSize));
    if (segmentState.page > totalPages) segmentState.page = totalPages;

    const start = (segmentState.page - 1) * segmentState.pageSize;
    const pageItems = segmentState.filtered.slice(start, start + segmentState.pageSize);

    document.getElementById("segmentBody").innerHTML = total === 0
        ? '<tr><td colspan="6"><div class="empty">No segments match this search.</div></td></tr>'
        : pageItems.map((s, i) => `<tr>
            <td>${start + i + 1}</td>
            <td><b>${escapeHtmlJs(s.name)}</b><div class="muted">${escapeHtmlJs(s.id)}</div></td>
            <td>${escapeHtmlJs(s.reportSuite)}<div class="muted">${escapeHtmlJs(s.rsid)}</div></td>
            <td>${escapeHtmlJs(s.owner)}</td>
            <td>${escapeHtmlJs(s.approval)}</td>
            <td>${escapeHtmlJs(s.description || "-")}<div class="muted">${escapeHtmlJs(s.analysisStatus)}</div></td>
          </tr>`).join("");

    renderPagination("segmentPagination", segmentState.page, totalPages, total,
                     start, pageItems.length, "gotoSegmentPage");
}

function gotoSegmentPage(page) {
    segmentState.page = page;
    renderSegmentPage();
}

function filterSegments() {
    const search = (document.getElementById("segmentSearch").value || "").trim().toLowerCase();
    segmentState.filtered = SEGMENTS_DATA.filter(s => String(s.name || "").toLowerCase().includes(search));
    segmentState.page = 1;
    renderSegmentPage();
}

function clearSegmentSearch() {
    document.getElementById("segmentSearch").value = "";
    filterSegments();
}

function changeSegmentPageSize() {
    segmentState.pageSize = Number(document.getElementById("segmentPageSize").value) || 10;
    segmentState.page = 1;
    renderSegmentPage();
}

function downloadSegmentsExcel() {
    if (!segmentState.filtered.length) {
        alert("There is no segment data available to download.");
        return;
    }
    downloadWorkbook(
        "Available Segments",
        ["Segment Name", "Segment ID", "Report Suite Name", "Report Suite ID", "Owner", "Description", "Analysis status", "Approved Status"],
        segmentState.filtered.map(s => [s.name, s.id, s.reportSuite, s.rsid, s.owner, s.description, s.analysisStatus, s.approval]),
        "AA_Available_Segments_"
    );
}

// --- Duplicate / near-duplicate comparison --------------------------

const comparisonState = { filtered: MATCHES_DATA.slice(), page: 1, pageSize: 10 };

function renderComparisonPage() {
    const total = comparisonState.filtered.length;
    const totalPages = Math.max(1, Math.ceil(total / comparisonState.pageSize));
    if (comparisonState.page > totalPages) comparisonState.page = totalPages;

    const start = (comparisonState.page - 1) * comparisonState.pageSize;
    const pageItems = comparisonState.filtered.slice(start, start + comparisonState.pageSize);

    document.getElementById("comparisonBody").innerHTML = total === 0
        ? '<tr><td colspan="8"><div class="empty">No duplicate or near-duplicate segments were identified.</div></td></tr>'
        : pageItems.map((m, i) => `<tr>
            <td>${start + i + 1}</td>
            <td><span class="badge ${m.type === "Exact duplicate" ? "exact" : "near"}">${escapeHtmlJs(m.type)}</span></td>
            <td><span class="score">${m.similarity.toFixed(1)}%</span></td>
            <td><b>${escapeHtmlJs(m.aName)}</b><div class="muted">${escapeHtmlJs(m.aId)}</div><div class="muted">${escapeHtmlJs(m.aRsid)}</div></td>
            <td><b>${escapeHtmlJs(m.bName)}</b><div class="muted">${escapeHtmlJs(m.bId)}</div><div class="muted">${escapeHtmlJs(m.bRsid)}</div></td>
            <td>
              <span class="usage-badge">A approval: ${escapeHtmlJs(m.aApproval)}</span><br>
              <span class="usage-badge">B approval: ${escapeHtmlJs(m.bApproval)}</span><br>
              <span class="usage-badge">A: <b>${m.aCount}</b> dashboard(s)</span><br>
              <span class="usage-badge">B: <b>${m.bCount}</b> dashboard(s)</span><br>
              <span class="usage-badge">A known shared: <b>${m.aShared}</b></span><br>
              <span class="usage-badge">B known shared: <b>${m.bShared}</b></span>
            </td>
            <td>
              <span class="${m.recClass}">${escapeHtmlJs(m.recText)}</span>
              <div class="usage-note">${escapeHtmlJs(m.recDetail)}</div>
            </td>
            <td>
              <b>Only in A:</b> ${escapeHtmlJs(m.onlyADisplay || "None")}
              <br><br>
              <b>Only in B:</b> ${escapeHtmlJs(m.onlyBDisplay || "None")}
            </td>
          </tr>`).join("");

    renderPagination("comparisonPagination", comparisonState.page, totalPages, total,
                     start, pageItems.length, "gotoComparisonPage");
}

function gotoComparisonPage(page) {
    comparisonState.page = page;
    renderComparisonPage();
}

function filterComparisonResults() {
    const search = (document.getElementById("comparisonSearch").value || "").trim().toLowerCase();
    comparisonState.filtered = MATCHES_DATA.filter(m =>
        String(m.aName || "").toLowerCase().includes(search) ||
        String(m.bName || "").toLowerCase().includes(search)
    );
    comparisonState.page = 1;
    renderComparisonPage();
}

function clearComparisonSearch() {
    document.getElementById("comparisonSearch").value = "";
    filterComparisonResults();
}

function changeComparisonPageSize() {
    comparisonState.pageSize = Number(document.getElementById("comparisonPageSize").value) || 10;
    comparisonState.page = 1;
    renderComparisonPage();
}

function comparisonRows(matches) {
    return matches.map(m => [
        m.type, m.similarity.toFixed(1), m.aName, m.aId, m.aRsid, m.aCount, m.aShared,
        m.bName, m.bId, m.bRsid, m.bCount, m.bShared, m.recText, m.recDetail, m.onlyA, m.onlyB, m.aApproval, m.bApproval,
    ]);
}

const COMPARISON_HEADER = [
    "Type", "Similarity (%)", "Segment A Name", "Segment A ID", "Segment A Report Suite ID",
    "Segment A Dashboard Count", "Segment A Known Shared Count",
    "Segment B Name", "Segment B ID", "Segment B Report Suite ID", "Segment B Dashboard Count",
    "Segment B Known Shared Count", "Cleanup Recommendation",
    "Recommendation Detail", "Only in A", "Only in B", "Segment A Approved Status", "Segment B Approved Status",
];

function downloadComparisonExcel(matches) {
    const rows = matches || MATCHES_DATA;
    if (!rows.length) {
        alert("There is no comparison data available to download.");
        return;
    }
    downloadWorkbook("Comparison Results", COMPARISON_HEADER, comparisonRows(rows),
                     "AA_Segment_Comparison_");
}

function downloadFilteredComparisonExcel() {
    downloadComparisonExcel(comparisonState.filtered);
}

// --- Full segment list (includes the definition JSON, which the Excel
// --- export above deliberately leaves out to stay readable) ----------

function downloadSegmentsCsv() {
    const header = ["#", "Segment Name", "Segment ID", "Report Suite Name", "Report Suite ID", "Owner", "Description", "Definition (JSON)", "Analysis status", "Approved Status"]
        .map(csvEscape).join(",");

    const rows = SEGMENTS_DATA.map((s, i) =>
        [i + 1, s.name, s.id, s.reportSuite, s.rsid, s.owner, s.description, s.definition, s.analysisStatus, s.approval].map(csvEscape).join(",")
    );

    downloadBlob(header + "\\n" + rows.join("\\n") + "\\n",
                 "AA_Segment_List_" + timestamp() + ".csv", "text/csv;charset=utf-8;");
}

renderSegmentPage();
renderComparisonPage();
"""


def build_dashboard_html(
    segments,
    matches,
    usage_map,
    usage_loaded,
    threshold,
    segment_csv_filename,
    scope_label="All Report Suites",
):
    total_segments = len(segments)

    # Data embedded directly in the page so the downloads, search and
    # pagination all work purely in-browser, regardless of how many segments
    # there are or where the HTML file is opened from. This avoids the
    # file:// "download" attribute restriction that browsers apply to plain
    # links pointing at local files, and lets both big tables render a page
    # at a time instead of as one giant static table.
    segments_for_js = [
        {
            "name": s.get("name", "(No name)"),
            "id": s.get("id", "(No ID)"),
            "reportSuite": get_report_suite_name(s),
            "rsid": get_report_suite_id(s),
            "owner": get_owner_name(s),
            "description": s.get("description", "") or "",
            "definition": json.dumps(s.get("definition"), ensure_ascii=False),
            "analysisStatus": definition_issue(s) or "Assessed",
            "approval": approval_status(s),
        }
        for s in segments
    ]

    matches_for_js = []

    for match in matches:
        a, b = match["a"], match["b"]
        usage_a = get_segment_usage(usage_map, a)
        usage_b = get_segment_usage(usage_map, b)
        recommendation = get_deletion_recommendation(match, usage_map, usage_loaded)
        bucket = get_recommendation_bucket(recommendation["text"])

        only_a = match["diff"]["onlyA"]
        only_b = match["diff"]["onlyB"]

        matches_for_js.append(
            {
                "type": match["type"],
                "aApproval": approval_status(a),
                "bApproval": approval_status(b),
                "similarity": round(match["similarity"], 1),
                "aName": a.get("name", ""),
                "aId": a.get("id", ""),
                "aRsid": get_report_suite_id(a),
                "aCount": usage_a["count"] if usage_loaded or usage_a["count"] else "Unknown",
                "aShared": usage_a["sharedPublishedCount"] or "Not verified",
                "bName": b.get("name", ""),
                "bId": b.get("id", ""),
                "bRsid": get_report_suite_id(b),
                "bCount": usage_b["count"] if usage_loaded or usage_b["count"] else "Unknown",
                "bShared": usage_b["sharedPublishedCount"] or "Not verified",
                "recText": recommendation["text"],
                "recDetail": recommendation["detail"],
                "recClass": REC_CLASS_BY_BUCKET[bucket],
                "onlyA": ", ".join(only_a),
                "onlyB": ", ".join(only_b),
                "onlyADisplay": ", ".join(only_a[:DIFF_DISPLAY_LIMIT]),
                "onlyBDisplay": ", ".join(only_b[:DIFF_DISPLAY_LIMIT]),
                "bucket": bucket,
            }
        )

    # Scorecards show the count of DISTINCT segments involved in each
    # duplicate type, not the number of pairwise comparison rows - same as
    # countDistinctSegmentsInMatches() in the HTML tool. A segment that
    # appears in several duplicate pairs is only counted once, and a
    # segment can count toward both "exact" and "near" if it has both.
    exact_distinct_count = count_distinct_segments_in_matches(matches, "Exact duplicate")
    near_distinct_count = count_distinct_segments_in_matches(matches, "Near duplicate")
    unique_segment_count = count_unique_segments(segments, matches)
    unassessed_count = sum(bool(definition_issue(s)) for s in segments)

    # Duplicate "clusters" via connected components - same grouping logic
    # as the HTML tool: if A=B and B=C, A, B and C are shown as one group
    # instead of two separate pairwise rows.
    exact_groups = build_duplicate_groups(matches, "Exact duplicate")
    near_groups = build_duplicate_groups(matches, "Near duplicate")
    exact_group_rows_html = render_duplicate_group_rows(exact_groups, True, usage_map, usage_loaded)
    near_group_rows_html = render_duplicate_group_rows(near_groups, False, usage_map, usage_loaded)

    usage_status = (
        "Accessible projects checked (not organisation-wide proof of non-use)"
        if usage_loaded
        else "Could not be verified this run (recommendations default to Review)"
    )
    generated = datetime.now().strftime("%d %b %Y, %I:%M %p")

    def js_safe(data):
        # Prevent a literal "</script>" inside embedded JSON from closing
        # the surrounding <script> tag early.
        return json.dumps(data, ensure_ascii=False).replace("</", "<\\/")

    segments_json = js_safe(segments_for_js)
    matches_json = js_safe(matches_for_js)

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Adobe Analytics Segment Cleanup Dashboard</title>
<style>{DASHBOARD_CSS}</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>Adobe Analytics Segment Cleanup Dashboard</h1>
    <div class="subtitle">Definition-based analysis with accessible Workspace references; deletion requires explicit server enablement</div>
    <div class="meta">
      Generated: {generated} &nbsp; | &nbsp; Scope: {esc(scope_label)} &nbsp; | &nbsp;
      Segments analyzed: {total_segments} &nbsp; | &nbsp;
      Similarity threshold: {threshold:g}% &nbsp; | &nbsp; Workspace usage: {usage_status}
    </div>
    <div class="toolbar">
      <a class="change-view" href="/">&#8592; Change Report Suite</a>
      <button onclick="downloadSegmentsCsv()">&#11015; Download Full Segment List (CSV)</button>
      <button class="secondary" onclick="downloadComparisonExcel()">&#11015; Download Comparison Results (Excel)</button>
    </div>
  </div>

  <div class="section highlight">
    <h2>Adobe Analytics Segment Summary</h2>
    <div class="cards">
      <div class="card"><div class="label">Total segments</div><div class="value">{total_segments}</div></div>
      <div class="card"><div class="label">Exact duplicates</div><div class="value exact-value">{exact_distinct_count}</div></div>
      <div class="card"><div class="label">Near duplicates</div><div class="value near-value">{near_distinct_count}</div></div>
      <div class="card"><div class="label">Unique segments (at this threshold)</div><div class="value unique-value">{unique_segment_count}</div></div>
    </div>

    <p class="note">Not assessed: <b>{unassessed_count}</b> (missing/unsupported definitions or parent suite). These are not counted as unique.
    Exact/near cards count distinct members and can overlap; pair counts are in the comparison table.
    Suites are compared separately. Similarity is structural Jaccard, not audience overlap or proof of equivalent business intent.</p>
    <div class="duplicate-groups-section">
      <h3>Exact Duplicate Groups</h3>
      <div class="group-subtitle">
        Segments chained together through exact-duplicate matches are grouped into a single row
        (e.g. if A = B and B = C, then A, B and C appear together).
      </div>
      <div class="table-wrap">
        <table class="group-table">
          <thead>
            <tr>
              <th style="width:5%">#</th>
              <th style="width:25%">Segment Names</th>
              <th style="width:20%">Report Suite Name</th>
              <th style="width:12%">Approved Status</th>
              <th style="width:13%">Workspace Usage</th>
              <th style="width:25%">Cleanup Recommendation</th>
            </tr>
          </thead>
          <tbody>{exact_group_rows_html}</tbody>
        </table>
      </div>

      <h3>Near-Duplicate Groups</h3>
      <div class="group-subtitle">
        Connected near-match pairs at the selected threshold. A ~ B and B ~ C does not guarantee A ~ C; review the pairwise table.
      </div>
      <div class="table-wrap">
        <table class="group-table">
          <thead>
            <tr>
              <th style="width:5%">#</th>
              <th style="width:25%">Segment Names</th>
              <th style="width:20%">Report Suite Name</th>
              <th style="width:12%">Approved Status</th>
              <th style="width:13%">Workspace Usage</th>
              <th style="width:25%">Cleanup Recommendation</th>
            </tr>
          </thead>
          <tbody>{near_group_rows_html}</tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="section">
    <h2 class="card-header-row" role="button" tabindex="0" aria-expanded="false" aria-controls="segmentsCard-body" onkeydown="if(event.key==='Enter'||event.key===' '){{event.preventDefault();this.click();}}" onclick="toggleSection('segmentsCard')">
      <span>Available Adobe Analytics Segments</span>
      <span class="collapse-toggle" id="segmentsCard-icon">&#9656; Expand</span>
    </h2>
    <div class="collapsible-body collapsed" id="segmentsCard-body">
      <div class="table-toolbar">
        <div class="search-box">
          <input id="segmentSearch" type="text" placeholder="Search by segment name..." oninput="filterSegments()">
        </div>
        <div class="page-size-control">
          <label for="segmentPageSize">Rows per page</label>
          <select id="segmentPageSize" onchange="changeSegmentPageSize()">
            <option value="10" selected>10</option>
            <option value="20">20</option>
            <option value="30">30</option>
            <option value="40">40</option>
            <option value="50">50</option>
            <option value="100">100</option>
          </select>
        </div>
        <button class="btn grey" onclick="clearSegmentSearch()">Clear Search</button>
        <button class="btn green" onclick="downloadSegmentsExcel()">Download Excel</button>
      </div>
      <div class="table-wrap">
        <table class="fixed">
          <thead>
            <tr>
              <th style="width:5%">#</th>
              <th style="width:27%">Segment Name</th>
              <th style="width:18%">Report Suite Name</th>
              <th style="width:14%">Owner</th>
              <th style="width:12%">Approved Status</th>
              <th style="width:24%">Description</th>
            </tr>
          </thead>
          <tbody id="segmentBody"></tbody>
        </table>
      </div>
      <div class="pagination" id="segmentPagination"></div>
    </div>
  </div>

  <div class="section">
    <h2 class="card-header-row" role="button" tabindex="0" aria-expanded="false" aria-controls="comparisonCard-body" onkeydown="if(event.key==='Enter'||event.key===' '){{event.preventDefault();this.click();}}" onclick="toggleSection('comparisonCard')">
      <span>Duplicate / Near-Duplicate Segments</span>
      <span class="collapse-toggle" id="comparisonCard-icon">&#9656; Expand</span>
    </h2>
    <div class="collapsible-body collapsed" id="comparisonCard-body">
      <div class="table-toolbar">
        <div class="search-box">
          <input id="comparisonSearch" type="text" placeholder="Search comparison results by segment name..." oninput="filterComparisonResults()">
        </div>
        <div class="page-size-control">
          <label for="comparisonPageSize">Rows per page</label>
          <select id="comparisonPageSize" onchange="changeComparisonPageSize()">
            <option value="10" selected>10</option>
            <option value="20">20</option>
            <option value="30">30</option>
            <option value="40">40</option>
            <option value="50">50</option>
            <option value="100">100</option>
          </select>
        </div>
        <button class="btn grey" onclick="clearComparisonSearch()">Clear Search</button>
        <button class="btn green" onclick="downloadFilteredComparisonExcel()">Download Excel</button>
      </div>
      <div class="table-wrap">
        <table class="fixed">
          <thead>
            <tr>
              <th style="width:5%">#</th>
              <th style="width:11%">Type</th>
              <th style="width:8%">Similarity</th>
              <th style="width:15%">Segment A</th>
              <th style="width:15%">Segment B</th>
              <th style="width:14%">Workspace Dashboard Usage</th>
              <th style="width:15%">Cleanup Recommendation</th>
              <th style="width:17%">Differences</th>
            </tr>
          </thead>
          <tbody id="comparisonBody"></tbody>
        </table>
      </div>
      <div class="pagination" id="comparisonPagination"></div>
    </div>
  </div>

  <div class="section">
    <h2>Reviewing the full segment library</h2>
    <p class="note">Report exports are read-only. The running app has a separate opt-in guarded deletion workflow. Workspace counts include only projects visible to the API account.
    Known shared counts show positive share evidence only; "Not verified" means share metadata was unavailable or no positive evidence was supplied.
    Zero accessible references does not mean globally unused. Approval, publishing and all other dependencies require owner verification.
    Excel downloads use Excel-compatible SpreadsheetML (.xls), not native .xlsx.</p>
    <p class="note">
      "Available Adobe Analytics Segments" above lists every segment pulled from Adobe Analytics, including ones with no
      duplicate match. Its Excel download covers the rows currently shown by the search filter.
      For a full offline review that also includes each segment's <b>definition JSON</b>, use the
      "Download Full Segment List (CSV)" button at the top of the page.
    </p>
  </div>
</div>

<script>
const SEGMENTS_DATA = {segments_json};
const MATCHES_DATA = {matches_json};
</script>
<script>{DASHBOARD_JS}</script>

</body>
</html>"""
    return augment_report(html, segments, usage_map, usage_loaded, get_report_suite_id, get_owner_name, definition_issue)

