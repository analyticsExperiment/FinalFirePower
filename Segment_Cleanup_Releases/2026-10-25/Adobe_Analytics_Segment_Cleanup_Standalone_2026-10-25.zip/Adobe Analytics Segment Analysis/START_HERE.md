# Adobe Analytics Segment Cleanup — Standalone

Release: 25 October 2026. Extract the complete folder before running. All required local Python modules are included; do not copy app.py alone.

## Quick start

Open a terminal inside this extracted app folder. Use Python 3.10 or later:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
cp .env.example .env
```

Edit your local `.env` and enter your authorised AA_* credentials. Real credentials are intentionally not included in this public package. Then run:

```bash
.venv/bin/python app.py
```

Open http://127.0.0.1:5001. Keep the server terminal running.

Windows: use `py -m venv .venv` and `.venv\Scripts\python` instead of the Linux Python paths, and copy `.env.example` to `.env` using File Explorer or your editor. Windows execution was not certified in this release.

## Safety and verification

Live deletion is disabled by default. Leave the deletion flags at `0`. See README.md and FEATURE_PARITY.md before any deliberate activation. Approval, publication and accessible Workspace usage must be verified; unknown metadata blocks deletion. Owner approval and dependencies outside accessible projects still require review. No live Adobe deletion was performed in release testing.

For offline tests:

```bash
.venv/bin/python -m unittest discover -s tests -v
```

The optional deletion simulator is clearly labelled, uses only sample data, and blocks external network requests. It is not the live app. Do not run live verification scripts unless real read-only API access has been approved.

The archive contains source, tests, setup documentation, a blank example configuration and PACKAGE_MANIFEST.json with individual file hashes. It excludes real environment files, credentials, token caches, virtual environments, generated reports, audit logs, captured inventories, screenshots and private validation exports.

For this release, VERIFICATION.md is a package-specific check summary. Older local validation exports and evidence are not distributed. References to this developer laptop or sibling applications in the original README are contextual only; the commands above apply to a fresh extraction.
