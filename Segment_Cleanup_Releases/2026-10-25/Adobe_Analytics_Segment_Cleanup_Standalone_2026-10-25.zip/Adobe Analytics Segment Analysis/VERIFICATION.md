# Package verification — 25 October 2026

Application: Adobe Analytics Segment Analysis.

- Offline suite: 101 passed, 1 skipped (102 total). The standalone skip is a CJA-only transport case.
- Both updated apps passed desktop synthetic preview/confirmation/cancel/single/bulk/partial-outcome/refresh flows. External requests were blocked in the deletion simulator. The V3 CJA flow was also simulated.
- Browser CSV and full/filtered SpreadsheetML download readback passed, including approval fields and scope IDs. The .xls output is SpreadsheetML XML, not native .xlsx.
- Frozen-input regression and matching/grouping preservation checks passed. No captured inventory, report or private evidence is included here.
- A small real read-only API probe passed for CJA and Analytics. Sample CJA publishing status was not returned; that case remains blocked as unverified.
- Live deletion remains disabled by default. No real Adobe DELETE or write-permission validation was performed.
- Packages are extracted into fresh temporary folders and their complete offline suites rerun with external network requests blocked before publication. PACKAGE_MANIFEST.json hashes every distributed file except itself.

Windows, native Microsoft Excel, production hosting and mobile view were not certified. See FEATURE_PARITY.md for the implementation comparison and limits. Historical private evidence and output directories are excluded.
