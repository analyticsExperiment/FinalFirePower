"""Adobe Analytics Segment Cleanup — same desktop workflow as the CJA app."""
from pathlib import Path
from collections import Counter
from html import escape
import logging
import os
import threading
import time
import webbrowser
from urllib.parse import urlencode
from flask import Flask, jsonify, request
from aa_client import Config, AdobeAnalyticsClient, AdobeError
from suite_picker import PICKER_STYLE, PICKER_SCRIPT
import segment_analysis as core
from deletion_workflow import DeletionWorkflow, register_routes
from deletion_ui import bind_live

APP_DIR = Path(__file__).resolve().parent
HOST = "127.0.0.1"
PORT = int(os.environ.get("AA_PORT", "5001"))
CACHE_TTL_SECONDS = 120
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 65536
logging.getLogger("werkzeug").setLevel(logging.WARNING)
_client = None
_suite_cache = {}
_cache_lock = threading.RLock()
_pipeline_lock = threading.Lock()
cleanup = DeletionWorkflow(core, lambda: APP_DIR)
register_routes(app, cleanup, False, {'aa':_pipeline_lock})

PAGE_STYLE = """
<style>
:root {
  --bg:#f4f7fb; --card:#fff; --text:#1d2939; --muted:#667085;
  --border:#d8e0ea; --accent:#4169f6; --accent-dark:#3158e6;
  --green:#2e7d32; --green-bg:#edf7ed; --red:#c62828; --red-bg:#fdecea;
}
* { box-sizing:border-box; }
body { margin:0; min-height:100vh; font-family:Arial,Helvetica,sans-serif; background:var(--bg); color:var(--text); }
.container { max-width:1400px; margin:0 auto; padding:70px 20px 44px; }
.panel { background:var(--card); padding:34px 20px; border-radius:8px; box-shadow:0 2px 9px rgba(0,0,0,.09); }
.panel h2 { margin:6px 0 20px; font-size:24px; }
.landing-shell { display:flex; justify-content:center; align-items:flex-start; min-height:100vh; padding:88px 24px 48px; }
.landing-card { width:100%; max-width:590px; padding:32px; border:1px solid #dde4ed; border-radius:12px; background:var(--card); box-shadow:0 4px 16px rgba(29,41,57,.08); }
.landing-card h1 { margin:0 0 5px; font-size:25px; line-height:1.25; font-weight:700; letter-spacing:-.2px; }
.landing-subtitle { margin:0 0 26px; color:var(--muted); font-size:14px; line-height:1.45; }
.field + .field { margin-top:18px; }
label { display:block; margin:0 0 7px; font-size:13px; line-height:1.3; font-weight:700; }
select, input { width:100%; height:42px; padding:9px 12px; border:1px solid var(--border); border-radius:7px; background:#fff; color:var(--text); font:14px Arial,Helvetica,sans-serif; }
select:focus, input:focus, button:focus-visible { outline:3px solid rgba(20,115,230,.22); outline-offset:1px; border-color:var(--accent); }
select:disabled { background:#f4f4f4; color:#999; }
.hint { margin-top:7px; color:var(--muted); font-size:12px; line-height:1.45; }
button { border:0; border-radius:7px; padding:11px 18px; font:600 14px Arial,Helvetica,sans-serif; cursor:pointer; }
button.primary { background:var(--accent); color:#fff; }
button.primary:hover:not(:disabled) { background:var(--accent-dark); }
button:disabled { opacity:.56; cursor:not-allowed; }
.generate-row { margin-top:23px; }
.generate-row .primary { width:100%; height:44px; }
.status { margin:0 0 18px; padding:0; font-size:13px; line-height:1.45; }
.status:empty { display:none; }
.status.error { padding:11px 13px; border-radius:5px; color:var(--red); background:var(--red-bg); }
.error-card { max-width:760px; margin:80px auto; }
a.back { display:inline-block; margin-top:18px; color:var(--accent); text-decoration:none; font-weight:600; }
</style>
"""


def get_client():
    global _client
    with _cache_lock:
        if _client is None:
            _client = AdobeAnalyticsClient(Config.load())
        return _client


def get_report_suites_cached(client):
    key = client.cache_identity
    with _cache_lock:
        cached = _suite_cache.get(key)
        if cached and time.monotonic() - cached[0] < CACHE_TTL_SECONDS:
            return cached[1]
    suites = client.get_report_suites()
    with _cache_lock:
        _suite_cache[key] = (time.monotonic(), suites)
    return suites


@app.before_request
def restrict_local_requests():
    if request.host.split(":")[0] not in ("127.0.0.1", "localhost"):
        return "Local access only", 403
    origin = request.headers.get("Origin")
    if origin and origin != request.host_url.rstrip("/"):
        return "Cross-origin requests are not allowed", 403


@app.after_request
def privacy_headers(response):
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "same-origin"
    response.headers["X-Frame-Options"] = "DENY"
    return response


@app.get("/")
def index():
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Adobe Analytics Segment Cleanup</title>
{PAGE_STYLE}
{PICKER_STYLE}
</head>
<body>
<main class="landing-shell">
  <section class="landing-card" aria-labelledby="cleanupHeading">
    <h1 id="cleanupHeading">Adobe Analytics Segment Cleanup</h1>
    <p class="landing-subtitle">Select a report suite and generate the dashboard.</p>
    <div id="status" class="status" role="status" aria-live="polite"></div>

    <form id="reportForm" action="/generate" method="post">
      <div id="reportSuitePanel">
        <div class="field">
        <label for="reportSuiteSelect">Report Suite</label>
        <select id="reportSuiteSelect" name="report_suite_selection" disabled required>
          <option value="">Loading Report Suites...</option>
        </select>
        </div>

        <div class="field">
        <label for="threshold">Similarity Threshold (%)</label>
        <input id="threshold" name="threshold" type="number" min="1" max="100" step="1" value="85">
        <div class="hint">Segments at or above this similarity are flagged as near-duplicates. 85 is a starting point for manual review, not audience overlap.</div>
        </div>

        <div class="generate-row">
          <button id="generateButton" class="primary" type="submit" disabled>Generate Dashboard</button>
        </div>
      </div>
    </form>
  </section>
</main>

{PICKER_SCRIPT}
<script>
const select = document.getElementById('reportSuiteSelect');
const generateButton = document.getElementById('generateButton');
const statusBox = document.getElementById('status');
const reportForm = document.getElementById('reportForm');
const suitePicker = new ReportSuitePicker(select);
suitePicker.setEnabled(true);

function setStatus(message, kind = '') {{
  statusBox.className = 'status' + (kind ? ' ' + kind : '');
  statusBox.textContent = message;
}}

async function loadReportSuites() {{
  select.replaceChildren(new Option('Loading Report Suites...', ''));
  select.disabled = true;
  generateButton.disabled = true;
  suitePicker.refresh();
  setStatus('');
  try {{
    const response = await fetch('/api/report-suites', {{headers: {{'Accept':'application/json'}}}});
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || 'Unable to load Report Suites.');

    select.replaceChildren(new Option('All Report Suites', 'ALL'));
    for (const reportSuite of payload.reportSuites || []) {{
      select.appendChild(new Option(reportSuite.name || reportSuite.id, String(reportSuite.id)));
    }}
    if (!(payload.reportSuites || []).length) throw new Error('No accessible Report Suites were returned.');
    select.disabled = false;
    select.value = 'ALL';
    generateButton.disabled = false;
    setStatus('');
  }} catch (error) {{
    setStatus('ERROR: ' + error.message, 'error');
    select.replaceChildren(new Option('Unable to load Report Suites', ''));
  }} finally {{
    suitePicker.refresh();
  }}
}}

select.addEventListener('change', () => {{
  const ready = Boolean(select.value);
  generateButton.disabled = !ready;
}});

reportForm.addEventListener('submit', event => {{
  if (!select.value) {{
    event.preventDefault();
    setStatus('Please select a Report Suite before generating the report.', 'error');
    select.focus();
    return;
  }}
  generateButton.disabled = true;
  generateButton.textContent = 'Generating...';
  setStatus('');
}});

loadReportSuites();
</script>
</body>
</html>"""


@app.get("/api/report-suites")
def api_report_suites():
    try:
        client = get_client()
        suites = get_report_suites_cached(client)
        names = Counter(str(s.get("name") or s["id"]) for s in suites)
        clean = [{"id": str(s["id"]), "name": str(s.get("name") or s["id"]) +
                  (f' ({s["id"]})' if names[str(s.get("name") or s["id"])] > 1 else "")} for s in suites]
        return jsonify({"reportSuites": clean, "count": len(clean)})
    except AdobeError as error:
        return jsonify({"error": str(error)}), 502
    except Exception:
        return jsonify({"error": "Unable to load Report Suites. Check the server configuration."}), 502


@app.get("/favicon.ico")
def favicon():
    return "", 204


def render_report(values):
    selection = (values.get("report_suite_selection") or "").strip()
    if not selection:
        return error_page("Please select a Report Suite before generating the report.")
    try:
        threshold = core.validate_threshold(values.get("threshold", "85"))
        client = get_client()
        suites = get_report_suites_cached(client)
        # Lock the complete run, including reads, to avoid parallel report overwrites.
        with _pipeline_lock:
            result = core.run_pipeline(cleanup.view_client('aa', client), threshold=threshold, output_dir=APP_DIR / "output" / "reports",
                                       report_suite_selection=selection, suites=suites)
            token = cleanup.register('aa', client, result, selection)
        refresh = '/dashboard?' + urlencode({'report_suite_selection':selection, 'threshold':threshold})
        return bind_live(result["dashboard_html"], token, 'aa',
                         bool(getattr(getattr(client, 'config', None), 'deletion_enabled', False)), refresh)
    except ValueError as error:
        return error_page(str(error))
    except AdobeError as error:
        return error_page(str(error), status=502)
    except Exception:
        return error_page("The report could not be generated. No Adobe data was changed.", status=500)


@app.post("/generate")
def generate():
    return render_report(request.form)


@app.get("/dashboard")
def dashboard():
    return render_report(request.args)


def error_page(message, status=400):
    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<title>Adobe Analytics — Error</title>{PAGE_STYLE}</head><body>
<main class="container error-card"><section class="panel"><h1>Could not generate the report</h1>
<div class="status error">{escape(str(message))}</div>
<a class="back" href="/">&larr; Back to Report Suites</a></section></main></body></html>""", status


if __name__ == "__main__":
    print(f"Adobe Analytics Segment Cleanup: http://{HOST}:{PORT}")
    if os.environ.get("AA_OPEN_BROWSER", "1") == "1":
        threading.Timer(1, lambda: webbrowser.open(f"http://{HOST}:{PORT}")).start()
    app.run(host=HOST, port=PORT, debug=False, threaded=True)
