"""Read-only command-line entry point and Python reuse facade."""
import argparse
import json
import sys
from aa_client import AdobeAnalyticsClient, Config, AdobeError
from segment_analysis import (run_pipeline, prepare_segments, find_duplicate_segments,
                              build_duplicate_groups, normalized_definition, tokenize)


def main():
    parser = argparse.ArgumentParser(description="Read-only Adobe Analytics segment definition analysis")
    parser.add_argument("--suite", default="ALL", help="Report Suite ID or ALL; no cross-suite comparisons")
    parser.add_argument("--threshold", default=85, type=float)
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--json", action="store_true", help="Return full findings as JSON instead of a short summary")
    args = parser.parse_args()
    try:
        result = run_pipeline(AdobeAnalyticsClient(Config.load()), args.threshold,
                              output_dir=args.output_dir, report_suite_selection=args.suite)
        result.pop("dashboard_html", None)
        if not args.json:
            for key in ("segments", "matches", "usage_map"):
                result.pop(key, None)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (AdobeError, ValueError) as error:
        print(json.dumps({"error": str(error)}), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
