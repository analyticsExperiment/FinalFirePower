# Adobe Analytics Segment Cleanup

This is a separate Adobe Analytics version of the existing **CJA Segment AnalysisV2** Python app. The CJA app has not been changed. The landing card, grouped report layout, scorecards, search, pagination and downloads follow the same desktop workflow.

## Start the app on this laptop

```bash
cd '/home/rajavel/development/Nodeapps/CJA MCP Analysis/Adobe Analytics Segment Analysis'
.venv/bin/python app.py
```

Open **http://127.0.0.1:5001**. The app automatically loads the accessible Report Suites. Choose **All Report Suites** or one suite, set the similarity threshold and click **Generate Dashboard**. **Change Report Suite** takes you back to the same landing page. No separate “Show Data Views” button or credentials notice is shown.

The server binds only to the local computer. It is a local development/demo app, not a production hosting setup. To use another port or stop automatic browser opening:

```bash
AA_PORT=5003 AA_OPEN_BROWSER=0 .venv/bin/python app.py
```

## Credentials

Credentials stay on the Python server. They are not added to the page, browser requests, downloaded reports or source code.

Configuration order:

1. An explicit `AA_ENV_FILE` path, if provided.
2. This new app's `.env`, if present.
3. The existing sibling `cja-segment-cleanup-poc/.env` on this laptop, if present.
4. Process environment settings override file values.

The existing file is only read. It is not modified or copied. The app accepts dedicated `AA_CLIENT_ID` (or `AA_API_KEY`), `AA_CLIENT_SECRET`, `AA_SCOPES`, `AA_ORG_ID` and `AA_GLOBAL_COMPANY_ID`. Existing `ADOBE_CLIENT_ID`, `ADOBE_CLIENT_SECRET`, `ADOBE_SCOPES` and `ADOBE_ORG_ID` are supported as fallbacks. A manually managed `AA_ACCESS_TOKEN` is also supported.

Example with an explicit configuration path:

```bash
AA_ENV_FILE='/absolute/path/to/approved/.env' .venv/bin/python app.py
```

Use `.env.example` for a fresh installation. Use the scopes assigned to an **Adobe Analytics API** integration in Adobe Developer Console; a CJA-only integration may not have Analytics access. If the company ID is missing, Discovery selects it only when there is one matching company. When several companies are accessible, set `AA_GLOBAL_COMPANY_ID` explicitly. The app will not silently choose the first company.

Automatic OAuth tokens are cached privately in `.aa_token_cache.json` with owner-only file permissions and a configuration fingerprint. The cache and real `.env` files are excluded by `.gitignore`. Do not include them or private reports when sharing the app.

## Installation on another computer

Python 3.10 or later is recommended. Create a virtual environment, then install the dependencies:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python app.py
```

On this Debian laptop, `ensurepip` is not available, so the environment was created locally and its packages were installed using the already available `uv pip install --python .venv/bin/python -r requirements.txt`. No system packages or existing CJA dependencies were changed.

For Windows, use `py -m venv .venv`, `.venv\Scripts\python -m pip install -r requirements.txt`, then `.venv\Scripts\python app.py`. Windows execution has not been tested here.

Dependencies: Flask 3.1.2, python-dotenv 1.1.1 and requests 2.32.5. Offline tests use Python's built-in `unittest`; no test package is required.

## What has changed from CJA

| CJA app | Adobe Analytics app |
|---|---|
| Data Views | Report Suites, loaded automatically |
| `cja.adobe.io` | `analytics.adobe.io` |
| CJA org-scoped API calls | Analytics company-scoped API calls |
| `/data/dataviews` | `/api/{company}/reportsuites/collections/suites` |
| Segment filter `dataviewIds` | Segment filter `rsid` |
| CJA segments and projects | Analytics `/segments` and `/projects` |
| CJA token cache | Separate private AA token cache |
| Port 5000 | Port 5001 by default |

The UI still provides total, exact-member, near-member and unique scorecards; exact and near groups; full available segments; per-pair rule differences; accessible Workspace references; search; page-size selection; CSV and Excel-compatible downloads.

Duplicate suite names are shown with suite IDs in the dropdown. Suite IDs are also included in inventory and comparison exports.

### Report Suite scrolling fix — 24 October 2026

The native popup was reproduced closing on mouse-wheel scrolling in desktop Chrome, in this app and unified V3. Its 268 options (All + 267 suites) did not reload during the failure.

The Report Suite control now uses a bounded, scrollable picker with search by suite name or ID. Scrolling keeps it open; choosing an option commits the value. Escape/outside click dismiss it, and arrow keys/Enter support keyboard selection. The original select retains its form name and submitted value. Analysis logic, API calls and credentials are unchanged.

`suite_picker.py` contains the local CSS/JavaScript and **must be included when copying the Python files**. It adds no package or external-script dependency. Restart an older running server and refresh the browser after updating.

Verified on desktop Chrome/Linux: scrolling/search/selection with the live 267-suite list, form-value preservation, synthetic individual/empty/All suite report generation and return navigation, and 52 offline tests. Windows/mobile behaviour and a fresh live segment-analysis audit are outside this fix's verification.

## Comparison rules and limitations

- **Exact duplicate:** the complete canonical definition matches within the same parent Report Suite. Object key order and ordinary AND/OR predicate order are normalised. Names and descriptions do not determine a match.
- **Near duplicate:** typed, position-aware definition tokens meet the selected Jaccard threshold. The score is `100 × intersection / union`. The default threshold is 85%.
- Sequence order, container scope, exclusions, operators, component IDs, metric/dimension functions, values, types and array multiplicity are retained. A 100% token score alone is never promoted to an exact match.
- **All Report Suites does not mix schemas.** Segments are compared within their recorded parent suite. This avoids treating the same eVar/event ID in two differently configured suites as equivalent.
- The API's segment `rsid` is its parent Report Suite, not a list of every suite where the segment can be used. A virtual-suite selection with `parentRsid` analyses parent-suite definitions and says so in the report; it does not evaluate the VRS population filter. The dropdown uses the Collections Suites API, not a separate full VRS inventory.
- Empty, unreadable or unsupported top-level definitions and unknown parent suites are marked **Not assessed**, kept in the inventory, and excluded from duplicate and unique counts. This performs structural checks, not Adobe's complete definition validation.
- **Unique** means an assessable segment has no exact/qualifying near match at the chosen threshold within its parent suite. It does not prove unique audience membership.
- Exact and near scorecards count distinct members, not pairs. A segment can appear in both cards. Connected near groups do not mean every pair in a group meets the threshold; use the pairwise table for evidence.
- Similarity is a definition-review aid, **not audience overlap or proof of business equivalence**. No Analytics reporting queries or audience-population comparisons are performed.

These safeguards intentionally improve unsafe edge cases in the original matcher. The new implementation is not expected to reproduce the original CJA false positives for empty definitions, reordered sequences or cross-suite comparisons.

## Workspace guidance and guarded deletion — 25 October 2026

Only projects visible to the current API account can be checked. Segment references in each accessible project are counted once per segment. Missing project details or API failures make usage **incomplete/unknown**, not “unused”. Positive references remain visible even if another project's details are unavailable.

Approved/published or positively used segments receive protective guidance. Other matches require owner and business-rule review. Zero accessible project references is not proof of global non-use. Dependencies outside accessible Workspace projects, scheduling, publishing destinations, hidden approval metadata and other tools still require manual checks.

Known shared counts show positive share metadata only. “Not verified” is used where no positive share evidence was returned; curation or approval is not treated as sharing.

The colleague update has now been integrated: approval counts/status, per-member group usage, defensive owner metadata handling and a **Segment Deletion** panel with single/bulk selection. See [FEATURE_PARITY.md](FEATURE_PARITY.md).

Live deletion is **disabled by default**. It requires deliberately setting `AA_ENABLE_DELETION=1` on the server and restarting. No real environment file was changed and no live Adobe deletion was performed. The panel performs a fresh read-only preview and blocks approved, published, used, changed, unreadable or unknown-metadata segments. Execution requires a report-bound one-use preview, fresh segment/Workspace checks, typed `DELETE` and explicit owner/outside-dependency review. A batch retains at least one known exact copy and accepts at most 200 IDs. Private audit records precede writes; pending/uncertain outcomes are not assumed successful or automatically retried.

The ordinary transport still permits GET and IMS token POST only. A separate opt-in method can issue DELETE only to this company's Analytics segment endpoint. There are no segment creation/update functions or project/suite deletion functions. Saved/offline reports cannot execute deletion. Approval is tri-state: missing metadata is **Unknown**, not Not Approved. It is also included in inventory/comparison downloads.

## Output files and downloads

The latest local run writes private files under `output/reports/`:

- `AA_Segment_List.csv`: all selected inventory rows, suite IDs, definition JSON and assessment status.
- `AA_Segment_Cleanup_Dashboard.html`: self-contained report with embedded inventory and findings. Search, pagination and exports work offline; “Change Report Suite” needs the running app.

The next run replaces these latest-run files. Save or download a copy if a run must be retained. Reports contain private segment/project information even though they contain no credentials.

Browser downloads:

- Full Segment List (CSV): all selected segments, independent of search.
- Top Comparison Results (Excel): all matching pairs, independent of search.
- Available Segments Download Excel: all inventory rows matching the active search, not only the visible page.
- Comparison Download Excel: all pairs matching the active search, not only the visible page.

Excel files use SpreadsheetML 2003 XML with `.xls`, matching the original dependency-free approach. They are not native `.xlsx`; Microsoft Excel may show a file-format notice. Native Microsoft Excel was not available for testing. CSV formula-like text is prefixed with an apostrophe for safer opening in spreadsheet tools. HTML and XML text are escaped.

## File and function map

```text
app.py — Flask entry point; landing page, suite API, form and local-only safeguards
  get_client() → aa_client.Config.load() → AdobeAnalyticsClient
  get_report_suites_cached() → AdobeAnalyticsClient.get_report_suites()
  generate() → segment_analysis.run_pipeline()

aa_client.py — server configuration, IMS authentication, read AA calls and opt-in mutation mixin
  token() → POST IMS token/v3; private cache
  resolve_company() → GET discovery/me when company is not configured
  paged() → complete array/envelope pagination, deduplication, incomplete-read checks
  get_report_suites() / get_segments(rsid) / get_projects() / get_project(id)

segment_analysis.py — reusable analysis, no Flask dependency
  prepare_segments() / definition_issue()
  canonicalize() / normalized_definition() / tokenize()
  find_duplicate_segments() → exact grouping + inverted-index near candidates
  build_duplicate_groups() → connected components
  load_workspace_usage() / get_deletion_recommendation() → review guidance only
  export_segment_csv() / run_pipeline()

report_ui.py — inherited desktop CSS/JS, HTML report and browser downloads
  build_dashboard_html()

suite_picker.py — local scrollable/searchable Report Suite control; original form value retained

governance.py — tri-state approval and fail-closed deletion checks
segment_mutation.py — fresh segment GET and narrow opt-in DELETE, with no automatic mutation retries
deletion_workflow.py — report/preview tokens, fresh checks, bounded batches, private audit and outcome tracking
deletion_ui.py — approval cards and desktop cleanup/confirmation controls

aa_segment_finder.py — non-interactive CLI and Python reuse facade
tests/ — synthetic offline cases, QA-only server and opt-in live verification
```

`get_deletion_recommendation` retains a familiar helper name for migration, but returns guidance only and does not delete anything.

## Without the web UI

```bash
.venv/bin/python aa_segment_finder.py --suite ALL --threshold 85
.venv/bin/python aa_segment_finder.py --suite YOUR_RSID --threshold 90 --json
```

`--json` returns counts, prepared segments, matches, usage and local output paths. It does not include tokens. Keep this output private because definitions and Workspace names are included. A minimal Python call is:

```python
from aa_client import Config, AdobeAnalyticsClient
from segment_analysis import run_pipeline

result = run_pipeline(AdobeAnalyticsClient(Config.load()),
                      report_suite_selection="ALL", threshold=85)
print(result["segment_count"], result["match_count"])
```

## Verification

```bash
.venv/bin/python -m unittest discover -s tests -v
```

Offline tests do not contact Adobe. For a clearly marked synthetic desktop report, run `.venv/bin/python tests/serve_fixture.py` and open `http://127.0.0.1:5002`. That QA server never contacts Adobe and is not the real app.

For the separately labelled deletion simulator, run `.venv/bin/python tests/serve_deletion_fixture.py` on port 5007. It blocks external requests and simulates deletion only. `tests/browser_deletion_flow.js` checks its desktop workflow.

The optional `.venv/bin/python tests/verify_live.py` performs real read-only inventory/project reads, checks exact grouping with a separate normal form and verifies inverted-index pair coverage against an exhaustive same-suite scan. It creates private outputs under `output/live-verification/` and prints count-only results. Run it only with approved credentials.

See [VERIFICATION.md](VERIFICATION.md) for the checked results and remaining limits. `source_baseline.json` records hashes of the original CJA source/test files so they can be checked for accidental changes.

## Official API references

- [Discovery and company selection](https://developer.adobe.com/analytics-apis/docs/2.0/guides/endpoints/discovery)
- [Report Suites API](https://developer.adobe.com/analytics-apis/docs/2.0/guides/endpoints/report-suites)
- [Segments API and parent-suite filter](https://developer.adobe.com/analytics-apis/docs/2.0/guides/endpoints/segments/)
- [Segment definition functions](https://developer.adobe.com/analytics-apis/docs/2.0/guides/endpoints/segments/definition)
- [Workspace Projects API](https://developer.adobe.com/analytics-apis/docs/2.0/guides/endpoints/projects/)
