"""Synthetic Adobe-shaped fixtures. These are not live customer data."""
from copy import deepcopy


def predicate(name="variables/evar1", value="checkout"):
    return {"func": "streq", "val": {"func": "attr", "name": name}, "str": value}


def definition(pred=None, context="visits"):
    return {"func": "segment", "version": [1, 0, 0], "container": {
        "func": "container", "context": context, "pred": pred or predicate()}}


def segment(identifier="s1", pred=None, rsid="demo_suite", **kwargs):
    return {"id": identifier, "name": "Segment " + identifier, "rsid": rsid,
            "reportSuiteName": "Demo Suite", "ownerFullName": "Demo owner",
            "description": "Synthetic QA example", "definition": definition(pred), **kwargs}


class FixtureClient:
    cache_identity = "synthetic-fixture-only"

    def get_report_suites(self):
        return [{"id": "demo_suite", "name": "Demo Suite"},
                {"id": "other_suite", "name": "Other Suite"},
                {"id": "empty_suite", "name": "Empty Suite"}]

    def get_segments(self, rsid=None):
        rules = {"func": "and", "preds": [predicate(f"variables/evar{i}", f"value {i}") for i in range(1, 11)]}
        items = [segment(f"exact{i}", deepcopy(rules), name=f"Checkout — exact {i}") for i in range(3)]
        for i in range(3):
            changed = deepcopy(rules)
            changed["preds"][0]["str"] = f"variant {i}"
            items.append(segment(f"near{i}", changed, name=f"Checkout — variant {i}"))
        for i in range(15):
            items.append(segment(f"unique{i}", {"func": "event-exists", "evt": {"func": "event", "name": f"metrics/event{i}"}}, name=f"Campaign {i:02d}"))
        items += [segment("missing", definition=None, name="Definition unavailable"),
                  segment("cross", deepcopy(rules), rsid="other_suite", reportSuiteName="Other Suite", name="Other suite checkout")]
        return [s for s in items if rsid is None or s["rsid"] == rsid]

    def get_projects(self):
        return [{"id": "project1", "name": "Synthetic checkout workspace", "definition": {
            "panels": [{"segment": "exact0"}, {"segment": "exact0"}]}},
                {"id": "project2", "name": "Synthetic shared workspace", "externalReferences": [{"id": "near0"}],
                 "shares": [{"type": "group"}]}]

    def get_project(self, project_id):
        raise AssertionError("Fixture projects are already expanded")
