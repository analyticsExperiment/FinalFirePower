import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch
import app as web
from tests.fixtures import FixtureClient


class AppTests(unittest.TestCase):
    def setUp(self):
        self.client = web.app.test_client()
        self.fixture = FixtureClient()
        web._suite_cache.clear()
        self.override = patch("app.get_client", return_value=self.fixture)
        self.override.start()

    def tearDown(self):
        self.override.stop()

    def get(self, path):
        return self.client.get(path, base_url="http://127.0.0.1")

    def post(self, data):
        return self.client.post("/generate", data=data, base_url="http://127.0.0.1")

    def test_landing_auto_load_same_workflow(self):
        response = self.get("/")
        html = response.get_data(as_text=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn("loadReportSuites();", html)
        self.assertIn("All Report Suites", html)
        self.assertNotIn("Show Data Views", html)
        self.assertNotIn("credentials are loaded", html)
        self.assertIn("max-width:590px", html)
        self.assertEqual(response.headers["Cache-Control"], "no-store")
        self.assertEqual(response.headers["Referrer-Policy"], "same-origin")

    def test_suite_api_only_safe_labels(self):
        data = self.get("/api/report-suites").json
        self.assertEqual(data["count"], 3)
        self.assertEqual(set(data["reportSuites"][0]), {"id", "name"})

    def test_report_suite_picker_keeps_original_form_control(self):
        html = self.get("/").get_data(as_text=True)
        self.assertIn('id="reportSuiteSelect" name="report_suite_selection"', html)
        self.assertIn('class ReportSuitePicker', html)
        self.assertIn('suitePicker.setEnabled(true)', html)
        self.assertIn('overscroll-behavior:contain', html)

    def test_duplicate_suite_names_disambiguated(self):
        with patch.object(self.fixture, "get_report_suites", return_value=[{"id": "one", "name": "Demo"}, {"id": "two", "name": "Demo"}]):
            names = [s["name"] for s in self.get("/api/report-suites").json["reportSuites"]]
        self.assertEqual(names, ["Demo (one)", "Demo (two)"])

    def test_favicon_has_no_console_404(self):
        self.assertEqual(self.get("/favicon.ico").status_code, 204)

    def test_api_failure_sanitized(self):
        with patch("app.get_client", side_effect=RuntimeError("private-secret")):
            response = self.get("/api/report-suites")
        self.assertEqual(response.status_code, 502)
        self.assertNotIn("private-secret", response.get_data(as_text=True))

    def test_required_selection_and_finite_threshold(self):
        self.assertEqual(self.post({}).status_code, 400)
        for invalid in ("nan", "inf", "0", "101", "bad"):
            self.assertEqual(self.post({"report_suite_selection": "ALL", "threshold": invalid}).status_code, 400)

    def test_invalid_suite_rejected_before_segment_read(self):
        with patch.object(self.fixture, "get_segments") as fetch:
            response = self.post({"report_suite_selection": "not-accessible", "threshold": "85"})
        self.assertEqual(response.status_code, 400)
        fetch.assert_not_called()

    def test_report_and_return_link(self):
        with tempfile.TemporaryDirectory() as directory, patch("app.APP_DIR", Path(directory)):
            response = self.post({"report_suite_selection": "ALL", "threshold": "85"})
        self.assertEqual(response.status_code, 200)
        html = response.get_data(as_text=True)
        for value in ("Change Report Suite", "Exact Duplicate Groups", "Near-Duplicate Groups", "Unique segments", "Download Comparison Results"):
            self.assertIn(value, html)
        self.assertIn('href="/"', html)

    def test_empty_suite_still_renders_report(self):
        with tempfile.TemporaryDirectory() as directory, patch("app.APP_DIR", Path(directory)):
            response = self.post({"report_suite_selection": "empty_suite", "threshold": "85"})
        self.assertEqual(response.status_code, 200)
        self.assertIn("No exact-duplicate groups found", response.get_data(as_text=True))

    def test_cross_origin_and_untrusted_host_denied(self):
        response = self.client.post("/generate", base_url="http://127.0.0.1", headers={"Origin": "https://evil.example"})
        self.assertEqual(response.status_code, 403)
        self.assertEqual(self.client.get("/", base_url="http://evil.example").status_code, 403)

    def test_error_html_escaped(self):
        html, status = web.error_page("<script>evil</script>")
        self.assertNotIn("<script>", html)
        self.assertEqual(status, 400)


if __name__ == "__main__":
    unittest.main()
