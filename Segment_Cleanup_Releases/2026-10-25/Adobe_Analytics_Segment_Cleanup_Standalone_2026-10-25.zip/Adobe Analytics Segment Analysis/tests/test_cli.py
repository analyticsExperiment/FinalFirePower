from contextlib import redirect_stdout, redirect_stderr
from io import StringIO
import json
import unittest
from unittest.mock import patch
import aa_segment_finder as cli
from aa_client import AdobeError


class CliTests(unittest.TestCase):
    def test_json_runner_omits_html_and_keeps_findings(self):
        output = StringIO()
        payload = {"segment_count": 2, "matches": [{"type": "Exact duplicate"}], "segments": [],
                   "usage_map": {}, "dashboard_html": "<!doctype html>"}
        with patch("sys.argv", ["aa_segment_finder.py", "--suite", "fixture-suite", "--threshold", "90", "--json"]), \
             patch("aa_segment_finder.Config.load"), patch("aa_segment_finder.AdobeAnalyticsClient"), \
             patch("aa_segment_finder.run_pipeline", return_value=payload) as run, redirect_stdout(output):
            self.assertEqual(cli.main(), 0)
        parsed = json.loads(output.getvalue())
        self.assertEqual(parsed["segment_count"], 2)
        self.assertNotIn("dashboard_html", parsed)
        self.assertEqual(run.call_args.kwargs["report_suite_selection"], "fixture-suite")

    def test_runner_sanitised_error(self):
        output = StringIO()
        with patch("sys.argv", ["aa_segment_finder.py"]), \
             patch("aa_segment_finder.Config.load", side_effect=AdobeError("Configuration is missing.")), redirect_stderr(output):
            self.assertEqual(cli.main(), 1)
        self.assertEqual(json.loads(output.getvalue()), {"error": "Configuration is missing."})
