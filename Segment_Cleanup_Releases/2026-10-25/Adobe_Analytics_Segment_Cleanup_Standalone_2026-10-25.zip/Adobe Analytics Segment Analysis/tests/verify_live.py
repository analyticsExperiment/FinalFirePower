"""Opt-in read-only live check. Prints counts only; no credentials or IDs.

Run: .venv/bin/python tests/verify_live.py
Creates private reports and a count-only QA record under output/live-verification/.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from collections import Counter, defaultdict
from itertools import combinations
import json
import math
import os
import time

from aa_client import Config, AdobeAnalyticsClient, IMS_URL
import segment_analysis as core


class ObservedClient(AdobeAnalyticsClient):
    def __init__(self, config):
        super().__init__(config)
        self.request_counts = Counter()
        self.project_count = None

    def _request(self, method, url, **kwargs):
        service = "IMS authentication" if url == IMS_URL else "Analytics"
        self.request_counts[f"{method} {service}"] += 1
        return super()._request(method, url, **kwargs)

    def get_projects(self):
        records = super().get_projects()
        self.project_count = len(records)
        return records


def independent_normal_form(value):
    """Independent exact grouping oracle, not the application's canonicaliser."""
    if isinstance(value, list):
        return [independent_normal_form(item) for item in value]
    if not isinstance(value, dict):
        return value
    result = {key: independent_normal_form(item) for key, item in sorted(value.items())}
    if result.get("func") in ("and", "or") and isinstance(result.get("preds"), list):
        result["preds"].sort(key=lambda item: json.dumps(item, sort_keys=True))
    return result


def verify():
    start = time.monotonic()
    client = ObservedClient(Config.load())
    suites = client.get_report_suites()
    segments = client.get_segments()
    directory = Path(__file__).resolve().parents[1] / "output" / "live-verification"
    result = core.run_pipeline(client, output_dir=directory, segments=segments, suites=suites)
    by_suite, exact_groups = defaultdict(list), defaultdict(list)
    for segment in result["segments"]:
        if core.definition_issue(segment):
            continue
        norm = json.dumps(independent_normal_form(segment["definition"]), sort_keys=True, separators=(",", ":"))
        by_suite[segment["rsid"]].append((str(segment["id"]), norm, core.tokenize(segment)))
        exact_groups[(segment["rsid"], norm)].append(str(segment["id"]))
    expected_exact = {tuple(sorted(pair)) for group in exact_groups.values() for pair in combinations(group, 2)}
    actual_exact = {tuple(sorted([str(m["a"]["id"]), str(m["b"]["id"])])) for m in result["matches"] if m["type"] == "Exact duplicate"}
    expected_near, possible = set(), 0
    for group in by_suite.values():
        possible += math.comb(len(group), 2)
        for a, b in combinations(group, 2):
            if a[1] == b[1]:
                continue
            # Exhaustive scan validates that the inverted index misses no eligible pair.
            score = 100 * len(a[2] & b[2]) / len(a[2] | b[2])
            if score >= 85:
                expected_near.add(tuple(sorted([a[0], b[0]])))
    actual_near = {tuple(sorted([str(m["a"]["id"]), str(m["b"]["id"])])) for m in result["matches"] if m["type"] == "Near duplicate"}
    assert expected_exact == actual_exact, "Exact grouping disagrees with independent normal form"
    assert expected_near == actual_near, "Inverted index differs from exhaustive pair scan"
    assert all(m["a"]["rsid"] == m["b"]["rsid"] for m in result["matches"]), "Cross-suite pair found"
    assert not any(key not in ("GET Analytics", "POST IMS authentication") for key in client.request_counts), "Unexpected write request"
    summary = {key: result[key] for key in ("segment_count", "assessed_count", "unassessed_count", "match_count", "exact_count", "near_count", "unique_count", "usage_loaded", "threshold")}
    summary.update({"report_suite_count": len(suites), "segment_parent_suite_count": len(by_suite),
                    "accessible_project_count": client.project_count, "possible_same_suite_pairs": possible,
                    "independent_exact_grouping": "PASS", "exhaustive_candidate_coverage": "PASS",
                    "cross_suite_protection": "PASS", "request_counts": dict(client.request_counts),
                    "analytics_writes": 0, "elapsed_seconds": round(time.monotonic() - start, 2)})
    target = directory / "verification_counts.json"
    target.write_text(json.dumps(summary, indent=2) + "\n")
    os.chmod(target, 0o600)
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    verify()
