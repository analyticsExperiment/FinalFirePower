"""Read back the synthetic browser downloads after the desktop QA flow."""
from collections import Counter
from pathlib import Path
import csv
import json
import xml.etree.ElementTree as ET


def verify():
    directory = Path(__file__).resolve().parents[1] / "output" / "playwright"
    rows = list(csv.DictReader((directory / "fixture-full.csv").open(encoding="utf-8-sig")))
    assert len(rows) == 23
    assert "Report Suite ID" in rows[0]
    assert sum(row["Analysis status"] != "Assessed" for row in rows) == 1
    assert all(json.loads(row["Definition (JSON)"]) is None or isinstance(json.loads(row["Definition (JSON)"]), dict) for row in rows)
    namespace = {"s": "urn:schemas-microsoft-com:office:spreadsheet"}
    counts = {}
    for name, expected in [("fixture-comparisons.xls", 15), ("fixture-filtered-segments.xls", 7), ("fixture-filtered-comparisons.xls", 5)]:
        root = ET.parse(directory / name).getroot()
        records = root.findall(".//s:Row", namespace)
        counts[name] = len(records) - 1
        assert len(records) - 1 == expected, (name, len(records) - 1)
        widths = {len(row.findall("s:Cell", namespace)) for row in records}
        assert len(widths) == 1, (name, widths)
        values = [[cell.text or "" for cell in row.findall("s:Cell/s:Data", namespace)] for row in records]
        if name == "fixture-comparisons.xls":
            mapped = [dict(zip(values[0], row)) for row in values[1:]]
            assert Counter(row["Type"] for row in mapped) == {"Exact duplicate": 3, "Near duplicate": 12}
            assert all(row["Segment A Report Suite ID"] == row["Segment B Report Suite ID"] for row in mapped)
    print(json.dumps({"full_csv_rows": len(rows), "xml_excel_row_counts": counts,
                      "headers_and_column_widths": "PASS", "missing_definition_retained": "PASS",
                      "comparison_types_and_suite_ids": "PASS"}, indent=2))


if __name__ == "__main__":
    verify()
