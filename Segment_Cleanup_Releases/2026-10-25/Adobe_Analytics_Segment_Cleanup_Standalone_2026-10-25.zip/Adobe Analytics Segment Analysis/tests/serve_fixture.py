"""QA-only desktop server: explicitly synthetic data; never contacts Adobe."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app
from tests.fixtures import FixtureClient
app._client = FixtureClient()
app.APP_DIR = Path(__file__).resolve().parents[1] / "output" / "fixture-qa"


@app.app.after_request
def mark_synthetic(response):
    if response.mimetype == "text/html":
        response.set_data(response.get_data(as_text=True).replace("<body>", '<body><aside style="padding:8px;background:#fff3cc;text-align:center">SYNTHETIC QA DATA — NOT A LIVE ADOBE REPORT</aside>', 1))
    return response


if __name__ == "__main__":
    app.app.run(host="127.0.0.1", port=5002, debug=False)
