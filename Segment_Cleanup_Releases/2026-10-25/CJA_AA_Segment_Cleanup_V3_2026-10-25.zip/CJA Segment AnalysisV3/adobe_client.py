"""Shared read-only Adobe transport/authentication and Analytics adapter."""

from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import quote
import hashlib
import json
import math
import os
import tempfile
import threading
import time

from dotenv import dotenv_values
import requests
from segment_mutation import SegmentMutationMixin

APP_DIR = Path(__file__).resolve().parent
AA_BASE = "https://analytics.adobe.io"
IMS_URL = "https://ims-na1.adobelogin.com/ims/token/v3"
SEGMENT_EXPANSION = (
    "reportSuiteName,ownerFullName,modified,tags,compatibility,definition,"
    "publishingStatus,definitionLastModified,categories,approved"
)
PROJECT_EXPANSION = "reportSuiteName,ownerFullName,modified,tags,accessLevel,externalReferences,definition"


class AdobeError(RuntimeError):
    """Only sanitised messages may be returned to the UI or CLI."""


@dataclass(repr=False)
class Config:
    client_id: str = field(repr=False)
    client_secret: str = field(default="", repr=False)
    scopes: str = field(default="", repr=False)
    access_token: str = field(default="", repr=False)
    org_id: str = ""
    company_id: str = ""
    provider: str = "aa"
    token_cache: Path = APP_DIR / ".aa_token_cache.json"
    source: str = "environment"
    deletion_enabled: bool = False

    @classmethod
    def load(cls, provider="aa"):
        if provider not in ("cja", "aa"):
            raise AdobeError("Choose CJA or Adobe Analytics.")
        prefix = provider.upper()
        explicit = os.environ.get(prefix + "_ENV_FILE") or os.environ.get("SEGMENT_ENV_FILE")
        local = APP_DIR / ".env"
        existing = APP_DIR.parent / ("CJA Segment AnalysisV2" if provider == "cja" else "cja-segment-cleanup-poc") / ".env"
        path = Path(explicit).expanduser().resolve() if explicit else (local if local.is_file() else existing)
        if explicit and not path.is_file():
            raise AdobeError(f"{prefix}_ENV_FILE does not point to an existing configuration file.")
        values = dict(dotenv_values(path)) if path.is_file() else {}
        values.update(os.environ)  # Explicit process settings take precedence.

        def setting(*names):
            return next((str(values[n]).strip() for n in names if values.get(n)), "")

        config = cls(
            client_id=setting(prefix + "_CLIENT_ID", prefix + "_API_KEY", "ADOBE_CLIENT_ID"),
            client_secret=setting(prefix + "_CLIENT_SECRET", "ADOBE_CLIENT_SECRET"),
            scopes=setting(prefix + "_SCOPES", "ADOBE_SCOPES"),
            access_token=setting(prefix + "_ACCESS_TOKEN"),
            org_id=setting(prefix + "_ORG_ID", "ADOBE_ORG_ID"),
            company_id=setting("AA_GLOBAL_COMPANY_ID") if provider == "aa" else "",
            provider=provider,
            token_cache=APP_DIR / ("." + provider + "_token_cache.json"),
            source=str(path) if path.is_file() else "environment",
            deletion_enabled=setting(prefix + "_ENABLE_DELETION") == "1",
        )
        if not config.client_id or not (config.access_token or (config.client_secret and config.scopes)):
            raise AdobeError(f"Configure {prefix}_CLIENT_ID and {prefix}_CLIENT_SECRET + {prefix}_SCOPES (or {prefix}_ACCESS_TOKEN) on the server.")
        if provider == "cja" and not config.org_id:
            raise AdobeError("Configure CJA_ORG_ID on the server.")
        return config


class AdobeAnalyticsClient(SegmentMutationMixin):
    BASE_URL = AA_BASE

    def __init__(self, config, session=None, page_size=100):
        self.config = config
        self.session = session or requests.Session()
        self.page_size = page_size
        self.company_id = config.company_id
        self._token = config.access_token
        self._expires = float("inf") if config.access_token else 0
        self._lock = threading.RLock()

    @property
    def cache_identity(self):
        # Fingerprint only; never log or export this or any credential value.
        raw = "|".join([self.config.provider, self.config.client_id, self.config.org_id, self.config.scopes,
                        self.config.client_secret, self.config.access_token, self.config.company_id])
        return hashlib.sha256(raw.encode()).hexdigest()

    def _request(self, method, url, **kwargs):
        # There is deliberately no arbitrary URL or Analytics write interface.
        if not ((method == "GET" and url.startswith(self.BASE_URL + "/")) or
                (method == "POST" and url == IMS_URL)):
            raise AdobeError("This application permits only the selected Adobe provider's reads and IMS authentication.")
        for attempt in range(3):
            try:
                response = self.session.request(method, url, timeout=(10, 45), allow_redirects=False, **kwargs)
            except requests.RequestException:
                if attempt == 2:
                    raise AdobeError("Adobe could not be reached. Check connectivity and retry.") from None
                time.sleep(2 ** attempt)
                continue
            if response.status_code == 429 or 500 <= response.status_code < 600:
                if attempt < 2:
                    try:
                        delay = float(response.headers.get("Retry-After", 2 ** attempt))
                    except (ValueError, TypeError):
                        delay = 2 ** attempt
                    time.sleep(min(10, max(0, delay)) if math.isfinite(delay) else 2 ** attempt)
                    continue
            if not 200 <= response.status_code < 300:
                # Adobe error bodies can contain request or credential details. Do not echo them.
                hint = " Check the API product profile and token permissions." if response.status_code in (401, 403) else ""
                raise AdobeError(f"Adobe returned HTTP {response.status_code}.{hint}")
            try:
                data = response.json()
            except ValueError:
                raise AdobeError("Adobe returned a non-JSON response.") from None
            if isinstance(data, dict) and (data.get("error") or data.get("error_code")):
                raise AdobeError("Adobe returned an API error. Verify server configuration and permissions.")
            return data
        raise AdobeError("Adobe request could not be completed.")

    def token(self, force=False):
        with self._lock:
            if not force and self._token and time.time() < self._expires - 300:
                return self._token
            if self.config.access_token:
                return self.config.access_token
            if not force:
                try:
                    cached = json.loads(self.config.token_cache.read_text())
                    if cached.get("identity") == self.cache_identity and time.time() < cached["expires_at"] - 300:
                        self._token, self._expires = cached["access_token"], cached["expires_at"]
                        return self._token
                except (OSError, ValueError, KeyError, TypeError):
                    pass
            payload = self._request("POST", IMS_URL, data={
                "grant_type": "client_credentials", "client_id": self.config.client_id,
                "client_secret": self.config.client_secret, "scope": self.config.scopes,
            })
            if not isinstance(payload, dict) or not isinstance(payload.get("access_token"), str):
                raise AdobeError("IMS did not return an access token.")
            try:
                lifetime = float(payload.get("expires_in", 0))
                if lifetime > 7 * 86400:  # Some older IMS responses express milliseconds.
                    lifetime /= 1000
                if not math.isfinite(lifetime) or lifetime <= 0:
                    raise ValueError
            except (TypeError, ValueError):
                raise AdobeError("IMS returned an invalid token expiry.") from None
            self._token, self._expires = payload["access_token"], time.time() + lifetime
            # Atomic private token cache. Failure to cache does not fail authentication.
            temporary = None
            try:
                fd, temporary = tempfile.mkstemp(prefix=".aa-token-", dir=self.config.token_cache.parent)
                with os.fdopen(fd, "w") as handle:
                    json.dump({"identity": self.cache_identity, "access_token": self._token,
                               "expires_at": self._expires}, handle)
                os.replace(temporary, self.config.token_cache)
            except OSError:
                pass
            finally:
                if temporary and os.path.exists(temporary):
                    os.unlink(temporary)
            return self._token

    def _headers(self):
        return {"Accept": "application/json", "x-api-key": self.config.client_id,
                "Authorization": "Bearer " + self.token()}

    def _get(self, url, params=None):
        headers = self._headers()
        try:
            return self._request("GET", url, params=params, headers=headers)
        except AdobeError as error:
            if "HTTP 401" not in str(error) or self.config.access_token:
                raise
            headers["Authorization"] = "Bearer " + self.token(force=True)
            return self._request("GET", url, params=params, headers=headers)

    def resolve_company(self):
        with self._lock:
            if self.company_id:
                return self.company_id
            discovery = self._get(AA_BASE + "/discovery/me")
            companies = set()
            for org in discovery.get("imsOrgs", []) if isinstance(discovery, dict) else []:
                if self.config.org_id and org.get("imsOrgId") != self.config.org_id:
                    continue
                companies.update(str(c["globalCompanyId"]) for c in org.get("companies", []) if c.get("globalCompanyId"))
            if len(companies) != 1:
                raise AdobeError("Company selection is missing or ambiguous. Set AA_GLOBAL_COMPANY_ID for the required company.")
            self.company_id = companies.pop()
            return self.company_id

    def get(self, resource, params=None):
        if not resource.startswith(("reportsuites/collections/suites", "segments", "projects")) or ".." in resource:
            raise AdobeError("Unsupported read-only Analytics resource.")
        company = quote(self.resolve_company(), safe="")
        return self._get(f"{AA_BASE}/api/{company}/{resource}", params)

    def paged(self, resource, keys, params=None):
        """Bare-array and Spring-style envelope pagination; never silently truncate."""
        records, seen, page_fingerprints = [], set(), set()
        for page in range(1000):
            payload = self.get(resource, {**(params or {}), "page": page, "limit": self.page_size})
            if isinstance(payload, list):
                items, meta = payload, {}
            elif isinstance(payload, dict):
                items = next((payload[k] for k in ("content", *keys) if isinstance(payload.get(k), list)), None)
                meta = payload
                if items is None:
                    raise AdobeError("Adobe returned an unexpected paginated response.")
            else:
                raise AdobeError("Adobe returned an unexpected paginated response.")
            if any(not isinstance(item, dict) or not (item.get("id") or item.get("rsid")) for item in items):
                raise AdobeError("Adobe returned a record without a usable identifier.")
            fingerprint = tuple(str(i.get("id") or i.get("rsid")) for i in items)
            if items and fingerprint in page_fingerprints:
                raise AdobeError("Adobe repeated a page. Retrieval stopped to avoid reporting incomplete results.")
            page_fingerprints.add(fingerprint)
            for item in items:
                identity = str(item.get("id") or item.get("rsid"))
                if identity not in seen:
                    seen.add(identity)
                    records.append(item)
            total_pages = meta.get("totalPages")
            terminal = meta.get("lastPage") is True or (isinstance(total_pages, int) and page + 1 >= total_pages)
            if not items and not terminal and (meta.get("lastPage") is False or isinstance(total_pages, int) and page + 1 < total_pages):
                raise AdobeError("Adobe returned an empty non-final page. Retrieval is incomplete.")
            if terminal or (not items) or (len(items) < self.page_size and meta.get("lastPage") is not False and total_pages is None):
                total = meta.get("totalElements")
                if isinstance(total, int) and len(records) < total:
                    raise AdobeError("Adobe returned fewer records than its total. Analysis was not run on a partial inventory.")
                return records
        raise AdobeError("Adobe pagination exceeded the safety limit; retrieval is incomplete.")

    def get_report_suites(self):
        suites = self.paged("reportsuites/collections/suites", ("reportSuites", "suites"),
                            {"expansion": "name,currency,timezoneZoneinfo,calendarType,parentRsid"})
        return sorted(({**s, "id": str(s.get("rsid") or s["id"])} for s in suites),
                      key=lambda s: str(s.get("name") or s["id"]).casefold())

    def get_scopes(self):
        return self.get_report_suites()

    def get_segments(self, rsid=None):
        params = {"includeType": "all", "filterByPublishedSegments": "all", "expansion": SEGMENT_EXPANSION}
        if rsid:
            params["rsid"] = rsid  # Adobe Analytics uses singular rsid, not CJA dataviewIds.
        segments = self.paged("segments", ("segments",), params)
        result = []
        for segment in segments:
            if not segment.get("definition") or not segment.get("rsid"):
                try:
                    detail = self.get("segments/" + quote(str(segment["id"]), safe=""), {"expansion": SEGMENT_EXPANSION})
                    if isinstance(detail, dict) and detail.get("id") == segment["id"]:
                        segment = {**segment, **detail}
                except AdobeError:
                    segment = {**segment, "_retrieval_issue": "Definition or parent report suite could not be retrieved."}
            if rsid and segment.get("rsid") and str(segment["rsid"]) != str(rsid):
                continue  # Defensive check if Adobe ignores the query filter.
            if rsid and not segment.get("rsid"):
                segment = {**segment, "_retrieval_issue": "Parent report suite is unknown; excluded from comparison."}
            result.append(segment)
        return result

    def get_projects(self):
        return self.paged("projects", ("projects",), {"includeType": "all", "expansion": PROJECT_EXPANSION})

    def get_project(self, project_id):
        return self.get("projects/" + quote(str(project_id), safe=""), {"expansion": PROJECT_EXPANSION})
