"""Narrow, opt-in segment-only DELETE; no automatic mutation retries."""
from urllib.parse import quote
import requests
from governance import valid_segment_id


class SegmentMutationMixin:
    def _segment_url(self, segment_id):
        if not valid_segment_id(segment_id):
            raise ValueError('Invalid segment ID.')
        identifier = quote(segment_id, safe='')
        if getattr(self.config, 'provider', 'aa') == 'cja':
            return 'https://cja.adobe.io/segments/' + identifier
        return 'https://analytics.adobe.io/api/' + quote(self.resolve_company(), safe='') + '/segments/' + identifier

    def get_segment(self, segment_id):
        return self._get(self._segment_url(segment_id), {'expansion':
            'definition,tags,compatibility,reportSuiteName,ownerFullName,modified,publishingStatus,definitionLastModified,categories,approved'})

    def delete_segment(self, segment_id):
        if not getattr(self.config, 'deletion_enabled', False):
            raise ValueError('Live deletion is disabled on this server.')
        url = self._segment_url(segment_id)
        try:
            response = self.session.request('DELETE', url, headers=self._headers(),
                                            timeout=(10, 45), allow_redirects=False)
        except requests.RequestException:
            return {'status': 'unknown', 'error': 'Delete response was lost. Do not retry automatically; check Adobe.'}
        if response.status_code == 204:
            return {'status': 'deleted', 'error': None}
        if response.status_code == 202:
            return {'status': 'pending', 'error': 'Adobe accepted the request; completion is not confirmed.'}
        if response.status_code == 200:
            try:
                payload = response.json()
            except ValueError:
                payload = None
            if isinstance(payload, dict) and payload.get('status') == 'ok' and not payload.get('error'):
                return {'status': 'deleted', 'error': None}
            return {'status': 'unknown', 'error': 'Adobe did not provide a recognised deletion confirmation.'}
        if response.status_code >= 500:
            return {'status': 'unknown', 'error': 'Adobe returned a server error. Completion is unknown; verify in Adobe.'}
        return {'status': 'failed', 'error': f'Adobe returned HTTP {response.status_code}. No success was confirmed. Check permissions or the segment in Adobe.'}
