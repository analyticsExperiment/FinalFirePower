"""One explicit provider selection per analysis; no cross-product comparisons."""
from dataclasses import dataclass
from adobe_client import Config, AdobeAnalyticsClient
from cja_client import CjaClient, data_view_id


@dataclass(frozen=True)
class Provider:
    id: str
    title: str
    scope_singular: str
    scope_plural: str
    prefix: str


PROVIDERS = {
    "cja": Provider("cja", "CJA", "Data View", "Data Views", "CJA"),
    "aa": Provider("aa", "Adobe Analytics", "Report Suite", "Report Suites", "AA"),
}


def get_provider(tool):
    if tool not in PROVIDERS:
        raise ValueError("Please choose CJA or Adobe Analytics.")
    return PROVIDERS[tool]


def make_client(tool):
    get_provider(tool)
    config = Config.load(tool)
    return CjaClient(config) if tool == "cja" else AdobeAnalyticsClient(config)


def normalize_segment(item, tool, scope_names):
    """Add internal scope metadata without rewriting the original definition."""
    get_provider(tool)
    segment = dict(item)
    scope_id = data_view_id(item) if tool == "cja" else str(item.get("rsid") or "")
    name = item.get("reportSuiteName")
    if tool == "cja":
        name = item.get("dataName") or item.get("dataViewName") or name
        for key in ("dataView", "dataview"):
            nested = item.get(key)
            if not name and isinstance(nested, dict):
                name = nested.get("name")
    segment.update({"_provider": tool, "_scope_id": scope_id,
                    "_scope_name": str(name or scope_names.get(scope_id) or scope_id or "Unknown scope")})
    return segment
