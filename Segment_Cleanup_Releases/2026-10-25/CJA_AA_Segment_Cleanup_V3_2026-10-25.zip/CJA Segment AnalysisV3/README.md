# Segment Cleanup V3 — CJA and Adobe Analytics

This is one separate Python application for both tools. It keeps the desktop card layout, grouped reports and review workflow from the existing CJA V2 app and its Adobe Analytics version. The original CJA V2 application is unchanged. The Report Suite scrolling fix below is also applied to the standalone Analytics application.

## Open the app

```bash
cd '/home/rajavel/development/Nodeapps/CJA MCP Analysis/CJA Segment AnalysisV3'
.venv/bin/python app.py
```

Open **http://127.0.0.1:5003**.

1. Choose **CJA** or **Adobe Analytics** in Analysis Tool.
2. The next dropdown loads automatically: **Data Views** for CJA, or **Report Suites** for Analytics.
3. Choose all or one scope, set the threshold and click **Generate Dashboard**.
4. Review exact groups, near groups, unique count, Workspace references and pairwise differences.
5. **Change Data View / Change Report Suite** returns to the same landing page with that tool selected. **Change Tool** returns to the first screen.

There is no separate Show Data Views button or credentials notice. Switching tools clears the previous list. A slow response from the old tool cannot overwrite the new selection.

### Report Suite scrolling fix — 24 October 2026

The native Report Suite popup was reproduced closing on mouse-wheel scrolling in desktop Chrome, in both V3 and standalone Analytics. Its 268 options (All + 267 suites) did not change during the failure, so this was not an options-reload issue.

Analytics now uses a bounded, scrollable picker with search by suite name or ID. Wheel scrolling and using the scrollbar keep it open. Choose an option to commit, or use Escape/outside click to dismiss. Arrow keys and Enter also work. The original select retains its form name and submitted value. The CJA Data View select stays native and unchanged.

`suite_picker.py` contains the local CSS/JavaScript and **must be included when copying the Python files**. No new packages or external scripts are required. Matching, API calls and credentials are unchanged. Restart a running older server and refresh the browser after updating.

Verified on desktop Chrome/Linux: live 267-suite list scrolling/search/selection; synthetic CJA and Analytics report generation, individual/empty scopes, return navigation, exports, provider-failure recovery and stale-response isolation; 69 offline tests. The deliberately injected CJA 502 in the browser test is expected. This is not a fresh live segment-analysis audit or Windows/mobile certification.

The picker interaction check is `tests/verify_suite_picker.js`, a Playwright CLI snippet for a loaded Analytics landing page with the full suite list. `tests/browser_flow.js` checks the synthetic end-to-end report flow on port 5004.

## Guarded deletion integration — 25 October 2026

The new colleague files have been reviewed and their applicable missing features integrated. Approval status/counts, group-level usage, owner metadata fallbacks and a single/bulk **Segment Deletion** panel are now included. See [FEATURE_PARITY.md](FEATURE_PARITY.md) for the comparison and verification limits.

Live deletion is **disabled by default**. The server must deliberately enable `CJA_ENABLE_DELETION=1` or `AA_ENABLE_DELETION=1` for the relevant product, then be restarted. No real environment file was changed and no live Adobe deletion was tested or performed.

The panel first performs a fresh read-only preview. Execution requires a valid report/preview token, a fresh segment and Workspace recheck, typed `DELETE`, and confirmation of owner approval and outside-dependency review. Approved, published, used, changed, unreadable or unknown-metadata segments are blocked. At least one known exact copy is retained per batch. Maximum: 200 IDs per deliberate operation. Every attempted write has a private audit record. Pending/uncertain responses are not treated as success or automatically retried.

The ordinary API transport remains GET-only except for IMS token POST. A separate, narrow opt-in method permits only the selected product's segment DELETE endpoint. There is no segment creation/update, project deletion or scope deletion. `get_deletion_recommendation()` still returns review guidance only; it does not itself delete anything. Saved/offline HTML reports cannot execute deletion. Zero visible Workspace references does not establish global non-use.

## Shared features

- Same desktop landing card, colours, typography and grouped-report layout.
- Total, exact-member, near-member and unique scorecards.
- Exact and near connected groups, with cautious cleanup guidance.
- Full inventory, pairwise matches, definition differences and accessible Workspace usage.
- Approved / Not Approved / Unknown summaries and per-segment approval in tables and exports.
- Guarded single/bulk deletion with read-only preview, explicit confirmation and refreshed reports.
- Search, clear, pagination, row-count selection and keyboard expand/collapse.
- Full inventory CSV; full and filtered Excel-compatible downloads.
- Tool-specific titles, scope names, scope IDs and download prefixes (`CJA_` / `AA_`).

The tools are not compared against each other. Each run analyses only the selected tool, and comparisons remain within its Data View or parent Report Suite. Credentials, clients, token caches, scope caches, output folders and generation locks are separate for CJA and Analytics.

## Credentials stay on the server

No credential values are placed in the HTML, browser requests, source code or report downloads. Real `.env` files were not copied or modified.

For each tool the configuration order is:

1. Explicit `CJA_ENV_FILE` or `AA_ENV_FILE`; `SEGMENT_ENV_FILE` can specify one combined file.
2. A `.env` in this V3 directory, if present.
3. On this laptop, the existing sibling `CJA Segment AnalysisV2/.env` for CJA, or `cja-segment-cleanup-poc/.env` for Analytics.
4. Process environment settings override file values.

Supported CJA settings: `CJA_CLIENT_ID` or the existing `CJA_API_KEY`, `CJA_CLIENT_SECRET`, `CJA_SCOPES`, `CJA_ORG_ID`, and optional manual `CJA_ACCESS_TOKEN`.

Supported Analytics settings: `AA_CLIENT_ID` or `AA_API_KEY`, `AA_CLIENT_SECRET`, `AA_SCOPES`, optional `AA_ORG_ID`, `AA_GLOBAL_COMPANY_ID`, and optional manual `AA_ACCESS_TOKEN`.

Generic `ADOBE_CLIENT_ID`, `ADOBE_CLIENT_SECRET`, `ADOBE_SCOPES` and `ADOBE_ORG_ID` are supported when intentionally using a common integration. Product-specific values take precedence. Analytics-prefixed credentials are not borrowed for CJA, or vice versa. A CJA-only integration may not have Analytics permissions.

Use `.env.example` to prepare a combined configuration on another computer. Alternatively:

```bash
CJA_ENV_FILE='/approved/cja.env' AA_ENV_FILE='/approved/analytics.env' .venv/bin/python app.py
```

Tokens are stored separately in `.cja_token_cache.json` and `.aa_token_cache.json`, with `0600` owner-only permissions and provider/configuration fingerprints. If Analytics has more than one matching company, set `AA_GLOBAL_COMPANY_ID` explicitly. CJA does not use Analytics company discovery.

## Installation and requirements

Python 3.10 or later is recommended; tested here with Python 3.13.5.

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python app.py
```

This laptop lacks `ensurepip`, so its isolated environment was created with `python3 -m venv --without-pip .venv`, then populated using the already installed `uv pip install --python .venv/bin/python -r requirements.txt`. No system packages or existing application dependencies were changed.

Dependencies are Flask 3.1.2, python-dotenv 1.1.1 and requests 2.32.5. Tests use built-in `unittest`. Windows can use `.venv\Scripts\python`; Windows execution was not tested here.

To change the local port or stop automatic browser opening:

```bash
SEGMENT_PORT=5005 SEGMENT_OPEN_BROWSER=0 .venv/bin/python app.py
```

The server binds to `127.0.0.1` only. It is a local demo/development application, not a production deployment.

## Files and reuse

- `app.py`: Flask entry point, tool-first landing page, `/api/scopes?tool=...`, form validation and local-only safeguards.
- `ui_styles.py`: the existing desktop landing styles.
- `suite_picker.py`: the Analytics-only searchable, scrollable Report Suite picker; native form values are preserved.
- `providers.py`: tool labels, client factory and non-destructive scope metadata mapping.
- `adobe_client.py`: shared OAuth/read transport, pagination, opt-in configuration and Analytics endpoints.
- `cja_client.py`: CJA Data Views, segments and Workspace endpoints, with CJA org headers.
- `segment_analysis.py`: common canonicalisation, Jaccard matching, grouping, usage guidance, CSV export and pipeline.
- `report_ui.py`: one common report renderer and browser export implementation. User segment names/descriptions are not relabelled when tool labels change.
- `governance.py`: tri-state approval and fail-closed deletion eligibility.
- `segment_mutation.py`: fresh single-segment GET and fixed-endpoint opt-in DELETE without automatic mutation retries.
- `deletion_workflow.py`: report/preview binding, fresh checks, batch execution, audit and short-lived outcome tracking.
- `deletion_ui.py`: approval cards, desktop cleanup controls and live-only confirmation flow.
- `segment_finder.py`: non-interactive runner for either tool.
- `tests/`: offline tests, a clearly labelled synthetic desktop server and opt-in live/browser verification helpers.

Command-line use:

```bash
.venv/bin/python segment_finder.py --tool cja --scope ALL --threshold 85
.venv/bin/python segment_finder.py --tool aa --scope YOUR_RSID --threshold 90 --json
```

For Python reuse, call `run_pipeline(make_client('cja'), tool='cja', scope_selection='ALL')` from `segment_analysis` and `providers`. `--json` includes segment definitions, matches and Workspace names but no tokens; keep that output private.

## Comparison and usage limits

Exact means equal canonical definitions in the same tool and scope. Object key order and ordinary AND/OR predicate order are normalised. Sequence order, container context, operators, component IDs, metric/dimension functions, typed values and array multiplicity are retained. Near matches use structural token Jaccard similarity, not audience overlap. A token score alone is never promoted to an exact match.

This shared engine retains the safeguards added in the Analytics port. It does not preserve the older V2 matcher's unsafe exact classifications for missing definitions, reordered sequences or cross-scope comparisons. It is not a full semantic-equivalence solver or Adobe definition validator.

Missing/unreadable definitions or unknown scopes remain in the inventory as **Not assessed**, not unique. Unique means no qualifying match at the selected threshold. Exact and near member counts can overlap. Connected near groups do not imply every pair in the group is similar; use the pairwise table.

Workspace counts cover only accessible projects. Missing details make usage unknown/incomplete, not unused. Approval, publishing, invisible projects, scheduling and other dependencies still require owner review. Zero visible references is not permission to delete. Known shared counts are positive evidence only; missing share information is shown as Not verified.

CJA uses Data View IDs (including the `rsid` response field). Analytics segment `rsid` records the parent Report Suite, not every suite in which a segment can be used. A virtual-suite selection with `parentRsid` analyses parent definitions and says so; it does not evaluate VRS population filters. The Analytics list comes from the Collections Suites API, not a complete separate VRS inventory.

## Outputs and sharing

Latest-run files are separate:

- `output/reports/cja/CJA_Segment_List.csv` and `CJA_Segment_Cleanup_Dashboard.html`
- `output/reports/aa/AA_Segment_List.csv` and `AA_Segment_Cleanup_Dashboard.html`

A later run replaces the latest files for that same tool only. Download/save a copy for a permanent record. Reports contain private segment/project information and must not be shared casually.

Top-level download buttons export all inventory or all pairs, regardless of search. Each table's Excel button exports all filtered rows, not only the current page. Excel exports use SpreadsheetML XML with `.xls`, as in the existing apps; they are not native `.xlsx` and Excel may show a format notice. CSV formula-like values are safely prefixed with an apostrophe.

`.gitignore` excludes real environment files, token caches, `.venv`, generated reports and browser evidence. Do not add these private files to a source package or Git repository.

## Test commands

```bash
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python tests/serve_fixture.py
```

The synthetic QA server uses port 5004 and never contacts Adobe. For approved real read-only checks, `tests/verify_live.py` scans both products and checks exact grouping and near-candidate coverage against an exhaustive same-scope comparison. Browser export readback is in `tests/verify_browser_exports.py`. See [VERIFICATION.md](VERIFICATION.md) for the checked evidence and remaining limits.

For the separately labelled deletion simulator, run `.venv/bin/python tests/serve_deletion_fixture.py` on port 5006. It blocks external requests and simulates deletion outcomes only; it is not the live app. `tests/browser_deletion_flow.js` exercises its desktop workflow.

Official API references: [CJA Data Views](https://developer.adobe.com/cja-apis/docs/endpoints/dataviews/), [CJA Segments](https://developer.adobe.com/cja-apis/docs/endpoints/segments/), [CJA Projects](https://developer.adobe.com/cja-apis/docs/endpoints/projects/), [Analytics Report Suites](https://developer.adobe.com/analytics-apis/docs/2.0/guides/endpoints/report-suites), [Analytics Segments](https://developer.adobe.com/analytics-apis/docs/2.0/guides/endpoints/segments/).
