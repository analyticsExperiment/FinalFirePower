"""Unified CJA + Adobe Analytics Segment Cleanup V3, desktop entry point."""
from collections import Counter
from html import escape
from pathlib import Path
import logging
import os
import threading
import time
import webbrowser
from urllib.parse import urlencode

from flask import Flask, jsonify, render_template_string, request
from adobe_client import AdobeError
from providers import get_provider, make_client
from ui_styles import PAGE_STYLE
from suite_picker import PICKER_STYLE, PICKER_SCRIPT
from deletion_workflow import DeletionWorkflow, register_routes
from deletion_ui import bind_live
import segment_analysis as core

APP_DIR = Path(__file__).resolve().parent
HOST = "127.0.0.1"
PORT = int(os.environ.get("SEGMENT_PORT", "5003"))
CACHE_TTL_SECONDS = 120
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 65536
logging.getLogger("werkzeug").setLevel(logging.WARNING)
_clients = {}
_scope_cache = {}
_cache_lock = threading.RLock()
_pipeline_locks = {"cja": threading.Lock(), "aa": threading.Lock()}
cleanup = DeletionWorkflow(core, lambda: APP_DIR)
register_routes(app, cleanup, True, _pipeline_locks)

LANDING_HTML = """<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Segment Cleanup — CJA and Adobe Analytics</title>
{{ style|safe }}
{{ picker_style|safe }}
<style>[hidden] { display:none !important; }</style>
</head><body>
<main class="landing-shell"><section class="landing-card" aria-labelledby="cleanupHeading">
  <h1 id="cleanupHeading">Segment Cleanup</h1>
  <p id="subtitle" class="landing-subtitle">Choose a tool, select the scope and generate the dashboard.</p>
  <div id="status" class="status" role="status" aria-live="polite"></div>
  <form id="reportForm" action="/generate" method="post">
    <div class="field">
      <label for="toolSelect">Analysis Tool</label>
      <select id="toolSelect" name="tool" required>
        <option value="">Choose a tool</option>
        <option value="cja" {% if initial_tool == 'cja' %}selected{% endif %}>CJA</option>
        <option value="aa" {% if initial_tool == 'aa' %}selected{% endif %}>Adobe Analytics</option>
      </select>
    </div>
    <div id="scopePanel" hidden>
      <div class="field" style="margin-top:18px">
        <label id="scopeLabel" for="scopeSelect">Scope</label>
        <select id="scopeSelect" name="scope_selection" disabled required>
          <option value="">Choose a tool first</option>
        </select>
      </div>
      <div class="field">
        <label for="threshold">Similarity Threshold (%)</label>
        <input id="threshold" name="threshold" type="number" min="1" max="100" step="1" value="85" required>
        <div class="hint">Segments at or above this similarity are flagged as near-duplicates. 85 is a starting point for manual review.</div>
      </div>
      <div class="generate-row"><button id="generateButton" class="primary" type="submit" disabled>Generate Dashboard</button></div>
    </div>
  </form>
</section></main>
{{ picker_script|safe }}
<script>
const tools = {cja:{title:'CJA',singular:'Data View',plural:'Data Views'},
               aa:{title:'Adobe Analytics',singular:'Report Suite',plural:'Report Suites'}};
const toolSelect = document.getElementById('toolSelect');
const scopeSelect = document.getElementById('scopeSelect');
const scopePanel = document.getElementById('scopePanel');
const generateButton = document.getElementById('generateButton');
const statusBox = document.getElementById('status');
const suitePicker = new ReportSuitePicker(scopeSelect);
let loadVersion = 0, controller = null, loadedTool = '';

function setStatus(message, kind='') {
  statusBox.className = 'status' + (kind ? ' ' + kind : '');
  statusBox.textContent = message;
}

async function loadScopes() {
  const version = ++loadVersion;
  if (controller) controller.abort();
  controller = new AbortController();
  const tool = toolSelect.value, labels = tools[tool];
  loadedTool = '';
  generateButton.disabled = true;
  generateButton.textContent = 'Generate Dashboard';
  scopeSelect.disabled = true;
  scopeSelect.replaceChildren(new Option('Choose a tool first', ''));
  suitePicker.setEnabled(tool === 'aa');
  scopePanel.hidden = !labels;
  setStatus('');
  document.getElementById('subtitle').textContent = labels
    ? 'Select a ' + labels.singular.toLowerCase() + ' and generate the dashboard.'
    : 'Choose a tool, select the scope and generate the dashboard.';
  if (!labels) return;
  document.getElementById('scopeLabel').textContent = labels.singular;
  scopeSelect.replaceChildren(new Option('Loading ' + labels.plural + '...', ''));
  suitePicker.refresh();
  try {
    const response = await fetch('/api/scopes?tool=' + encodeURIComponent(tool), {
      headers:{Accept:'application/json'}, signal:controller.signal
    });
    const payload = await response.json();
    if (version !== loadVersion || toolSelect.value !== tool) return;
    if (!response.ok) throw new Error(payload.error || 'Unable to load ' + labels.plural + '.');
    if (payload.tool !== tool) throw new Error('The tool changed. Please select it again.');
    if (!(payload.scopes || []).length) throw new Error('No accessible ' + labels.plural + ' were returned.');
    scopeSelect.replaceChildren(new Option('All ' + labels.plural, 'ALL'));
    for (const item of payload.scopes) scopeSelect.appendChild(new Option(item.name || item.id, String(item.id)));
    scopeSelect.value = 'ALL';
    scopeSelect.disabled = false;
    loadedTool = tool;
    generateButton.disabled = false;
  } catch (error) {
    if (version !== loadVersion || error.name === 'AbortError') return;
    scopeSelect.replaceChildren(new Option('Unable to load ' + labels.plural, ''));
    setStatus(error.message, 'error');
  } finally {
    if (version === loadVersion) suitePicker.refresh();
  }
}

toolSelect.addEventListener('change', loadScopes);
scopeSelect.addEventListener('change', () => {
  generateButton.disabled = !scopeSelect.value || loadedTool !== toolSelect.value;
});
document.getElementById('reportForm').addEventListener('submit', event => {
  if (!tools[toolSelect.value] || loadedTool !== toolSelect.value || !scopeSelect.value) {
    event.preventDefault();
    setStatus('Choose a tool and wait for its Data Views or Report Suites to load.', 'error');
    return;
  }
  generateButton.disabled = true;
  generateButton.textContent = 'Generating...';
  // Keep the tool field enabled so its selected value is submitted.
  setStatus('');
});
window.addEventListener('pageshow', event => {
  if (event.persisted) {
    generateButton.textContent = 'Generate Dashboard';
    generateButton.disabled = loadedTool !== toolSelect.value || !scopeSelect.value;
  }
});
loadScopes();
</script></body></html>"""


def get_client(tool):
    get_provider(tool)
    with _cache_lock:
        if tool not in _clients:
            _clients[tool] = make_client(tool)
        return _clients[tool]


def get_scopes_cached(tool, client):
    key = (tool, client.cache_identity)
    with _cache_lock:
        cached = _scope_cache.get(key)
        if cached and time.monotonic() - cached[0] < CACHE_TTL_SECONDS:
            return cached[1]
    scopes = client.get_scopes()
    with _cache_lock:
        _scope_cache[key] = (time.monotonic(), scopes)
    return scopes


@app.before_request
def restrict_local_requests():
    if request.host.split(":")[0] not in ("127.0.0.1", "localhost"):
        return "Local access only", 403
    origin = request.headers.get("Origin")
    if origin and origin != request.host_url.rstrip("/"):
        return "Cross-origin requests are not allowed", 403


@app.after_request
def privacy_headers(response):
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "same-origin"
    response.headers["X-Frame-Options"] = "DENY"
    return response


@app.get("/")
def index():
    tool = request.args.get("tool", "")
    tool = tool if tool in _pipeline_locks else ""
    return render_template_string(LANDING_HTML, style=PAGE_STYLE, initial_tool=tool,
                                  picker_style=PICKER_STYLE, picker_script=PICKER_SCRIPT)


@app.get("/api/scopes")
def api_scopes():
    try:
        tool = request.args.get("tool", "")
        provider = get_provider(tool)
        scopes = get_scopes_cached(tool, get_client(tool))
        names = Counter(str(s.get("name") or s["id"]) for s in scopes)
        clean = [{"id": str(s["id"]), "name": str(s.get("name") or s["id"]) +
                  (f' ({s["id"]})' if names[str(s.get("name") or s["id"])] > 1 else "")} for s in scopes]
        return jsonify({"tool": tool, "scopeLabel": provider.scope_singular, "scopes": clean, "count": len(clean)})
    except ValueError as error:
        return jsonify({"error": str(error)}), 400
    except AdobeError as error:
        return jsonify({"error": str(error)}), 502
    except Exception:
        return jsonify({"error": "Unable to load the selected tool's list. Check its server configuration."}), 502


@app.get("/favicon.ico")
def favicon():
    return "", 204


def render_report(values):
    tool = values.get("tool", "")
    try:
        provider = get_provider(tool)
        selection = (values.get("scope_selection") or "").strip()
        if not selection:
            raise ValueError(f"Please select a {provider.scope_singular} before generating the report.")
        threshold = core.validate_threshold(values.get("threshold", "85"))
        client = get_client(tool)
        scopes = get_scopes_cached(tool, client)
        with _pipeline_locks[tool]:
            result = core.run_pipeline(cleanup.view_client(tool, client), tool=tool, threshold=threshold,
                                       output_dir=APP_DIR / "output" / "reports" / tool,
                                       scope_selection=selection, scopes=scopes)
            token = cleanup.register(tool, client, result, selection)
        refresh = '/dashboard?' + urlencode({'tool':tool, 'scope_selection':selection, 'threshold':threshold})
        return bind_live(result["dashboard_html"], token, tool,
                         bool(getattr(getattr(client, 'config', None), 'deletion_enabled', False)), refresh)
    except ValueError as error:
        return error_page(str(error), tool=tool)
    except AdobeError as error:
        return error_page(str(error), tool=tool, status=502)
    except Exception:
        return error_page("The report could not be generated. No Adobe data was changed.", tool=tool, status=500)


@app.post("/generate")
def generate():
    return render_report(request.form)


@app.get("/dashboard")
def dashboard():
    # Refresh performs reads only; no deletion is possible through navigation.
    return render_report(request.args)


def error_page(message, tool="", status=400):
    target = "/?tool=" + tool if tool in _pipeline_locks else "/"
    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<title>Segment Cleanup — Error</title>{PAGE_STYLE}</head><body>
<main class="container error-card"><section class="panel"><h1>Could not generate the report</h1>
<div class="status error">{escape(str(message))}</div>
<a class="back" href="{target}">&larr; Back to Segment Cleanup</a></section></main></body></html>""", status


if __name__ == "__main__":
    print(f"Segment Cleanup V3 — CJA + Adobe Analytics: http://{HOST}:{PORT}")
    if os.environ.get("SEGMENT_OPEN_BROWSER", "1") == "1":
        threading.Timer(1, lambda: webbrowser.open(f"http://{HOST}:{PORT}")).start()
    app.run(host=HOST, port=PORT, debug=False, threaded=True)
