"""Non-interactive read-only entry point for either supported tool."""
import argparse
import json
import sys
from adobe_client import AdobeError
from providers import make_client
from segment_analysis import run_pipeline


def main():
    parser = argparse.ArgumentParser(description="Unified CJA + Adobe Analytics segment analysis")
    parser.add_argument("--tool", choices=("cja", "aa"), required=True)
    parser.add_argument("--scope", default="ALL", help="Data View ID (CJA), Report Suite ID (AA), or ALL")
    parser.add_argument("--threshold", type=float, default=85)
    parser.add_argument("--output-dir")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    try:
        result = run_pipeline(make_client(args.tool), tool=args.tool, scope_selection=args.scope,
                              threshold=args.threshold, output_dir=args.output_dir)
        result.pop("dashboard_html", None)
        if not args.json:
            for key in ("segments", "matches", "usage_map"):
                result.pop(key, None)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (AdobeError, ValueError) as error:
        print(json.dumps({"error": str(error)}), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
