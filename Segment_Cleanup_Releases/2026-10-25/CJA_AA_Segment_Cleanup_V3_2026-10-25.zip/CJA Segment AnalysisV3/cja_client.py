"""CJA adapter using the original app's API flow, with strict read-only guards."""
from urllib.parse import quote
from adobe_client import AdobeAnalyticsClient, AdobeError, SEGMENT_EXPANSION

CJA_BASE = "https://cja.adobe.io"
PROJECT_EXPANSION = "externalReferences,definition,ownerFullName,shares"


def data_view_id(segment):
    values = [segment.get(k) for k in ("rsid", "dataId", "dataID", "data_id")]
    for key in ("dataView", "dataview", "dataSource"):
        value = segment.get(key)
        if isinstance(value, dict):
            values.append(value.get("id"))
    return next((str(value) for value in values if value), "")


class CjaClient(AdobeAnalyticsClient):
    BASE_URL = CJA_BASE

    def __init__(self, config, session=None, page_size=100):
        if not config.org_id:
            raise AdobeError("Configure CJA_ORG_ID on the server.")
        super().__init__(config, session, page_size)

    def _headers(self):
        return {**super()._headers(), "x-gw-ims-org-id": self.config.org_id}

    def resolve_company(self):
        raise AdobeError("Company discovery is not used for CJA.")

    def get(self, resource, params=None):
        root = resource.split("/", 1)[0]
        if root not in ("segments", "projects") and resource != "data/dataviews":
            raise AdobeError("Unsupported read-only CJA resource.")
        if ".." in resource or "?" in resource or "#" in resource:
            raise AdobeError("Unsupported read-only CJA resource.")
        return self._get(CJA_BASE + "/" + resource, params)

    def get_data_views(self):
        items = self.paged("data/dataviews", ("dataViews", "dataviews"),
                           {"expansion": "name,owner,organization,description"})
        return sorted(items, key=lambda item: str(item.get("name") or item["id"]).casefold())

    def get_scopes(self):
        return self.get_data_views()

    def get_report_suites(self):
        raise AdobeError("Report Suites are not used for CJA. Load Data Views instead.")

    def get_segments(self, scope_id=None):
        params = {"includeType": "all", "expansion": SEGMENT_EXPANSION}
        if scope_id:
            # CJA documents rsids (plural); AA uses rsid (singular).
            params["rsids"] = scope_id
        items = self.paged("segments", ("segments",), params)
        segments = []
        for segment in items:
            if not segment.get("definition") or not data_view_id(segment):
                try:
                    detail = self.get("segments/" + quote(str(segment["id"]), safe=""), {"expansion": SEGMENT_EXPANSION})
                    if isinstance(detail, dict) and str(detail.get("id")) == str(segment["id"]):
                        segment = {**segment, **detail}
                except AdobeError:
                    segment = {**segment, "_retrieval_issue": "Definition or Data View could not be retrieved."}
            actual = data_view_id(segment)
            if scope_id and actual and actual != str(scope_id):
                continue
            if not actual:
                segment = {**segment, "_retrieval_issue": "Data View is unknown; excluded from comparison."}
            segments.append(segment)
        return segments

    def get_projects(self):
        return self.paged("projects", ("projects",), {"includeType": "all", "locale": "en_US", "expansion": PROJECT_EXPANSION})

    def get_project(self, project_id):
        return self.get("projects/" + quote(str(project_id), safe=""), {"expansion": PROJECT_EXPANSION})
