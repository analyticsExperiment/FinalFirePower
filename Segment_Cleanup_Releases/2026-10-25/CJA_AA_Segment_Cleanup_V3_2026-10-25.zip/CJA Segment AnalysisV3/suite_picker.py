"""Local, dependency-free Report Suite picker; the native select still submits."""

PICKER_STYLE = """<style>
.suite-picker { position:relative; width:100%; }
.suite-picker[hidden], .suite-picker [hidden] { display:none !important; }
.suite-picker .suite-trigger {
  display:flex; align-items:center; justify-content:space-between; gap:12px;
  width:100%; height:42px; padding:9px 12px; border:1px solid var(--border,#d8e0ea);
  border-radius:7px; background:#fff; color:var(--text,#1d2939);
  font:14px Arial,Helvetica,sans-serif; text-align:left; cursor:pointer;
}
.suite-picker .suite-trigger:disabled { opacity:1; background:#f4f4f4; color:#999; cursor:not-allowed; }
.suite-picker .suite-value { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.suite-picker .suite-arrow { flex:none; font-size:12px; color:#667085; }
.suite-picker .suite-popup {
  position:absolute; top:calc(100% + 5px); left:0; right:0; z-index:1000;
  border:1px solid #cbd5e1; border-radius:8px; background:#fff;
  box-shadow:0 8px 24px rgba(29,41,57,.16); overflow:hidden;
}
.suite-picker .suite-search-wrap { padding:10px; border-bottom:1px solid #e6ebf2; }
.suite-picker .suite-search { height:36px; font-size:13px; }
.suite-picker .suite-options {
  max-height:250px; overflow-y:auto; overflow-x:hidden; overscroll-behavior:contain;
  scrollbar-gutter:stable; padding:4px 0; scroll-behavior:auto;
}
.suite-picker .suite-option {
  padding:9px 12px; font:14px/1.35 Arial,Helvetica,sans-serif;
  color:#1d2939; overflow-wrap:anywhere; cursor:pointer;
}
.suite-picker .suite-option:hover, .suite-picker .suite-option.is-active { background:#edf2ff; }
.suite-picker .suite-option[aria-selected="true"] { color:#244dcb; font-weight:600; }
.suite-picker .suite-empty { padding:12px; color:#667085; font-size:13px; }
.suite-picker .suite-count { padding:7px 12px; border-top:1px solid #e6ebf2; color:#667085; font-size:11px; }
</style>"""

PICKER_SCRIPT = r"""<script>
// A bounded DOM list replaces the platform-native popup, not its form value.
class ReportSuitePicker {
  constructor(select) {
    this.select = select;
    this.originalRequired = select.required;
    this.enabled = false;
    this.activeIndex = -1;
    this.matches = [];
    this.label = select.labels && select.labels[0];
    if (this.label && !this.label.id) this.label.id = select.id + '-label';

    this.root = document.createElement('div');
    this.root.className = 'suite-picker';
    this.root.hidden = true;
    this.root.innerHTML = '<button type="button" class="suite-trigger" role="combobox" aria-haspopup="dialog" aria-expanded="false">' +
      '<span class="suite-value"></span><span class="suite-arrow" aria-hidden="true">▾</span></button>' +
      '<div class="suite-popup" role="dialog" aria-label="Choose a Report Suite" hidden>' +
      '<div class="suite-search-wrap"><input class="suite-search" type="search" autocomplete="off" spellcheck="false" aria-label="Search Report Suites" placeholder="Search by suite name or ID..."></div>' +
      '<div class="suite-options" role="listbox" aria-label="Report Suites"></div>' +
      '<div class="suite-count" role="status" aria-live="polite"></div></div>';
    select.insertAdjacentElement('afterend', this.root);
    this.button = this.root.querySelector('.suite-trigger');
    this.value = this.root.querySelector('.suite-value');
    this.popup = this.root.querySelector('.suite-popup');
    this.search = this.root.querySelector('.suite-search');
    this.list = this.root.querySelector('.suite-options');
    this.count = this.root.querySelector('.suite-count');
    this.popup.id = select.id + '-suite-popup';
    this.list.id = select.id + '-suite-options';
    this.button.setAttribute('aria-controls', this.popup.id);
    this.search.setAttribute('aria-controls', this.list.id);
    if (this.label) this.button.setAttribute('aria-labelledby', this.label.id);
    else this.button.setAttribute('aria-label', 'Report Suite');

    this.button.addEventListener('click', () => this.popup.hidden ? this.open() : this.close());
    this.button.addEventListener('keydown', event => this.keydown(event));
    this.search.addEventListener('keydown', event => this.keydown(event));
    this.search.addEventListener('input', () => this.renderOptions());
    this.list.addEventListener('click', event => {
      const option = event.target.closest('[data-suite-index]');
      if (option && this.list.contains(option)) this.choose(Number(option.dataset.suiteIndex));
    });
    // No blur/mouseleave/wheel dismissal: scrollbar clicks and wheel scrolling
    // inside this root must never close the menu or commit a different value.
    document.addEventListener('pointerdown', event => {
      if (!this.popup.hidden && !this.root.contains(event.target) && event.target !== this.label) this.close(false);
    });
    if (this.label) this.label.addEventListener('click', event => {
      if (this.enabled) { event.preventDefault(); this.button.focus(); }
    });
    select.addEventListener('change', () => this.updateValue());
    window.addEventListener('resize', () => { if (!this.popup.hidden) this.position(); });
  }

  setEnabled(enabled) {
    this.close(false);
    this.enabled = Boolean(enabled);
    this.root.hidden = !this.enabled;
    this.select.hidden = this.enabled;
    // Hidden required controls cannot receive native validation focus. Existing
    // form handlers validate the selected value; CJA restores native required.
    this.select.required = this.enabled ? false : this.originalRequired;
    this.button.setAttribute('aria-required', String(this.originalRequired));
    this.refresh();
  }

  updateValue() {
    const selected = this.select.options[this.select.selectedIndex];
    this.value.textContent = selected ? selected.textContent : 'Choose a Report Suite';
    this.button.title = this.value.textContent;
    this.button.disabled = this.select.disabled || !this.enabled;
  }

  refresh() {
    this.close(false);
    this.updateValue();
  }

  open() {
    if (!this.enabled || this.select.disabled) return;
    this.search.value = '';
    this.popup.hidden = false;
    this.button.setAttribute('aria-expanded', 'true');
    this.renderOptions();
    this.position();
    this.search.focus({preventScroll:true});
  }

  close(restoreFocus=true) {
    const wasOpen = !this.popup.hidden;
    this.popup.hidden = true;
    this.button.setAttribute('aria-expanded', 'false');
    this.search.removeAttribute('aria-activedescendant');
    if (wasOpen && restoreFocus && this.enabled && !this.select.disabled) this.button.focus({preventScroll:true});
  }

  position() {
    const rect = this.root.getBoundingClientRect();
    const below = window.innerHeight - rect.bottom - 12;
    const above = rect.top - 12;
    const up = below < 220 && above > below;
    this.popup.style.top = up ? 'auto' : 'calc(100% + 5px)';
    this.popup.style.bottom = up ? 'calc(100% + 5px)' : 'auto';
    this.list.style.maxHeight = Math.max(80, Math.min(250, (up ? above : below) - 90)) + 'px';
    this.ensureActiveVisible();
  }

  renderOptions() {
    const query = this.search.value.trim().toLocaleLowerCase();
    this.matches = Array.from(this.select.options).map((option, index) => ({option, index})).filter(item =>
      !item.option.disabled && item.option.value &&
      (!query || (item.option.textContent + ' ' + item.option.value).toLocaleLowerCase().includes(query)));
    const fragment = document.createDocumentFragment();
    for (const [index, item] of this.matches.entries()) {
      const row = document.createElement('div');
      row.className = 'suite-option';
      row.id = this.select.id + '-suite-option-' + item.index;
      row.dataset.suiteIndex = String(index);
      row.setAttribute('role', 'option');
      row.setAttribute('aria-selected', String(item.option.value === this.select.value));
      row.textContent = item.option.textContent;
      fragment.appendChild(row);
    }
    if (!this.matches.length) {
      const empty = document.createElement('div');
      empty.className = 'suite-empty';
      empty.textContent = 'No Report Suites match this search.';
      fragment.appendChild(empty);
    }
    this.list.replaceChildren(fragment);
    this.count.textContent = this.matches.length + (this.matches.length === 1 ? ' option' : ' options');
    const selectedIndex = this.matches.findIndex(item => item.option.value === this.select.value);
    this.setActive(selectedIndex >= 0 ? selectedIndex : this.matches.length ? 0 : -1);
  }

  setActive(index) {
    this.activeIndex = index;
    const rows = this.list.querySelectorAll('[role="option"]');
    rows.forEach((row, i) => row.classList.toggle('is-active', i === index));
    const active = rows[index];
    if (active) this.search.setAttribute('aria-activedescendant', active.id);
    else this.search.removeAttribute('aria-activedescendant');
    this.ensureActiveVisible();
  }

  ensureActiveVisible() {
    const active = this.list.querySelector('.is-active');
    if (!active || this.popup.hidden) return;
    const row = active.getBoundingClientRect(), list = this.list.getBoundingClientRect();
    if (row.top < list.top) this.list.scrollTop -= list.top - row.top;
    else if (row.bottom > list.bottom) this.list.scrollTop += row.bottom - list.bottom;
  }

  choose(index) {
    const item = this.matches[index];
    if (!item || this.select.disabled) return;
    this.select.value = item.option.value;
    this.select.dispatchEvent(new Event('change', {bubbles:true}));
    this.close();
  }

  keydown(event) {
    if (event.key === 'Escape' && !this.popup.hidden) { event.preventDefault(); this.close(); return; }
    if (event.key === 'Tab') { this.close(false); return; }
    if (event.target === this.search && this.search.value && ['Home','End'].includes(event.key)) return;
    if (['ArrowDown','ArrowUp','Home','End'].includes(event.key)) {
      event.preventDefault();
      if (this.popup.hidden) { this.open(); return; }
      const last = this.matches.length - 1;
      if (last < 0) return;
      this.setActive(event.key === 'Home' ? 0 : event.key === 'End' ? last :
        Math.max(0, Math.min(last, this.activeIndex + (event.key === 'ArrowDown' ? 1 : -1))));
    } else if (event.key === 'Enter' && !this.popup.hidden) {
      event.preventDefault(); this.choose(this.activeIndex);
    }
  }
}
window.ReportSuitePicker = ReportSuitePicker;
</script>"""
