"""Report-bound, two-step deletion with fresh checks and fail-closed defaults."""
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import secrets
import threading
import time
from governance import deletion_block_reason, valid_segment_id

MAX_BULK_DELETE = 200


class DeletionError(ValueError):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def fingerprint(segment):
    fields = {k: segment.get(k) for k in ('id', 'rsid', 'dataId', 'dataID', 'data_id', 'definition',
              'approved', 'tags', 'publishingStatus', 'modified', 'definitionLastModified', 'owner', 'usedIn', 'usageSummary', 'shares')}
    return hashlib.sha256(json.dumps(fields, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()


class DeletionWorkflow:
    def __init__(self, core, output_root):
        self.core, self.output_root = core, output_root
        self.reports, self.recent, self.pending = {}, {}, {}
        self.lock = threading.RLock()

    def scope(self, segment):
        return getattr(self.core, 'get_scope_id', getattr(self.core, 'get_report_suite_id', None))(segment)

    def identity(self, tool, client):
        return tool, client.cache_identity

    def register(self, tool, client, result, selection):
        with self.lock:
            now = time.monotonic()
            self.reports = {k:v for k,v in self.reports.items() if v['expires'] > now}
            # Bound server memory; old tabs then require a fresh report.
            while len(self.reports) >= 12:
                self.reports.pop(next(iter(self.reports)))
            token = secrets.token_urlsafe(32)
            self.reports[token] = {'tool':tool, 'client':client, 'identity':self.identity(tool, client),
                'segments':{str(s['id']):deepcopy(s) for s in result['segments']},
                'groups':[{str(s['id']) for s in g} for g in self.core.build_duplicate_groups(result['matches'], 'Exact duplicate')],
                'expires':now+1200, 'plans':{}, 'selection':selection, 'threshold':result['threshold']}
            return token

    def context(self, token, tool):
        report = self.reports.get(token)
        if not report or report['expires'] <= time.monotonic() or report['tool'] != tool:
            raise DeletionError('Report expired or does not match the tool. Generate a fresh report.', 409)
        if self.identity(tool, report['client']) != report['identity']:
            raise DeletionError('Server credentials changed. Generate a fresh report.', 409)
        return report

    def ids(self, payload, report):
        raw = payload.get('ids')
        if not isinstance(raw, list) or not raw or len(raw) > MAX_BULK_DELETE:
            raise DeletionError('Select between 1 and 200 segments per operation.')
        if any(not valid_segment_id(s) for s in raw):
            raise DeletionError('Invalid segment ID.')
        ids = list(dict.fromkeys(raw))
        if any(s not in report['segments'] for s in ids):
            raise DeletionError('A selected ID is not in this report.', 403)
        return ids

    def prepare_fresh(self, segment, tool):
        # Apply the same read-side aliases/JSON parsing used to build the report.
        # In V3 this also identifies legacy CJA definition/container structures.
        if hasattr(self.core, 'get_scope_id'):
            from providers import normalize_segment
            segment = normalize_segment(segment, tool, {})
        return self.core.prepare_segments([segment])[0]

    def recheck(self, report, ids):
        rows, fresh = {}, []
        client = report['client']
        for sid in ids:
            old = report['segments'][sid]
            row = rows[sid] = {'id':sid, 'name':str(old.get('name') or sid), 'eligible':False}
            try:
                item = client.get_segment(sid)
                if not isinstance(item, dict) or str(item.get('id') or '') != sid:
                    row['reason'] = 'Returned segment identity did not match.'
                    continue
                item = self.prepare_fresh(item, report['tool'])
                if self.scope(item) != self.scope(old):
                    row['reason'] = 'Segment scope changed or is unknown.'
                elif fingerprint(item) != fingerprint(old):
                    row['reason'] = 'Segment changed since this report. Generate a fresh report.'
                elif self.pending.get((*report['identity'], sid), 0) > time.monotonic():
                    row['reason'] = 'A prior deletion is pending or uncertain. Verify in Adobe before retrying.'
                else:
                    fresh.append(item)
            except Exception:
                row['reason'] = 'Could not re-read the segment. Nothing was deleted.'
        try:
            usage, loaded = self.core.load_workspace_usage(fresh, client) if fresh else ({}, False)
        except Exception:
            usage, loaded = {}, False
        for item in fresh:
            row = rows[str(item['id'])]
            reason = deletion_block_reason(item, usage, loaded, self.core.definition_issue(item))
            row.update(eligible=not reason, reason=reason or 'Fresh checks passed; owner and outside-dependency review still required.')
        eligible = {sid for sid,row in rows.items() if row['eligible']}
        # Do not remove every known copy of an exact definition in one operation.
        for group in report['groups']:
            if group and group <= eligible:
                keeper = sorted(group)[0]
                rows[keeper].update(eligible=False, reason='Retain at least one member of this exact group.')
                eligible.remove(keeper)
        return [rows[sid] for sid in ids]

    def preview(self, token, tool, payload):
        with self.lock:
            report = self.context(token, tool)
            ids = self.ids(payload, report)
            rows = self.recheck(report, ids)
            eligible = [r['id'] for r in rows if r['eligible']]
            nonce = secrets.token_urlsafe(24)
            now = time.monotonic()
            report['plans'] = {k:v for k,v in report['plans'].items() if v[0] > now}
            while len(report['plans']) >= 12:
                report['plans'].pop(next(iter(report['plans'])))
            report['plans'][nonce] = (now+300, eligible)
            return {'results':rows, 'ids':eligible, 'plan':nonce,
                    'enabled':bool(getattr(report['client'].config, 'deletion_enabled', False))}

    def record(self, tool, data):
        path = Path(self.output_root()) / 'output' / 'audit' / 'segment-deletions.jsonl'
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        fd = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
        with os.fdopen(fd, 'a') as stream:
            os.chmod(path, 0o600)
            stream.write(json.dumps({'time_utc':datetime.now(timezone.utc).isoformat(), 'tool':tool, **data})+'\n')
            stream.flush()
            os.fsync(stream.fileno())

    def execute(self, token, tool, payload):
        with self.lock:
            report = self.context(token, tool)
            if not getattr(report['client'].config, 'deletion_enabled', False):
                raise DeletionError('Live deletion is disabled on this server.', 403)
            if payload.get('confirmation') != 'DELETE' or payload.get('owner_review_confirmed') is not True:
                raise DeletionError('Type DELETE and confirm owner approval and outside-dependency review.')
            ids = self.ids(payload, report)
            if not isinstance(payload.get('plan'), str):
                raise DeletionError('A fresh preview plan is required.')
            plan = report['plans'].pop(payload.get('plan'), None)
            if not plan or plan[0] <= time.monotonic() or plan[1] != ids:
                raise DeletionError('Preview expired or selection changed. Run a fresh preview.', 409)
            rows = self.recheck(report, ids)
            batch = secrets.token_hex(12)
            # Refuse all writes if the initial durable audit cannot be saved.
            self.record(tool, {'batch':batch, 'phase':'preflight', 'results':rows})
            attempted = False
            try:
                for row in rows:
                    row.update(success=False, status='blocked', error=row['reason'])
                    if not row['eligible']:
                        continue
                    # Persist intent before each independent write. No automatic retry.
                    self.record(tool, {'batch':batch, 'phase':'intent', 'id':row['id']})
                    attempted = True
                    try:
                        outcome = report['client'].delete_segment(row['id'])
                        if not isinstance(outcome, dict) or outcome.get('status') not in ('deleted','pending','failed','unknown'):
                            outcome = {'status':'unknown','error':'Deletion outcome not recognised. Verify in Adobe.'}
                    except Exception:
                        outcome = {'status':'unknown','error':'Deletion could not be confirmed. Verify in Adobe before retrying.'}
                    row.update(status=outcome['status'], success=outcome['status']=='deleted', error=outcome.get('error'))
                    identity = (*report['identity'], row['id'])
                    if row['success']:
                        self.recent[identity] = time.monotonic()+600
                    elif row['status'] in ('pending','unknown'):
                        self.pending[identity] = time.monotonic()+600
                    self.record(tool, {'batch':batch, 'phase':'result', **row})
            finally:
                # Even a late disk/audit failure must invalidate old tabs and plans.
                if attempted:
                    self.reports = {k:v for k,v in self.reports.items() if v['identity'] != report['identity']}
            return {'success':all(r['success'] for r in rows), 'results':rows, 'refresh_required':attempted}

    def view_client(self, tool, client):
        manager = self
        class View:
            def __getattr__(self, name):
                return getattr(client, name)
            def get_segments(self, *args, **kwargs):
                records = client.get_segments(*args, **kwargs)
                now = time.monotonic()
                with manager.lock:
                    manager.recent = {k:v for k,v in manager.recent.items() if v > now}
                    hidden = {key[2] for key in manager.recent if key[:2] == manager.identity(tool,client)}
                return [s for s in records if str(s.get('id')) not in hidden]
        return View()


def register_routes(app, manager, unified, locks):
    from flask import jsonify, request
    def handle(preview):
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify(error='A JSON object is required.'), 400
        tool = payload.get('tool', 'aa' if not unified else '')
        if not isinstance(tool, str) or tool not in locks:
            return jsonify(error='Choose a valid tool.'), 400
        if request.headers.get('Sec-Fetch-Site') not in (None, 'same-origin', 'none'):
            return jsonify(error='Cross-site cleanup requests are not allowed.'), 403
        try:
            with locks[tool]:
                fn = manager.preview if preview else manager.execute
                return jsonify(fn(request.headers.get('X-Cleanup-Token', ''), tool, payload))
        except DeletionError as error:
            return jsonify(error=str(error)), error.status
        except Exception:
            return jsonify(error='Cleanup could not complete. Do not assume any deletion succeeded; verify in Adobe and refresh.'), 500
    app.add_url_rule('/api/segments/delete-preview', 'deletion_preview', lambda:handle(True), methods=['POST'])
    app.add_url_rule('/api/segments/delete', 'deletion_execute', lambda:handle(False), methods=['POST'])
