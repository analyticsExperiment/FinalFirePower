"""Desktop cleanup controls; exported reports contain no live write token."""
from collections import Counter
from html import escape
import json
from governance import approval_status, deletion_block_reason

STYLE = '''<style>
.approval-summary {display:flex;gap:16px;flex-wrap:wrap;margin:18px 0}
.approval-metric {padding:12px 18px;border:1px solid #d9e2ef;border-radius:8px;background:white;min-width:160px}
.approval-value {font-size:23px;font-weight:700;display:block;margin-top:5px}
#cleanupPanel input[type=checkbox],#cleanupDialog input[type=checkbox] {width:18px;height:18px;vertical-align:middle}
#cleanupPanel .cleanup-tools {display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:14px 0}
#cleanupPanel input[type=search] {padding:9px;min-width:260px;flex:1;border:1px solid #cbd5e1;border-radius:5px}
#cleanupPanel select {padding:8px;width:auto} #cleanupPanel button {padding:9px 12px;border:0;border-radius:5px;cursor:pointer}
#cleanupPanel .danger,#cleanupDialog .danger {background:#b42318;color:white}
#cleanupPanel button:disabled,#cleanupDialog button:disabled {opacity:.45;cursor:not-allowed}
#cleanupBody td {vertical-align:top;overflow-wrap:anywhere} #cleanupBody td:first-child {width:45px}
#cleanupDialog {width:min(760px,90vw);max-height:85vh;overflow:auto;border:1px solid #cbd5e1;border-radius:10px;padding:24px;color:#1d2939}
#cleanupDialog::backdrop {background:rgba(15,23,42,.45)} #cleanupDialog input[type=text] {padding:8px;width:150px;margin:8px}
#cleanupDialog .cleanup-preview {max-height:230px;overflow:auto;margin:12px 0} #cleanupDialog button {padding:10px 16px;margin:8px;border:0;border-radius:5px;cursor:pointer}
#cleanupMessage {white-space:pre-wrap;margin:12px 0;padding:10px;border:1px solid #d8e0ea;border-radius:6px}
[hidden] {display:none!important}
</style>'''

SCRIPT = r'''<script>
(() => {
 const data=CLEANUP_DATA, context=/*CLEANUP_CONTEXT*/null;
 const selected=new Set(); let filtered=data.slice(),page=1,size=10,plan=null,busy=false;
 const $=id=>document.getElementById(id), message=$('cleanupMessage'), dialog=$('cleanupDialog');
 const note='Owner approval and dependencies outside accessible Workspace projects must be checked. A similarity score is not permission to delete.';
 function text(tag,value) {const e=document.createElement(tag);e.textContent=String(value??'');return e;}
 function status(value) {message.textContent=value;message.hidden=false;}
 function render() {
   const query=$('cleanupSearch').value.trim().toLocaleLowerCase();
   filtered=data.filter(s=>(s.name+' '+s.id+' '+s.reason).toLocaleLowerCase().includes(query));
   page=Math.max(1,Math.min(page,Math.max(1,Math.ceil(filtered.length/size))));
   const rows=filtered.slice((page-1)*size,page*size), body=$('cleanupBody');body.replaceChildren();
   for(const s of rows) {
     const tr=document.createElement('tr'), check=text('td',''), box=document.createElement('input');
     box.type='checkbox';box.checked=selected.has(s.id);box.disabled=Boolean(s.reason)||busy||!context;
     box.setAttribute('aria-label','Select segment '+s.name);box.addEventListener('change',()=>{box.checked?selected.add(s.id):selected.delete(s.id);render();});check.append(box);tr.append(check);
     const name=text('td',s.name);name.append(text('div',s.id));tr.append(name);
     for(const value of [s.scope,s.owner,s.approval,s.usage,s.reason||'Ready for fresh preflight'])tr.append(text('td',value));
     const action=text('td',''),button=text('button','Delete');button.type='button';button.className='danger';button.disabled=Boolean(s.reason)||busy||!context;
     button.setAttribute('aria-label','Review deletion of '+s.name);button.addEventListener('click',()=>preview([s.id]));action.append(button);tr.append(action);body.append(tr);
   }
   if(!rows.length){const tr=document.createElement('tr'),td=text('td','No segments match this search.');td.colSpan=8;tr.append(td);body.append(tr);}
   $('cleanupPagination').textContent=`Page ${page} of ${Math.max(1,Math.ceil(filtered.length/size))} — ${filtered.length} rows`;
   $('cleanupSelection').textContent=selected.size+' selected';$('cleanupPreview').disabled=busy||!selected.size||!context;
   $('cleanupPrevious').disabled=page===1||busy;$('cleanupNext').disabled=page*size>=filtered.length||busy;
 }
 async function request(path,payload) {
   if(!context)throw new Error('This is an offline report. Generate a fresh report in the running application.');
   const response=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-Cleanup-Token':context.token},body:JSON.stringify({tool:context.tool,...payload})});
   const value=await response.json();if(!response.ok)throw new Error(value.error||'Server could not complete cleanup.');return value;
 }
 async function preview(ids) {
   if(busy)return;if(ids.length>200){status('Select at most 200 segments per operation. Nothing was deleted.');return;}
   busy=true;render();status('Checking current definitions, approval, publishing and accessible Workspace usage...');
   try {
     plan=await request('/api/segments/delete-preview',{ids});$('cleanupPreviewList').replaceChildren();
     for(const row of plan.results)$('cleanupPreviewList').append(text('p',row.name+' ['+row.id+']: '+row.reason));
     $('cleanupType').value='';$('cleanupOwner').checked=false;
     $('cleanupConfirm').disabled=true;
     $('cleanupMode').textContent=plan.enabled?'Live deletion is enabled for this provider.':'Live deletion is DISABLED. This preview performs reads only.';
     dialog.showModal();$('cleanupCancel').focus();status('Preview complete. No segments have been deleted.');
   }catch(error){status(error.message);}finally{busy=false;render();}
 }
 function confirmation(){ $('cleanupConfirm').disabled=busy||!plan?.enabled||!plan.ids.length||$('cleanupType').value!=='DELETE'||!$('cleanupOwner').checked; }
 $('cleanupSearch').addEventListener('input',()=>{page=1;render();});
 $('cleanupPageSize').addEventListener('change',()=>{size=Number($('cleanupPageSize').value);page=1;render();});
 $('cleanupPrevious').addEventListener('click',()=>{page--;render();});$('cleanupNext').addEventListener('click',()=>{page++;render();});
 function choose(rows){const ids=rows.filter(s=>!s.reason).map(s=>s.id);if(new Set([...selected,...ids]).size>200){status('Selection would exceed 200. Narrow the search or select a page.');return;}ids.forEach(id=>selected.add(id));render();}
 $('cleanupSelectPage').addEventListener('click',()=>choose(filtered.slice((page-1)*size,page*size)));
 $('cleanupSelectFiltered').addEventListener('click',()=>choose(filtered));$('cleanupClearSelection').addEventListener('click',()=>{selected.clear();render();});
 $('cleanupClearSearch').addEventListener('click',()=>{$('cleanupSearch').value='';page=1;render();});
 $('cleanupPreview').addEventListener('click',()=>preview([...selected]));
 $('cleanupType').addEventListener('input',confirmation);$('cleanupOwner').addEventListener('change',confirmation);
 $('cleanupCancel').addEventListener('click',()=>{if(!busy){dialog.close();plan=null;}});
 dialog.addEventListener('cancel',event=>{if(busy)event.preventDefault();});
 $('cleanupConfirm').addEventListener('click',async()=>{
   if($('cleanupConfirm').disabled)return;busy=true;confirmation();$('cleanupCancel').disabled=true;
   try {
     const result=await request('/api/segments/delete',{ids:plan.ids,plan:plan.plan,confirmation:$('cleanupType').value,owner_review_confirmed:$('cleanupOwner').checked});
     const note=result.results.map(r=>r.name+': '+r.status+(r.error?' — '+r.error:'')).join('\n');
     status(note);dialog.close();plan=null;
     if(result.refresh_required){try{sessionStorage.setItem('cleanup-result-'+context.tool,JSON.stringify({message:note,time:Date.now()}));}catch(e){}window.location.assign(context.refresh);}
   }catch(error){status(error.message+' Refresh the report and verify Adobe before retrying.');dialog.close();plan=null;}
   finally{busy=false;$('cleanupCancel').disabled=false;render();}
 });
 $('cleanupNote').textContent=note+(context?(context.enabled?' Live writes are enabled for this provider.':' Live writes are disabled; preview only.'):' Offline report: deletion controls are inactive.');
 if(context){try{const key='cleanup-result-'+context.tool,prior=JSON.parse(sessionStorage.getItem(key)||'null');sessionStorage.removeItem(key);if(prior&&Date.now()-prior.time<120000)status(prior.message);}catch(e){}}
 render();
})();
</script>'''


def json_safe(value):
    return json.dumps(value, ensure_ascii=False).replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')


def augment_report(html, segments, usage_map, usage_loaded, scope_fn, owner_fn, issue_fn):
    counts=Counter(approval_status(s) for s in segments)
    summary='<div class="approval-summary" aria-label="Approval summary">'+''.join(
        '<div class="approval-metric">'+escape(label)+'<span class="approval-value">'+str(counts[label])+'</span></div>'
        for label in ('Approved','Not Approved','Unknown'))+'</div><p class="note">Approval is reported only when explicit metadata is available. Unknown is not Not Approved.</p>'
    rows=[{'id':str(s['id']), 'name':str(s.get('name') or s['id']), 'scope':scope_fn(s), 'owner':owner_fn(s),
           'approval':approval_status(s), 'usage':usage_map.get(str(s['id']),{}).get('count',0) if usage_loaded else 'Unknown',
           'reason':deletion_block_reason(s,usage_map,usage_loaded,issue_fn(s))} for s in segments]
    panel='''<section class="section" id="cleanupPanel">
<details><summary><h2 style="display:inline">Segment Deletion</h2></summary>
<p class="note" id="cleanupNote"></p><p class="note">The list includes blocked rows so the reason is visible. Only explicitly Not Approved, confirmed unpublished, assessable segments with no accessible references can reach preflight. Retain one exact copy. Maximum 200 per operation.</p>
<div id="cleanupMessage" role="status" aria-live="polite" hidden></div>
<div class="cleanup-tools"><input type="search" id="cleanupSearch" aria-label="Search cleanup segments" placeholder="Search by name, ID or blocking reason"><button id="cleanupClearSearch">Clear Search</button><label for="cleanupPageSize">Rows per page</label><select id="cleanupPageSize"><option>10</option><option>20</option><option>50</option><option>100</option></select></div>
<div class="cleanup-tools"><button id="cleanupSelectPage">Select Page</button><button id="cleanupSelectFiltered">Select All Filtered</button><button id="cleanupClearSelection">Clear Selection</button><span id="cleanupSelection"></span><button id="cleanupPreview">Preview Selected</button></div>
<div class="table-wrap"><table><thead><tr><th>Select</th><th>Segment and ID</th><th>Scope ID</th><th>Owner</th><th>Approval</th><th>Workspace references</th><th>Preflight status</th><th>Action</th></tr></thead><tbody id="cleanupBody"></tbody></table></div>
<div class="cleanup-tools"><button id="cleanupPrevious">Previous</button><span id="cleanupPagination"></span><button id="cleanupNext">Next</button></div>
</details></section>
<dialog id="cleanupDialog" aria-labelledby="cleanupDialogTitle"><h2 id="cleanupDialogTitle">Review segment deletion</h2><p id="cleanupMode"></p><p>Blocked rows will not be sent for deletion. Review the exact IDs below. Deletion affects availability in Adobe; do not assume it can be undone.</p><div class="cleanup-preview" id="cleanupPreviewList"></div><p><label><input type="checkbox" id="cleanupOwner"> I confirm owner approval and have checked dependencies outside accessible Workspace projects.</label></p><p><label for="cleanupType">Type DELETE to confirm</label><input id="cleanupType" type="text" autocomplete="off" spellcheck="false"></p><button id="cleanupCancel">Cancel</button><button class="danger" id="cleanupConfirm" disabled>Delete Confirmed Segments</button></dialog>'''
    html=html.replace('</head>',STYLE+'</head>',1)
    html=html.replace('    <p class="note">Not assessed:',summary+'    <p class="note">Not assessed:',1)
    html=html.replace('  <div class="section">\n    <h2 class="card-header-row"',panel+'\n  <div class="section">\n    <h2 class="card-header-row"',1)
    script=SCRIPT.replace('CLEANUP_DATA',json_safe(rows),1)
    return html.replace('</body>',script+'</body>',1)


def bind_live(html, token, tool, enabled, refresh):
    return html.replace('/*CLEANUP_CONTEXT*/null',json_safe({'token':token,'tool':tool,'enabled':enabled,'refresh':refresh}),1)
