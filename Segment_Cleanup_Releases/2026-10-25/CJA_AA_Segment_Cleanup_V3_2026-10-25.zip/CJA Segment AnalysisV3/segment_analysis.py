"""Pure definition comparison, connected groups and cautious usage guidance.

Exact = the same canonical definition in the same provider and scope.
Near = structural token Jaccard similarity, NOT audience overlap/equivalence.
"""

from collections import defaultdict
from html import escape as esc
from itertools import combinations
from pathlib import Path
import csv
import json
import math
import os
from governance import approval_status

from adobe_client import AdobeError
from providers import get_provider, normalize_segment


def json_key(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def predicate_sort_key(value):
    """Keep rules on the same component aligned when only literals change."""
    references = []

    def walk(item):
        if isinstance(item, dict):
            if item.get("func") in ("attr", "event") and isinstance(item.get("name"), str):
                references.append((item["func"], item["name"]))
            for child in item.values():
                walk(child)
        elif isinstance(item, list):
            for child in item:
                walk(child)
    walk(value)
    return (tuple(sorted(references)), json_key(value))


def canonicalize(value):
    if isinstance(value, list):
        return [canonicalize(item) for item in value]
    if not isinstance(value, dict):
        return value
    result = {key: canonicalize(value[key]) for key in sorted(value)}
    # Only ordinary boolean AND/OR predicate order is normalised. All sequence
    # streams, checkpoints, versions, and other arrays retain order/multiplicity.
    if result.get("func") in ("and", "or") and isinstance(result.get("preds"), list):
        result["preds"] = sorted(result["preds"], key=predicate_sort_key)
    return result


def get_scope_id(segment):
    return str(segment.get("_scope_id") or segment.get("rsid") or segment.get("dataId") or "")


def get_scope_name(segment):
    return str(segment.get("_scope_name") or segment.get("reportSuiteName") or segment.get("dataName") or get_scope_id(segment) or "Unknown scope")


def provider_scope_key(segment):
    return (segment.get("_provider", "aa"), get_scope_id(segment))


def get_owner_name(segment):
    owner = segment.get("owner")
    owner_info = owner if isinstance(owner, dict) else {}
    created_by = segment.get("createdBy")
    created_name = (created_by.get("name") or created_by.get("displayName")) if isinstance(created_by, dict) else created_by
    user = segment.get("user")
    user = user if isinstance(user, dict) else {}
    owner_id = owner_info.get("id") or owner_info.get("ownerId")
    return str(owner_info.get("fullName") or owner_info.get("name") or owner_info.get("displayName")
               or owner_info.get("login") or segment.get("ownerFullName") or segment.get("ownerName")
               or (owner if isinstance(owner, str) else None) or created_name or user.get("name")
               or user.get("displayName") or (f"Owner ID: {owner_id}" if owner_id else "-"))


def definition_issue(segment):
    if segment.get("_retrieval_issue"):
        return segment["_retrieval_issue"]
    if not segment.get("id") or not get_scope_id(segment):
        return "Segment ID or scope is missing."
    definition = segment.get("definition")
    if not isinstance(definition, dict) or not definition:
        return "Definition is missing or is not a JSON object."
    container = definition.get("container")
    is_cja = segment.get("_provider") == "cja"
    allowed_root = ("segment", "segment-def") if is_cja else ("segment",)
    allowed_container = ("container", "segment") if is_cja else ("container",)
    if definition.get("func") not in allowed_root or not isinstance(container, dict) or not container:
        return "Definition does not contain an Adobe segment/container structure."
    if container.get("func") not in allowed_container or container.get("context") not in ("hits", "visits", "visitors"):
        return "Container context is missing or unsupported."
    pred = container.get("pred")
    if not isinstance(pred, dict) or not pred.get("func"):
        return "Container predicate is missing."
    if pred.get("func") in ("and", "or") and not pred.get("preds"):
        return "Boolean predicate has no rules."
    try:
        json_key(definition)
    except (ValueError, TypeError, RecursionError):
        return "Definition is not valid finite JSON."
    return ""


def prepare_segments(segments):
    prepared = []
    for original in segments:
        segment = dict(original)
        if isinstance(segment.get("definition"), str):
            try:
                segment["definition"] = json.loads(segment["definition"])
            except (ValueError, TypeError):
                pass
        segment["_analysis_issue"] = definition_issue(segment)
        prepared.append(segment)
    return prepared


def normalized_definition(segment):
    return None if definition_issue(segment) else json_key(canonicalize(segment["definition"]))


def flatten_to_path_tokens(value, path, tokens):
    if isinstance(value, dict):
        if not value:
            tokens.add(path + "={}")
        for key, item in value.items():
            flatten_to_path_tokens(item, path + "/" + key.replace("~", "~0").replace("/", "~1"), tokens)
    elif isinstance(value, list):
        if not value:
            tokens.add(path + "=[]")
        for index, item in enumerate(value):
            # Array positions bind each value to its own predicate and sequence step.
            flatten_to_path_tokens(item, f"{path}/{index}", tokens)
    else:
        tokens.add(path + "=" + json_key(value))  # true, 1, "1", null stay distinct.


def tokenize(segment):
    if definition_issue(segment):
        return set()
    tokens = set()
    flatten_to_path_tokens(canonicalize(segment["definition"]), "", tokens)
    return tokens


def similarity_from_tokens(a, b):
    return 100 * len(a & b) / len(a | b) if a or b else 0.0


def differences_from_tokens(a, b):
    return {"onlyA": sorted(a - b), "onlyB": sorted(b - a)}


def validate_threshold(threshold):
    try:
        threshold = float(threshold)
        if not math.isfinite(threshold) or not 1 <= threshold <= 100:
            raise ValueError
        return threshold
    except (ValueError, TypeError):
        raise ValueError("Similarity threshold must be a finite number between 1 and 100.") from None


def find_duplicate_segments(segments, threshold=85, verbose=False):
    threshold = validate_threshold(threshold)
    prepared = [(s, normalized_definition(s), tokenize(s)) for s in segments]
    exact_groups, inverted = defaultdict(list), defaultdict(set)
    for index, (segment, norm, tokens) in enumerate(prepared):
        if norm is None:
            continue
        scope = provider_scope_key(segment)
        exact_groups[(scope, norm)].append(index)
        for token in tokens:
            inverted[(scope, token)].add(index)
    matches, exact_pairs = [], set()

    def match(i, j, kind, score):
        a, _, a_tokens = prepared[i]
        b, _, b_tokens = prepared[j]
        return {"type": kind, "similarity": score, "a": a, "b": b,
                "diff": differences_from_tokens(a_tokens, b_tokens)}

    for group in exact_groups.values():
        for i, j in combinations(group, 2):
            exact_pairs.add((i, j))
            matches.append(match(i, j, "Exact duplicate", 100.0))
    for i, (segment, norm, tokens) in enumerate(prepared):
        if norm is None:
            continue
        candidates = set()
        for token in tokens:
            candidates.update(inverted[(provider_scope_key(segment), token)])
        for j in sorted(candidates):
            if j <= i or (i, j) in exact_pairs:
                continue
            other = prepared[j][2]
            if 100 * min(len(tokens), len(other)) / max(len(tokens), len(other)) < threshold:
                continue
            score = similarity_from_tokens(tokens, other)
            if score >= threshold:
                matches.append(match(i, j, "Near duplicate", score))
    return sorted(matches, key=lambda m: (-m["similarity"], str(m["a"]["id"]), str(m["b"]["id"])))


def get_match_segment_key(segment):
    return (*provider_scope_key(segment), str(segment.get("id") or ""))


def count_distinct_segments_in_matches(matches, match_type):
    return len({get_match_segment_key(m[side]) for m in matches if m["type"] == match_type for side in ("a", "b")})


def count_unique_segments(segments, matches):
    matched = {get_match_segment_key(m[side]) for m in matches for side in ("a", "b")}
    return sum(not definition_issue(s) and get_match_segment_key(s) not in matched for s in segments)


def build_duplicate_groups(matches, match_type):
    parent, by_key = {}, {}

    def find(key):
        while parent[key] != key:
            parent[key] = parent[parent[key]]
            key = parent[key]
        return key

    for match in matches:
        if match["type"] != match_type:
            continue
        keys = []
        for side in ("a", "b"):
            segment = match[side]
            key = get_match_segment_key(segment)
            parent.setdefault(key, key)
            by_key[key] = segment
            keys.append(key)
        parent[find(keys[0])] = find(keys[1])
    groups = defaultdict(list)
    for key, segment in by_key.items():
        groups[find(key)].append(segment)
    return sorted(groups.values(), key=lambda group: (-len(group), str(group[0].get("id"))))


def collect_segment_ids_from_project(project, known_ids):
    found = set()

    def walk(value):
        if isinstance(value, str) and value in known_ids:
            found.add(value)
        elif isinstance(value, dict):
            for child in value.values():
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)
    for key in ("externalReferences", "definition"):
        value = project.get(key)
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except ValueError:
                pass
        walk(value)
    return found


def load_workspace_usage(segments, client, verbose=False):
    """Visible Workspace projects only; absence is never proof of global non-use."""
    known = {str(s["id"]) for s in segments}
    usage, complete = {}, True
    try:
        projects = client.get_projects()
        for project in projects:
            if not any(isinstance(project.get(k), (dict, list)) for k in ("externalReferences", "definition")):
                try:
                    detail = client.get_project(project["id"])
                    if isinstance(detail, dict) and detail.get("id") == project["id"]:
                        project = {**project, **detail}
                except AdobeError:
                    complete = False
            if not any(isinstance(project.get(k), (dict, list)) for k in ("externalReferences", "definition")):
                complete = False
                continue
            shared = bool(project.get("shares"))  # Never infer publishing from approval/curation.
            for segment_id in collect_segment_ids_from_project(project, known):
                item = usage.setdefault(segment_id, {"count": 0, "sharedPublishedCount": 0, "projectNames": [], "sharedPublishedProjectNames": []})
                item["count"] += 1
                item["sharedPublishedCount"] += int(shared)
                item["projectNames"].append(str(project.get("name") or project["id"]))
                if shared:
                    item["sharedPublishedProjectNames"].append(str(project.get("name") or project["id"]))
    except AdobeError:
        complete = False
    return usage, complete


def get_segment_usage(usage_map, segment):
    return usage_map.get(str(segment.get("id")), {"count": 0, "sharedPublishedCount": 0,
                                                "projectNames": [], "sharedPublishedProjectNames": []})


def is_protected(segment):
    tags = segment.get("tags") or []
    approved = segment.get("approved") is True or any(
        (isinstance(t, dict) and str(t.get("name", "")).lower() == "approved") or
        (isinstance(t, str) and t.lower() == "approved") for t in tags)
    publishing = segment.get("publishingStatus")
    published = (publishing is True or
                 isinstance(publishing, str) and publishing.lower() not in ("", "false", "notpublished", "not_published", "unpublished", "none") or
                 isinstance(publishing, dict) and bool(publishing) and publishing.get("published") is not False)
    return bool(approved or published)


def get_deletion_recommendation(match, usage_map, usage_loaded):
    used = [side.upper() for side in ("a", "b") if get_segment_usage(usage_map, match[side])["count"]]
    protected = [side.upper() for side in ("a", "b") if is_protected(match[side])]
    if used or protected:
        text = "Do not delete — " + ("in use: " + ", ".join(used) if used else "approved/published or protected")
    elif not usage_loaded:
        text = "Unable to verify — Workspace usage incomplete"
    elif match["type"] == "Exact duplicate":
        text = "Review consolidation — no references in accessible projects"
    else:
        text = "Review business rules — similarity is not equivalence"
    return {"text": text, "detail": (
        "Check owner approval and dependencies outside accessible Workspace projects before consolidation. "
        "Near matches need business-rule review. Deletion is disabled by default and requires a separate guarded workflow."
    )}


def get_recommendation_bucket(text):
    return "keep" if text.startswith("Do not delete") else "unknown" if text.startswith("Unable") else "review"


def get_group_deletion_recommendation(group_segments, is_exact, usage_map, usage_loaded):
    if any(is_protected(s) or get_segment_usage(usage_map, s)["count"] for s in group_segments):
        return {"text": "Do not delete used/approved/published segments. Review each pair and owner impact.", "class_name": "recommend-keep"}
    if not usage_loaded:
        return {"text": "Unable to verify — Workspace usage incomplete. Owner/dependency review required.", "class_name": "recommend-review"}
    return {"text": ("Review consolidation; retain a suitable canonical segment after owner approval. " if is_exact else
                     "Review each linked pair; not every member is similar to every other member. ") +
                    "No references found in accessible projects is not proof of global non-use.", "class_name": "recommend-review"}


def render_duplicate_group_rows(groups, is_exact, usage_map, usage_loaded):
    if not groups:
        return '<tr><td colspan="6"><span class="badge strong">No ' + ("exact-duplicate" if is_exact else "near-duplicate") + ' groups found.</span></td></tr>'
    rows = []
    for index, group in enumerate(groups, 1):
        names = "".join(f'<span class="group-segment-name">{esc(str(s.get("name") or "(No name)"))}</span>' for s in group)
        suites = "".join(f'<span class="group-segment-name">{esc(name)}</span>' for name in sorted({get_scope_name(s) for s in group}))
        rec = get_group_deletion_recommendation(group, is_exact, usage_map, usage_loaded)
        approval = "".join(f'<span class="group-segment-name">{esc(approval_status(s))}</span>' for s in group)
        usage = "".join(f'<span class="group-segment-name">{get_segment_usage(usage_map, s)["count"] if usage_loaded or get_segment_usage(usage_map, s)["count"] else "Unknown"}</span>' for s in group)
        rows.append(f'<tr><td>{index}</td><td>{names}</td><td>{suites}</td><td>{approval}</td><td>{usage}</td><td><span class="{rec["class_name"]}">{esc(rec["text"])}</span></td></tr>')
    return "".join(rows)


def spreadsheet_safe(value):
    text = str(value or "")
    return "'" + text if text.lstrip().startswith(("=", "+", "-", "@", "\t", "\r")) else text


def export_segment_csv(segments, path, tool="aa"):
    provider = get_provider(tool)
    with open(path, "w", encoding="utf-8-sig", newline="") as handle:
        os.chmod(path, 0o600)
        writer = csv.writer(handle)
        writer.writerow(["#", "Segment Name", "Segment ID", provider.scope_singular + " Name", provider.scope_singular + " ID", "Owner", "Description", "Definition (JSON)", "Analysis status", "Approved Status"])
        for index, segment in enumerate(segments, 1):
            values = [index, segment.get("name", ""), segment.get("id", ""), get_scope_name(segment), get_scope_id(segment),
                      get_owner_name(segment), segment.get("description", ""), json.dumps(segment.get("definition"), ensure_ascii=False),
                      definition_issue(segment) or "Assessed", approval_status(segment)]
            writer.writerow([spreadsheet_safe(v) for v in values])


def run_pipeline(client, threshold=85, output_dir=None, scope_selection="ALL", segments=None, scopes=None, tool="aa"):
    from report_ui import build_dashboard_html

    threshold = validate_threshold(threshold)
    provider = get_provider(tool)
    scopes = scopes if scopes is not None else client.get_scopes()
    selected = next((s for s in scopes if str(s["id"]) == str(scope_selection)), None)
    if str(scope_selection).upper() != "ALL" and selected is None:
        raise ValueError(f"Please select an accessible {provider.scope_singular}.")
    selected_id = str((selected.get("parentRsid") if tool == "aa" else None) or selected["id"]) if selected else None
    scope = str(selected.get("name") or selected["id"]) if selected else f"All {provider.scope_plural} (compared within each scope)"
    if tool == "aa" and selected and selected.get("parentRsid") and selected["parentRsid"] != selected["id"]:
        scope += " — parent-suite definitions; VRS population filters are not evaluated"
    raw = segments if segments is not None else client.get_segments(selected_id)
    names = {str(s["id"]): str(s.get("name") or s["id"]) for s in scopes}
    normal = [normalize_segment(s, tool, names) for s in raw]
    normal = [s for s in normal if not selected_id or not get_scope_id(s) or get_scope_id(s) == selected_id]
    segments = prepare_segments(normal)
    usage, usage_loaded = load_workspace_usage(segments, client) if segments else ({}, False)
    matches = find_duplicate_segments(segments, threshold)
    directory = Path(output_dir) if output_dir else Path(__file__).resolve().parent / "output" / "reports" / tool
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    csv_path, html_path = directory / f"{provider.prefix}_Segment_List.csv", directory / f"{provider.prefix}_Segment_Cleanup_Dashboard.html"
    export_segment_csv(segments, csv_path, tool)
    html = build_dashboard_html(segments, matches, usage, usage_loaded, threshold, csv_path.name, scope, tool=tool)
    html_path.write_text(html, encoding="utf-8")
    os.chmod(html_path, 0o600)
    summary = {"segment_count": len(segments), "assessed_count": sum(not definition_issue(s) for s in segments),
               "unassessed_count": sum(bool(definition_issue(s)) for s in segments), "match_count": len(matches),
               "exact_count": sum(m["type"] == "Exact duplicate" for m in matches),
               "near_count": sum(m["type"] == "Near duplicate" for m in matches),
               "unique_count": count_unique_segments(segments, matches), "usage_loaded": usage_loaded,
               "tool": tool, "scope": scope, "threshold": threshold}
    return {**summary, "segments": segments, "matches": matches, "usage_map": usage,
            "segment_csv_path": str(csv_path), "dashboard_html_path": str(html_path), "dashboard_html": html}
