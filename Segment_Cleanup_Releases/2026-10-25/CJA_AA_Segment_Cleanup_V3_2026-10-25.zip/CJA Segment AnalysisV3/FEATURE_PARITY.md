# Colleague update: feature comparison and integration

Checked on 25 October 2026. Sources: the supplied `appNew.py` and `cjaFinderNew.py` in the parent directory. Targets: **CJA Segment AnalysisV3** (CJA + Adobe Analytics) and **Adobe Analytics Segment Analysis** (standalone Analytics). The older CJA V2 app was not updated.

## Result

The applicable browser/report features in the supplied files are now covered in both targets. Deletion was the main missing workflow, but approval reporting, group-member usage and owner metadata fallbacks also needed additions. The supplied files were used as a feature reference, not copied as executable modules.

| Feature in supplied files | Before this update | Current targets |
|---|---|---|
| Server credentials, OAuth and private token cache | Present | Retained; no credentials in browser/report |
| Automatic scope list; All/individual selection; threshold | Present | Retained; Data Views for CJA, Report Suites for Analytics |
| Segment paging and Workspace-reference scan | Present | Retained, with incomplete-read safeguards |
| Exact/near detection, groups, unique count and recommendations | Present | Retained; matching engine unchanged |
| Search, paging, page sizes, CSV and Excel-compatible downloads | Present | Retained |
| Approved / Not Approved counts and status in reports/exports | Missing | Added, with an extra Unknown category |
| Workspace count beside each grouped segment | Missing | Added; incomplete usage is labelled Unknown |
| Additional owner-name / creator / user / ID fallbacks | Partial | Added |
| Single and bulk Segment Deletion controls | Missing | Added, with search, page/all-filtered selection and per-ID outcomes |
| Fresh segment and Workspace checks before deletion | Missing | Added in preview and again in execution |
| Confirmation, protected-row blocking and server batch limit | Missing | Added; stricter safeguards described below |
| Refresh after deletion and short-lived stale-list filtering | Missing | Added; successful, failed, pending and uncertain outcomes distinguished |
| GET `/dashboard` and POST `/api/segments/delete` | Missing | Added; also POST `/api/segments/delete-preview` |

Both apps keep their existing desktop UI and Report Suite scrolling fix. V3 isolates CJA and Analytics credentials, context tokens, API endpoints and generated reports. The standalone app intentionally supports Analytics only.

## Deliberate differences and source issues

- The supplied files do not compile as received: `appNew.py` first fails at line 26 with missing indentation; `cjaFinderNew.py` first fails at line 95 with invalid syntax. There are further formatting/identifier issues. Both originals remain byte-for-byte unchanged.
- The supplied matcher drops array positions and can promote a 100% token score to exact. We did **not** import that behaviour. The existing tested matcher retains sequence position, types, multiplicity, metric/dimension distinctions and provider/scope isolation. It is still a structural comparison aid, not a full Adobe validator or audience-equivalence proof.
- Missing approval is **Unknown**, never Not Approved. Unknown publishing/usage status also blocks execution. Positive sharing/usage protects a segment. A tag explicitly named Approved is protective.
- Zero accessible Workspace references is not global non-use. No recommendation automatically authorises deletion; owner approval and outside-dependency review must be confirmed explicitly.
- A known exact group cannot lose every member in one operation. This does not provide a global lock against changes by other users or other applications.
- The original standalone Tkinter scope picker is not copied into the web apps: their existing browser picker and explicit CLI scope arguments cover that selection workflow.
- Large unattended auto-chunking is not copied. One deliberate request accepts at most 200 IDs. Near/unique segments are not automatically selected for deletion; a user may submit a segment for review, but it must pass the same fresh safeguards.
- The source's sharing inference from project approval/curation is not copied. Only positive share metadata is counted as known sharing.

## Deletion design and operation

Live deletion is **disabled by default**. Neither real `.env` file was changed. To enable after permissions and dependency review, deliberately set the relevant server flag to exactly `1` and restart:

- V3 CJA: `CJA_ENABLE_DELETION=1`.
- V3 Analytics or standalone Analytics: `AA_ENABLE_DELETION=1`.

These flags do not grant Adobe permissions. No segment creation/update, project deletion or scope deletion is implemented.

Flow: live report → select rows → read-only preview → inspect eligible/blocked rows → type `DELETE` and confirm owner/outside-dependency review → fresh server checks → fixed-endpoint DELETE → per-ID status → refreshed full report.

| Module | Responsibility |
|---|---|
| `app.py` | Existing landing/generation plus live report binding and refresh route |
| `governance.py` | Tri-state approval, publication/usage/definition eligibility |
| `segment_mutation.py` | Fresh segment GET and narrow opt-in segment DELETE |
| `deletion_workflow.py` | Report-bound preview/execute routes, tokens, fresh checks, limits, audit and outcome tracking |
| `deletion_ui.py` | Approval summaries, cleanup table, confirmation dialog and refresh |
| `segment_analysis.py`, `report_ui.py` | Existing engine/report plus owner/approval/group-usage presentation and export fields |

Report contexts expire after 20 minutes; one-use preview plans after 5 minutes. At most 12 reports and 12 preview plans per report are retained. Provider/integration, report membership, returned segment identity, scope and definition/governance fingerprint are checked. Saved/offline HTML has no active cleanup token and cannot execute deletion.

Writes use these fixed endpoints only:

- CJA: `DELETE https://cja.adobe.io/segments/{segmentId}`.
- Analytics: `DELETE https://analytics.adobe.io/api/{globalCompanyId}/segments/{segmentId}`.

The ordinary API transport remains read-only apart from OAuth token POST; the mutation method is separate and has no automatic DELETE retries or redirects. HTTP 202 is pending; timeouts/server errors/unrecognised confirmations are uncertain, not success. Batches are not atomic: one ID can succeed while another fails. Any attempted write invalidates the integration's old report tabs/plans, including after a late audit-disk failure.

The private audit is `output/audit/segment-deletions.jsonl` with owner-only file permissions. Preflight and per-ID intent are durably saved before writes. If audit storage fails before a write, that write is not sent; after a late failure, the UI reports an incomplete outcome and requires verification in Adobe. No automatic retry is made. Confirmed deletions are filtered from stale list reads for 10 minutes; pending/uncertain IDs are blocked from retry for 10 minutes in this process. This tracking is not persistent across server restarts and is not a distributed transaction/lock. Check Adobe before retrying any uncertain operation.

Adobe documents that deletion hides a segment from lists, while existing references can continue working and an individual GET may still return it. This implementation does not claim a physical purge or require GET 404 as proof.

## Verification and evidence boundaries

Verified during this update:

- V3: **120 offline tests passed**.
- Standalone: **101 offline tests passed; 1 CJA-only test skipped** because CJA is not part of standalone.
- Both desktop browser workflows passed against separately labelled synthetic servers with external network blocked: approval/usage protection, search, paging, selection, cancellation, typed/owner confirmation, successful refresh, partial failure/pending outcomes and retain-one-copy protection. V3 also passed the simulated CJA flow. No JavaScript errors or horizontal overflow in the tested desktop view.
- Replayed the frozen 24 October Demo Data 7616 inventory in both updated apps: 1,722 segments; 3,958 exact pairs; 1,376 near pairs; 555 unique segments. All 5,334 pair IDs, types, unrounded scores, differences and exact/near groups match the independent oracle. CSV definitions and approval fields read back correctly. This is frozen-data regression, not a new full live scan.
- AST comparison confirms the nine matching/grouping functions are unchanged from the pre-integration backup. Both colleague originals are unchanged.
- Actual browser CSV and full/filtered SpreadsheetML downloads were read back for both apps: IDs, counts, approval fields, definitions and scope IDs passed. Fresh preflight also covers JSON-encoded definitions and legacy CJA scope/definition aliases.
- A small real **read-only** API probe verified list reads with the approval expansion and a single-segment read for each provider. The sampled list/detail fingerprints matched. Analytics returned explicit approval and publishing status. CJA returned approval but **did not return publishing status for that sample**, so the application correctly blocks its deletion as unverified. This observation is not a claim about every CJA segment/API response.

Not verified: a real Adobe DELETE, granted write permissions, production hosting, all segment metadata shapes, organisation-wide dependencies, Windows/Excel-native execution or mobile view. **No live Adobe deletion was performed.** Native `.xlsx` export is not added: existing `.xls` downloads remain SpreadsheetML XML.

The source-only backup, count-only regression evidence and API-read probe are under `../Feature Integration/2026-10-25/`. The backup intentionally excludes credentials, caches and private reports. Synthetic browser helpers are in each app's `tests/`; screenshots are in V3 `output/playwright/`. Historical validation evidence was not overwritten.

Official endpoint references: [CJA Segments](https://developer.adobe.com/cja-apis/docs/endpoints/segments/), [Analytics Segments](https://developer.adobe.com/analytics-apis/docs/2.0/guides/endpoints/segments/).
