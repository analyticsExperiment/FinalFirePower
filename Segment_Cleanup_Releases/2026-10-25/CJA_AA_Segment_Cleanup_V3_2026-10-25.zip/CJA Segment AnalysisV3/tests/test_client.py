import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from adobe_client import AdobeAnalyticsClient, AdobeError, Config, AA_BASE, IMS_URL


class Response:
    def __init__(self, data, status=200, headers=None):
        self.data, self.status_code, self.headers = data, status, headers or {}

    def json(self):
        return self.data


class Session:
    def __init__(self, responses):
        self.responses, self.calls = iter(responses), []

    def request(self, method, url, **kwargs):
        self.calls.append((method, url, kwargs))
        return next(self.responses)


def client(responses, page_size=2, **config):
    session = Session([r if isinstance(r, Response) else Response(r) for r in responses])
    return AdobeAnalyticsClient(Config(client_id="fixture-client", access_token="fixture-token", company_id="fixture-company", **config), session, page_size)


class ClientTests(unittest.TestCase):
    def test_report_suites_bare_array_paginates_and_sorts(self):
        c = client([[{"rsid": "b", "name": "Beta"}, {"rsid": "a", "name": "Alpha"}], [{"rsid": "c"}]])
        self.assertEqual([s["id"] for s in c.get_report_suites()], ["a", "b", "c"])
        self.assertEqual([call[2]["params"]["page"] for call in c.session.calls], [0, 1])
        self.assertTrue(all("/reportsuites/collections/suites" in call[1] for call in c.session.calls))

    def test_envelope_metadata_overrides_short_page(self):
        c = client([{"content": [{"id": "s1", "rsid": "r", "definition": {"func": "segment"}}], "lastPage": False, "totalPages": 2},
                    {"content": [{"id": "s2", "rsid": "r", "definition": {"func": "segment"}}], "lastPage": True, "totalPages": 2}])
        self.assertEqual(len(c.get_segments("r")), 2)
        self.assertEqual(c.session.calls[0][2]["params"]["rsid"], "r")
        self.assertNotIn("dataviewIds", c.session.calls[0][2]["params"])

    def test_duplicates_deduplicated_across_pages(self):
        c = client([{"content": [{"id": "1"}, {"id": "2"}], "lastPage": False},
                    {"content": [{"id": "2"}, {"id": "3"}], "lastPage": True}])
        self.assertEqual([x["id"] for x in c.get_projects()], ["1", "2", "3"])

    def test_repeated_page_fails_closed(self):
        c = client([[{"id": "1"}, {"id": "2"}], [{"id": "1"}, {"id": "2"}]])
        with self.assertRaisesRegex(AdobeError, "repeated a page"):
            c.get_projects()

    def test_partial_inventory_rejected(self):
        c = client([{"content": [{"id": "1"}], "lastPage": True, "totalElements": 2}])
        with self.assertRaisesRegex(AdobeError, "partial inventory"):
            c.get_projects()

    def test_empty_non_final_page_rejected(self):
        c = client([{"content": [], "lastPage": False, "totalPages": 2}])
        with self.assertRaisesRegex(AdobeError, "incomplete"):
            c.get_projects()

    def test_selected_rsid_filter_and_hydration(self):
        c = client([{"content": [{"id": "s1"}, {"id": "s2", "rsid": "other", "definition": {"func": "segment"}}], "lastPage": True},
                    {"id": "s1", "rsid": "selected", "definition": {"func": "segment"}}])
        self.assertEqual([s["id"] for s in c.get_segments("selected")], ["s1"])
        self.assertIn("/segments/s1", c.session.calls[1][1])

    def test_missing_scope_not_silently_assigned(self):
        c = client([{"content": [{"id": "s1"}], "lastPage": True}, Response({}, 403)])
        item = c.get_segments("selected")[0]
        self.assertFalse(item.get("rsid"))
        self.assertIn("unknown", item["_retrieval_issue"])

    def test_discovery_unique_company_for_configured_org(self):
        c = client([])
        c.company_id = ""
        c.config.org_id = "org-b"
        c.session = Session([Response({"imsOrgs": [{"imsOrgId": "org-a", "companies": [{"globalCompanyId": "a"}]},
                                                 {"imsOrgId": "org-b", "companies": [{"globalCompanyId": "b"}]}]})])
        self.assertEqual(c.resolve_company(), "b")
        self.assertEqual(c.session.calls[0][1], AA_BASE + "/discovery/me")

    def test_discovery_ambiguous_never_picks_first(self):
        c = client([])
        c.company_id = ""
        c.session = Session([Response({"imsOrgs": [{"companies": [{"globalCompanyId": "a"}, {"globalCompanyId": "b"}]}]})])
        with self.assertRaisesRegex(AdobeError, "ambiguous"):
            c.resolve_company()

    def test_error_bodies_not_leaked(self):
        c = client([Response({"error": "private-token-secret"}, 403)])
        with self.assertRaises(AdobeError) as captured:
            c.get_projects()
        self.assertNotIn("private-token-secret", str(captured.exception))
        self.assertIn("HTTP 403", str(captured.exception))

    def test_only_get_and_ims_post_permitted(self):
        c = client([])
        for method, url in [("DELETE", AA_BASE + "/api/x/segments/y"), ("POST", AA_BASE + "/api/x/segments"),
                            ("GET", "https://example.com/"), ("GET", "https://analytics.adobe.io.evil.example/"), ("PUT", IMS_URL)]:
            with self.assertRaises(AdobeError):
                c._request(method, url)
        self.assertEqual(c.session.calls, [])

    def test_retry_bounded_and_no_redirects(self):
        c = client([Response({}, 429, {"Retry-After": "999"}), []])
        with patch("adobe_client.time.sleep") as sleep:
            self.assertEqual(c.get_projects(), [])
        sleep.assert_called_once_with(10)
        self.assertTrue(all(call[2]["allow_redirects"] is False for call in c.session.calls))

    def test_token_cache_private_and_context_bound(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "cache.json"
            cfg = Config(client_id="fixture", client_secret="fake", scopes="fake-scope", company_id="fixture", token_cache=path)
            session = Session([Response({"access_token": "fixture-generated-token", "expires_in": 86400000})])
            c = AdobeAnalyticsClient(cfg, session)
            self.assertEqual(c.token(), "fixture-generated-token")
            self.assertEqual(os.stat(path).st_mode & 0o777, 0o600)
            self.assertEqual(session.calls[0][0:2], ("POST", IMS_URL))
            cached = AdobeAnalyticsClient(cfg, Session([]))
            self.assertEqual(cached.token(), "fixture-generated-token")
            cfg.scopes = "different-scope"
            changed = AdobeAnalyticsClient(cfg, Session([Response({"access_token": "different-token", "expires_in": 3600})]))
            self.assertEqual(changed.token(), "different-token")

    def test_invalid_token_expiry_rejected(self):
        c = AdobeAnalyticsClient(Config(client_id="fake", client_secret="fake", scopes="fake"), Session([Response({"access_token": "fake", "expires_in": "nan"})]))
        with self.assertRaisesRegex(AdobeError, "expiry"):
            c.token()

    def test_expired_bearer_refreshes_once_without_browser_credentials(self):
        with tempfile.TemporaryDirectory() as directory:
            cfg = Config(client_id="fixture", client_secret="fake", scopes="fake", company_id="fixture", token_cache=Path(directory) / "cache.json")
            session = Session([Response({"access_token": "old-fixture-token", "expires_in": 3600}),
                               Response({}, 401), Response({"access_token": "new-fixture-token", "expires_in": 3600}), Response([])])
            c = AdobeAnalyticsClient(cfg, session)
            self.assertEqual(c.get_projects(), [])
            self.assertEqual([call[0] for call in session.calls], ["POST", "GET", "POST", "GET"])
            self.assertEqual(session.calls[-1][2]["headers"]["Authorization"], "Bearer new-fixture-token")

    def test_redirect_rejected(self):
        c = client([Response({}, 302, {"Location": "https://example.com"})])
        with self.assertRaisesRegex(AdobeError, "HTTP 302"):
            c.get_projects()


if __name__ == "__main__":
    unittest.main()
