"""Opt-in read-only live check. Prints counts only; no credentials or IDs.

Run: .venv/bin/python tests/verify_live.py
Creates private reports and a count-only QA record under output/live-verification/.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from collections import Counter, defaultdict
from itertools import combinations
import json
import math
import os
import time

from adobe_client import Config, AdobeAnalyticsClient, IMS_URL
from cja_client import CjaClient
from providers import make_client, get_provider
import segment_analysis as core


def independent_normal_form(value):
    """Independent exact grouping oracle, not the application's canonicaliser."""
    if isinstance(value, list):
        return [independent_normal_form(item) for item in value]
    if not isinstance(value, dict):
        return value
    result = {key: independent_normal_form(item) for key, item in sorted(value.items())}
    if result.get("func") in ("and", "or") and isinstance(result.get("preds"), list):
        result["preds"].sort(key=lambda item: json.dumps(item, sort_keys=True))
    return result


def verify(tool):
    start = time.monotonic()
    client = make_client(tool)
    requests_count = Counter()
    original_request = client._request
    def observed(method, url, **kwargs):
        requests_count[method + (" IMS" if url == IMS_URL else " " + tool)] += 1
        return original_request(method, url, **kwargs)
    client._request = observed
    scopes = client.get_scopes()
    segments = client.get_segments()
    directory = Path(__file__).resolve().parents[1] / "output" / "live-verification" / tool
    result = core.run_pipeline(client, output_dir=directory, segments=segments, scopes=scopes, tool=tool)
    by_suite, exact_groups = defaultdict(list), defaultdict(list)
    for segment in result["segments"]:
        if core.definition_issue(segment):
            continue
        norm = json.dumps(independent_normal_form(segment["definition"]), sort_keys=True, separators=(",", ":"))
        by_suite[core.get_scope_id(segment)].append((str(segment["id"]), norm, core.tokenize(segment)))
        exact_groups[(core.get_scope_id(segment), norm)].append(str(segment["id"]))
    expected_exact = {tuple(sorted(pair)) for group in exact_groups.values() for pair in combinations(group, 2)}
    actual_exact = {tuple(sorted([str(m["a"]["id"]), str(m["b"]["id"])])) for m in result["matches"] if m["type"] == "Exact duplicate"}
    expected_near, possible = set(), 0
    for group in by_suite.values():
        possible += math.comb(len(group), 2)
        for a, b in combinations(group, 2):
            if a[1] == b[1]:
                continue
            # Exhaustive scan validates that the inverted index misses no eligible pair.
            score = 100 * len(a[2] & b[2]) / len(a[2] | b[2])
            if score >= 85:
                expected_near.add(tuple(sorted([a[0], b[0]])))
    actual_near = {tuple(sorted([str(m["a"]["id"]), str(m["b"]["id"])])) for m in result["matches"] if m["type"] == "Near duplicate"}
    assert expected_exact == actual_exact, "Exact grouping disagrees with independent normal form"
    assert expected_near == actual_near, "Inverted index differs from exhaustive pair scan"
    assert all(core.get_scope_id(m["a"]) == core.get_scope_id(m["b"]) for m in result["matches"]), "Cross-suite pair found"
    assert not any(key not in ("GET " + tool, "POST IMS") for key in requests_count), "Unexpected write request"
    summary = {key: result[key] for key in ("segment_count", "assessed_count", "unassessed_count", "match_count", "exact_count", "near_count", "unique_count", "usage_loaded", "threshold")}
    summary.update({"tool": tool, "scope_count": len(scopes), "segment_scope_count": len(by_suite),
                     "possible_same_suite_pairs": possible,
                    "independent_exact_grouping": "PASS", "exhaustive_candidate_coverage": "PASS",
                    "cross_suite_protection": "PASS", "request_counts": dict(requests_count),
                    "analytics_writes": 0, "elapsed_seconds": round(time.monotonic() - start, 2)})
    target = directory / "verification_counts.json"
    target.write_text(json.dumps(summary, indent=2) + "\n")
    os.chmod(target, 0o600)
    print(json.dumps(summary, indent=2), flush=True)
    return summary


if __name__ == "__main__":
    for tool in ("cja", "aa"):
        verify(tool)
