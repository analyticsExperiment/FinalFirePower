// Playwright CLI snippet. Start on V3 ?tool=aa or standalone Analytics landing.
async (page) => {
  const assert = (value, message) => { if (!value) throw new Error(message); };
  const frame = () => page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  const native = page.locator('#scopeSelect, #reportSuiteSelect');
  const trigger = page.getByRole('combobox', {name:'Report Suite', exact:true});
  const search = page.getByRole('searchbox', {name:'Search Report Suites', exact:true});
  const list = page.getByRole('listbox', {name:'Report Suites', exact:true});
  await page.waitForFunction(() => {
    const select = document.querySelector('#scopeSelect, #reportSuiteSelect');
    return select && select.options.length > 200 && !document.querySelector('.suite-trigger').disabled;
  });
  assert(await native.isHidden(), 'Native Report Suite popup was not replaced');
  assert(await native.inputValue() === 'ALL', 'Default All Report Suites was lost');
  const total = await native.evaluate(el => el.options.length);
  await trigger.click();
  assert(await trigger.getAttribute('aria-expanded') === 'true', 'Picker did not open');
  const box = await list.boundingBox();
  const pageTop = await page.evaluate(() => scrollY);
  await page.mouse.move(box.x + box.width / 2, box.y + Math.min(80, box.height / 2));
  for (let i=0; i<5; i++) { await page.mouse.wheel(0, 600); await frame(); }
  const wheelScroll = await list.evaluate(el => el.scrollTop);
  assert(wheelScroll > 0, 'Wheel did not scroll the suite list');
  assert(await list.isVisible(), 'Picker disappeared while wheel scrolling');
  assert(await page.evaluate(() => scrollY) === pageTop, 'Wheel scrolled the page instead of the list');
  assert(await native.inputValue() === 'ALL', 'Wheel changed the committed suite');

  // Move the scrollbar itself without holding the selector button.
  await search.press('Home'); await frame();
  const dragBox = await list.boundingBox();
  // This desktop's classic scrollbar has a top arrow; start on its thumb.
  await page.mouse.move(dragBox.x + dragBox.width - 6, dragBox.y + 30);
  await page.mouse.down();
  await page.mouse.move(dragBox.x + dragBox.width - 6, dragBox.y + dragBox.height - 30, {steps:10});
  await page.mouse.up(); await frame();
  const dragScroll = await list.evaluate(el => el.scrollTop);
  assert(dragScroll > 0, 'Scrollbar drag did not scroll');
  assert(await list.isVisible(), 'Scrollbar drag dismissed the picker');

  // Keep boundary scrolling inside the bounded menu as well.
  await search.press('End'); await frame();
  await page.mouse.move(dragBox.x + dragBox.width/2, dragBox.y + dragBox.height/2);
  await page.mouse.wheel(0, 1200); await frame();
  assert(await list.isVisible(), 'End-of-list wheel dismissed the picker');
  assert(await page.evaluate(() => scrollY) === pageTop, 'End-of-list wheel escaped to page');

  await search.fill('no-such-report-suite-qa-7b91');
  assert(await page.getByText('No Report Suites match this search.', {exact:true}).isVisible(), 'No-result state missing');
  await search.press('Enter');
  assert(await native.inputValue() === 'ALL', 'No-result Enter committed an invalid suite');
  assert(await list.isVisible(), 'No-result search dismissed the picker');
  const target = await native.evaluate(el => ({value:el.options[el.options.length-1].value, text:el.options[el.options.length-1].textContent}));
  await search.fill(target.value);
  await page.getByRole('option', {name:target.text, exact:true}).click();
  assert(await native.inputValue() === target.value, 'Mouse choice did not reach native form control');
  assert(await trigger.getAttribute('aria-expanded') === 'false', 'Picker did not close after choosing');
  const formValue = await native.evaluate(el => new FormData(el.form).get(el.name));
  assert(formValue === target.value, 'Selected Report Suite was not in form data');

  await trigger.click(); await search.fill('no-such-report-suite-qa-7b91'); await search.press('Escape');
  assert(await native.inputValue() === target.value, 'Escape changed committed selection');
  assert(await trigger.getAttribute('aria-expanded') === 'false', 'Escape did not dismiss picker');
  await trigger.click(); await search.fill(''); await search.press('Home'); await search.press('Enter');
  assert(await native.inputValue() === 'ALL', 'Keyboard could not restore All Report Suites');
  // The popup overlays lower form fields; click a genuinely outside heading.
  await trigger.click(); await page.getByRole('heading', {level:1}).click();
  assert(await trigger.getAttribute('aria-expanded') === 'false', 'Outside click did not dismiss picker');
  assert(await page.getByRole('button', {name:'Generate Dashboard', exact:true}).isEnabled(), 'Generate button lost valid selection');
  assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'Horizontal overflow');

  let cjaControl = 'not applicable';
  if (await page.locator('#toolSelect').count()) {
    await page.getByRole('combobox', {name:'Analysis Tool', exact:true}).selectOption('cja');
    await page.waitForFunction(() => !document.querySelector('#scopeSelect').disabled);
    const cja = page.getByRole('combobox', {name:'Data View', exact:true});
    assert(await cja.evaluate(el => el.tagName) === 'SELECT', 'CJA was changed from native select');
    assert(await cja.isVisible(), 'Working CJA dropdown was hidden');
    assert(await page.locator('.suite-picker').isHidden(), 'AA picker remained visible for CJA');
    assert(await cja.evaluate(el => el.required), 'CJA required validation was not restored');
    await cja.selectOption('ALL');
    await page.getByRole('combobox', {name:'Analysis Tool', exact:true}).selectOption('aa');
    await page.waitForFunction(() => !document.querySelector('.suite-trigger').disabled);
    assert(await native.isHidden(), 'AA picker was not restored after switching back');
    cjaControl = 'unchanged and working';
  }
  await trigger.click();
  await page.screenshot({path:(await page.locator('#toolSelect').count()) ? 'suite-picker-v3-fixed.png' : 'suite-picker-standalone-fixed.png'});
  await search.press('Escape');
  return {options:total, wheelScroll, dragScroll, wheelAndScrollbarStayOpen:'PASS', boundaryScroll:'PASS',
    searchById:'PASS', noResults:'PASS', mouseAndKeyboardSelection:'PASS', formValue:'PASS',
    escapeAndOutsideClick:'PASS', cjaControl};
}
