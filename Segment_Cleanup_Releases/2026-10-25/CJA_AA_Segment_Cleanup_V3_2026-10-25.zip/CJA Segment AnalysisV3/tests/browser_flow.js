// Run with playwright-cli run-code --filename=../../tests/browser_flow.js
// Starting point: the synthetic CJA ALL report at 127.0.0.1:5004.
async (page) => {
  const assert = (condition, message) => { if (!condition) throw new Error(message); };
  const evidence = [];
  const ready = () => page.waitForFunction(() => !document.querySelector('#generateButton').disabled);
  const generate = async () => {
    await Promise.all([page.waitForURL('**/generate'), page.getByRole('button', {name:'Generate Dashboard', exact:true}).click({noWaitAfter:true})]);
  };
  const save = async (button, file, prefix) => {
    const event = page.waitForEvent('download');
    await button.click();
    const download = await event;
    assert(download.suggestedFilename().startsWith(prefix + '_'), 'Wrong provider download name');
    await download.saveAs(file);
  };

  for (const tool of ['cja', 'aa']) {
    const title = tool === 'cja' ? 'CJA' : 'Adobe Analytics';
    const label = tool === 'cja' ? 'Data View' : 'Report Suite';
    const prefix = tool === 'cja' ? 'CJA' : 'AA';
    const counts = await page.evaluate(() => ({tool:REPORT_CONFIG.tool, segments:SEGMENTS_DATA.length,
      pairs:MATCHES_DATA.length, cards:Array.from(document.querySelectorAll('.card .value')).map(x=>x.textContent)}));
    assert(counts.tool === tool && counts.segments === 23 && counts.pairs === 15, 'Wrong report data');
    assert(counts.cards.join(',') === '23,3,6,16', 'Scorecards do not agree');
    await page.getByRole('button', {name:'Available ' + title + ' Segments', exact:false}).click();
    await page.getByRole('button', {name:'Duplicate / Near-Duplicate Segments', exact:false}).click();
    const sr = page.locator('#segmentsCard-body'), cr = page.locator('#comparisonCard-body');
    await sr.getByRole('button', {name:'Next', exact:true}).click();
    await cr.getByRole('button', {name:'Next', exact:true}).click();
    assert((await page.locator('#segmentPagination .pagination-info').textContent()).includes('11-20 of 23'), 'Segment paging failed');
    assert((await page.locator('#comparisonPagination .pagination-info').textContent()).includes('11-15 of 15'), 'Comparison paging failed');
    await sr.getByRole('combobox').selectOption('20');
    await cr.getByRole('combobox').selectOption('20');
    await page.getByPlaceholder('Search by segment name...', {exact:true}).fill('Checkout');
    await page.getByPlaceholder('Search comparison results by segment name...', {exact:true}).fill('variant 0');
    assert((await page.locator('#segmentPagination .pagination-info').textContent()).includes('of 7'), 'Segment search failed');
    assert((await page.locator('#comparisonPagination .pagination-info').textContent()).includes('of 5'), 'Pair search failed');
    await save(page.getByRole('button', {name:'⬇ Download Full Segment List (CSV)', exact:true}), `fixture-${tool}.csv`, prefix);
    await save(page.getByRole('button', {name:'⬇ Download Comparison Results (Excel)', exact:true}), `fixture-${tool}.xls`, prefix);
    await save(sr.getByRole('button', {name:'Download Excel', exact:true}), `fixture-${tool}-filtered-segments.xls`, prefix);
    await save(cr.getByRole('button', {name:'Download Excel', exact:true}), `fixture-${tool}-filtered-pairs.xls`, prefix);
    await sr.getByRole('button', {name:'Clear Search', exact:true}).click();
    await cr.getByRole('button', {name:'Clear Search', exact:true}).click();
    const heading = page.getByRole('button', {name:'Available ' + title + ' Segments', exact:false});
    await heading.focus(); await page.keyboard.press('Enter');
    assert(await heading.getAttribute('aria-expanded') === 'false', 'Keyboard collapse failed');
    await page.keyboard.press('Enter');
    assert(await heading.getAttribute('aria-expanded') === 'true', 'Keyboard expansion failed');
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'Horizontal overflow');
    await page.screenshot({path:`fixture-${tool}-tables.png`});
    await page.getByRole('link', {name:'← Change ' + label, exact:true}).click();
    await ready();
    assert(await page.getByRole('combobox', {name:'Analysis Tool', exact:true}).inputValue() === tool, 'Return did not retain tool');
    assert(await page.locator('#scopeSelect').inputValue() === 'ALL', 'Return did not load all scopes');

    // Individual and empty scopes for both tools, then return to the same landing.
    for (const [scope, expected] of tool === 'cja' ? [['dv_two',1], ['dv_empty',0]] : [['other_suite',1], ['empty_suite',0]]) {
      if (tool === 'cja') await page.getByRole('combobox', {name:label, exact:true}).selectOption(scope);
      else {
        await page.getByRole('combobox', {name:label, exact:true}).click();
        await page.getByRole('searchbox', {name:'Search Report Suites', exact:true}).fill(scope);
        const optionText = await page.locator('#scopeSelect').evaluate((el, id) => Array.from(el.options).find(o=>o.value===id).textContent, scope);
        await page.getByRole('option', {name:optionText, exact:true}).click();
      }
      await generate();
      assert(await page.evaluate(() => SEGMENTS_DATA.length) === expected, 'Selected scope count failed');
      assert(await page.evaluate(() => MATCHES_DATA.length) === 0, 'Unexpected pair in individual/empty scope');
      await page.getByRole('link', {name:'← Change ' + label, exact:true}).click();
      await ready();
    }
    evidence.push({tool, report:counts, exports:'PASS', searchPaginationKeyboard:'PASS', individualEmptyReturn:'PASS'});
    if (tool === 'cja') {
      await page.getByRole('combobox', {name:'Analysis Tool', exact:true}).selectOption('aa');
      await ready(); await generate();
    }
  }

  // Resetting the tool hides the dependent fields.
  const toolSelect = page.getByRole('combobox', {name:'Analysis Tool', exact:true});
  await toolSelect.selectOption('');
  assert(await page.locator('#scopePanel').isHidden(), 'Scope panel remained visible');

  // One provider failing must not prevent the other from working.
  await page.route('**/api/scopes?tool=cja', route => route.fulfill({status:502, contentType:'application/json', body:JSON.stringify({error:'Synthetic access denied'})}));
  await toolSelect.selectOption('cja');
  await page.waitForFunction(() => document.querySelector('#status').textContent.includes('Synthetic access denied'));
  assert(await page.locator('#generateButton').isDisabled(), 'Generation enabled after failed load');
  await toolSelect.selectOption('aa'); await ready();
  assert(await page.locator('#status').textContent() === '', 'Old provider error remained');
  await page.unroute('**/api/scopes?tool=cja');

  // Emulate a fetch implementation that ignores aborts to exercise the version guard.
  await page.evaluate(() => {
    window.qaOriginalFetch = window.fetch;
    window.fetch = (url, options={}) => window.qaOriginalFetch(url, {...options, signal:undefined});
  });
  let releaseSlow, sawSlow;
  const gate = new Promise(resolve => releaseSlow = resolve);
  const seen = new Promise(resolve => sawSlow = resolve);
  await page.route('**/api/scopes?tool=cja', async route => {
    sawSlow(); await gate;
    await route.fulfill({contentType:'application/json',body:JSON.stringify({tool:'cja', scopes:[{id:'dv_late',name:'Late CJA view'}]})});
  });
  await toolSelect.selectOption('cja'); await seen;
  await toolSelect.selectOption('aa'); await ready();
  const late = page.waitForResponse(response => response.url().endsWith('/api/scopes?tool=cja'));
  releaseSlow(); await (await late).finished();
  await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
  assert(await page.locator('#scopeLabel').textContent() === 'Report Suite', 'Late CJA response overwrote AA label');
  assert(await page.evaluate(() => !Array.from(document.querySelector('#scopeSelect').options).some(o=>o.value.startsWith('dv_'))), 'Late CJA scopes leaked into AA');
  await page.unroute('**/api/scopes?tool=cja');
  await page.evaluate(() => {window.fetch=window.qaOriginalFetch; delete window.qaOriginalFetch;});
  evidence.push({providerFailureIsolation:'PASS', staleResponseIsolation:'PASS', resetTool:'PASS'});
  return evidence;
}
