// Playwright CLI function; synthetic servers ONLY at 5006/5007. Never Adobe.
async(page)=>{
 const assert=(value,message)=>{if(!value)throw new Error(message);};
 assert(['5006','5007'].includes(new URL(page.url()).port),'This helper must never target a live server');
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.setViewportSize({width:1440,height:1000});
 const unified=await page.locator('#toolSelect').count()>0;
 const initial=async(tool='aa')=>{
  if(unified)await page.getByRole('combobox',{name:'Analysis Tool',exact:true}).selectOption(tool);
  await page.waitForFunction(()=>!document.querySelector('#generateButton').disabled);
  if(tool==='aa'){
   await page.getByRole('combobox',{name:'Report Suite',exact:true}).click();
   await page.getByRole('searchbox',{name:'Search Report Suites',exact:true}).fill('Synthetic');
   await page.getByRole('option',{name:'Synthetic Cleanup Scope',exact:true}).click();
  }else await page.getByRole('combobox',{name:'Data View',exact:true}).selectOption('qa_cja');
  await Promise.all([page.waitForURL('**/generate'),page.getByRole('button',{name:'Generate Dashboard',exact:true}).click({noWaitAfter:true})]);
  await page.locator('#cleanupPanel').waitFor();
  await page.locator('#cleanupPanel summary').click();
 };
 await initial();
 assert(await page.locator('.approval-value').allTextContents().then(v=>v.join(',')==='1,34,1'),'Approval counters');
 const search=page.getByRole('searchbox',{name:'Search cleanup segments',exact:true});
 const row=id=>page.locator('#cleanupBody tr').filter({hasText:id});
 await search.fill('qa02');assert(await row('qa02').getByRole('checkbox').isDisabled(),'Unknown approval selectable');
 await search.fill('qa01');assert(await row('qa01').getByRole('checkbox').isDisabled(),'Approved selectable');
 await search.fill('qa03');assert(await row('qa03').getByRole('checkbox').isDisabled(),'Published selectable');
 await search.fill('qa04');assert(await row('qa04').getByRole('checkbox').isDisabled(),'Used segment selectable');
 await search.fill('');await page.locator('#cleanupNext').click();
 assert((await page.locator('#cleanupPagination').innerText()).includes('Page 2'),'Cleanup pagination');
 await page.locator('#cleanupPageSize').selectOption('20');assert(await page.locator('#cleanupBody tr').count()===20,'Cleanup page size');
 await search.fill('qa05');await row('qa05').getByRole('button').click();
 await page.locator('#cleanupDialog').waitFor({state:'visible'});
 assert(await page.locator('#cleanupConfirm').isDisabled(),'Confirmation enabled without review');
 await page.locator('#cleanupCancel').click();assert(await page.locator('#cleanupDialog').isHidden(),'Cancel failed');
 assert(await page.evaluate(()=>SEGMENTS_DATA.length)===36,'Cancel deleted a segment');
 await row('qa05').getByRole('button').click();await page.locator('#cleanupDialog').waitFor({state:'visible'});
 await page.locator('#cleanupType').fill('DELETE');assert(await page.locator('#cleanupConfirm').isDisabled(),'Owner review bypassed');
 await page.locator('#cleanupOwner').check();assert(await page.locator('#cleanupConfirm').isEnabled(),'Valid confirmation not accepted');
 await page.screenshot({path:unified?'cleanup-v3-confirm.png':'cleanup-aa-confirm.png'});
 await Promise.all([page.waitForURL('**/dashboard?**'),page.locator('#cleanupConfirm').click({noWaitAfter:true})]);
 await page.locator('#cleanupPanel').waitFor();
 assert(await page.evaluate(()=>SEGMENTS_DATA.length)===35,'Successful deletion did not refresh inventory');
 assert(!await page.evaluate(()=>SEGMENTS_DATA.some(s=>s.id==='qa05')),'Deleted ID remained in inventory');
 await page.locator('#cleanupPanel summary').click();
 assert((await page.locator('#cleanupMessage').innerText()).includes('deleted'),'Result message not restored');
 // A simulated partial batch: one success, one permission failure, one pending.
 await search.fill('');
 for(const id of ['qa06','qa07','qa08']){await search.fill(id);await row(id).getByRole('checkbox').check();}
 await page.locator('#cleanupPreview').click();await page.locator('#cleanupDialog').waitFor({state:'visible'});
 await page.locator('#cleanupType').fill('DELETE');await page.locator('#cleanupOwner').check();
 await Promise.all([page.waitForURL(url=>url.pathname==='/dashboard'&&url.search.includes('threshold='),{waitUntil:'load'}),page.locator('#cleanupConfirm').click({noWaitAfter:true})]);
 await page.waitForFunction(()=>typeof SEGMENTS_DATA!=='undefined'&&SEGMENTS_DATA.length===34);
 await page.locator('#cleanupPanel summary').click();
 assert((await page.locator('#cleanupMessage').innerText()).includes('pending'),'Pending not distinguished');
 assert((await page.locator('#cleanupMessage').innerText()).includes('failed'),'Failure not distinguished');
 assert(await page.evaluate(()=>SEGMENTS_DATA.some(s=>s.id==='qa07')&&SEGMENTS_DATA.some(s=>s.id==='qa08')),'Failure or pending falsely removed');
 // Select every known exact copy: preview must reserve one canonical member.
 await search.fill('qa1');
 for(const id of ['qa10','qa11','qa12'])await row(id).getByRole('checkbox').check();
 await page.locator('#cleanupPreview').click();await page.locator('#cleanupDialog').waitFor({state:'visible'});
 assert((await page.locator('#cleanupPreviewList').innerText()).includes('Retain at least one'),'Keep-one protection absent');
 await page.locator('#cleanupCancel').click();
 await page.locator('#cleanupClearSelection').click();
 assert((await page.locator('#cleanupSelection').innerText())==='0 selected','Selection not cleared');
 assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Desktop overflow');
 await page.screenshot({path:unified?'cleanup-v3-result.png':'cleanup-aa-result.png'});
 let cja='not applicable';
 if(unified){
  await page.getByRole('link',{name:'Change Tool',exact:true}).click();await initial('cja');
  await search.fill('qa05');await row('qa05').getByRole('button').click();await page.locator('#cleanupDialog').waitFor({state:'visible'});
  assert((await page.locator('#cleanupPreviewList').innerText()).includes('Fresh checks passed'),'CJA preflight failed');
  await page.locator('#cleanupType').fill('DELETE');await page.locator('#cleanupOwner').check();
  await Promise.all([page.waitForURL('**/dashboard?**'),page.locator('#cleanupConfirm').click({noWaitAfter:true})]);
  await page.waitForFunction(()=>SEGMENTS_DATA.length===35);
  cja='synthetic preview execute refresh PASS';
 }
 assert(errors.length===0,errors.join(';'));
 return{app:unified?'V3':'standalone',approvalAndUsageBlocks:'PASS',searchPagingSelection:'PASS',cancel:'PASS',typedAndOwnerConfirmation:'PASS',singleSuccessRefresh:'PASS',partialBatchFailurePending:'PASS',keepOneExactCopy:'PASS',desktopOverflow:'none',javascriptErrors:errors.length,cja,adobeRequests:0};
}
