"""Synthetic UI deletion server. No Adobe/network calls are possible."""
from pathlib import Path
from types import SimpleNamespace
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from unittest.mock import patch
import app
from tests.test_deletion import FakeClient
from tests.fixtures import segment, predicate


def fixture(scope):
    records=[segment(f'qa{i:02}',predicate(value=f'unique{i}'),rsid=scope,
                     name=f'Synthetic cleanup segment {i:02}',approved=False,publishingStatus={'published':False}) for i in range(36)]
    records[1]['approved']=True
    records[2].pop('approved')
    records[3]['publishingStatus']={'published':True}
    for i in (11,12):records[i]['definition']=records[10]['definition']
    c=FakeClient(records)
    c.projects=[{'id':'p','definition':{'segment':'qa04'}}]
    c.get_scopes=lambda:[{'id':scope,'name':'Synthetic Cleanup Scope'}]
    c.outcomes['qa07']={'status':'failed','error':'Synthetic permission refusal'}
    c.outcomes['qa08']={'status':'pending','error':'Synthetic asynchronous response'}
    return c


if hasattr(app,'_clients'):
    app._clients={'aa':fixture('qa_aa'),'cja':fixture('qa_cja')}
    port=5006
else:
    app._client=fixture('qa_aa')
    port=5007
app.APP_DIR=Path(__file__).resolve().parents[1]/'output'/'deletion-fixture'


@app.app.after_request
def synthetic_banner(response):
    if response.mimetype=='text/html':
        response.set_data(response.get_data(as_text=True).replace('<body>','<body><aside style="padding:10px;background:#fff0ba;text-align:center">SYNTHETIC QA ONLY — DELETIONS ARE SIMULATED — NO ADOBE CONNECTION</aside>',1))
    return response


if __name__=='__main__':
    with patch('requests.sessions.Session.request',side_effect=AssertionError('Network forbidden in deletion fixture')):
        app.app.run(host='127.0.0.1',port=port,debug=False)
