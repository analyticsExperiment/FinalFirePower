"""Read back actual browser downloads from both unified-app paths."""
from collections import Counter
from pathlib import Path
import csv
import json
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1] / "output" / "playwright"
NS = {"s": "urn:schemas-microsoft-com:office:spreadsheet"}


def excel_rows(path):
    rows = ET.parse(path).getroot().findall(".//s:Row", NS)
    cells = [[cell.text or "" for cell in row.findall("s:Cell/s:Data", NS)] for row in rows]
    assert len({len(row) for row in cells}) == 1
    return cells[0], [dict(zip(cells[0], row)) for row in cells[1:]]


def verify():
    summary = {}
    for tool, label in [("cja", "Data View"), ("aa", "Report Suite")]:
        with (ROOT / f"fixture-{tool}.csv").open(encoding="utf-8-sig") as handle:
            inventory = list(csv.DictReader(handle))
        assert len(inventory) == 23
        assert label + " ID" in inventory[0]
        assert sum(row["Analysis status"] != "Assessed" for row in inventory) == 1
        for row in inventory:
            json.loads(row["Definition (JSON)"])
        _, pairs = excel_rows(ROOT / f"fixture-{tool}.xls")
        _, filtered_segments = excel_rows(ROOT / f"fixture-{tool}-filtered-segments.xls")
        _, filtered_pairs = excel_rows(ROOT / f"fixture-{tool}-filtered-pairs.xls")
        assert (len(pairs), len(filtered_segments), len(filtered_pairs)) == (15, 7, 5)
        assert Counter(row["Type"] for row in pairs) == {"Exact duplicate": 3, "Near duplicate": 12}
        assert all(row["Segment A " + label + " ID"] == row["Segment B " + label + " ID"] for row in pairs)
        summary["fixture-" + tool] = {"inventory": 23, "pairs": 15, "filtered_inventory": 7, "filtered_pairs": 5, "scope_headers": "PASS"}

        with (ROOT / f"live-{tool}.csv").open(encoding="utf-8-sig") as handle:
            live = list(csv.DictReader(handle))
        _, live_pairs = excel_rows(ROOT / f"live-{tool}.xls")
        audit = json.loads((ROOT.parent / "live-verification" / tool / "verification_counts.json").read_text())
        assert len(live) == audit["segment_count"] and len(live_pairs) == audit["match_count"]
        assert Counter(row["Type"] for row in live_pairs) == {"Exact duplicate": audit["exact_count"], "Near duplicate": audit["near_count"]}
        assert all(row["Segment A " + label + " ID"] == row["Segment B " + label + " ID"] for row in live_pairs)
        assert all(isinstance(json.loads(row["Definition (JSON)"]), dict) for row in live)
        summary["live-" + tool] = {"inventory": len(live), "pairs": len(live_pairs), "scope_headers_and_definitions": "PASS"}
    print(json.dumps(summary, indent=2))


if __name__ == "__main__": verify()
