// Run only after the synthetic cleanup flow at 5006/5007.
async(page)=>{
 const assert=(value,message)=>{if(!value)throw new Error(message);};
 assert(['5006','5007'].includes(new URL(page.url()).port),'Synthetic servers only');
 const unified=await page.getByRole('link',{name:'Change Tool',exact:true}).count()>0;
 const label=unified?'v3':'standalone';
 const save=async(button,path)=>{const event=page.waitForEvent('download');await button.click();await(await event).saveAs(path);};
 const config=await page.evaluate(()=>({title:typeof REPORT_CONFIG==='undefined'?'Adobe Analytics':REPORT_CONFIG.title,segments:SEGMENTS_DATA.length,pairs:MATCHES_DATA.length}));
 await save(page.getByRole('button',{name:'⬇ Download Full Segment List (CSV)',exact:true}),`cleanup-${label}.csv`);
 await save(page.getByRole('button',{name:'⬇ Download Comparison Results (Excel)',exact:true}),`cleanup-${label}-pairs.xls`);
 const inventory=page.getByRole('button',{name:'Available '+config.title+' Segments',exact:false});
 if(await inventory.getAttribute('aria-expanded')!=='true')await inventory.click();
 await page.getByPlaceholder('Search by segment name...',{exact:true}).fill('segment 10');
 await save(page.locator('#segmentsCard-body').getByRole('button',{name:'Download Excel',exact:true}),`cleanup-${label}-filtered.xls`);
 const pairs=page.getByRole('button',{name:'Duplicate / Near-Duplicate Segments',exact:false});
 if(await pairs.getAttribute('aria-expanded')!=='true')await pairs.click();
 await page.getByPlaceholder('Search comparison results by segment name...',{exact:true}).fill('segment 10');
 await save(page.locator('#comparisonCard-body').getByRole('button',{name:'Download Excel',exact:true}),`cleanup-${label}-filtered-pairs.xls`);
 const count=await page.evaluate(()=>({segments:SEGMENTS_DATA.length,pairs:MATCHES_DATA.length,filteredSegments:segmentState.filtered.length,filteredPairs:comparisonState.filtered.length}));
 return {app:label,downloaded:count};
}
