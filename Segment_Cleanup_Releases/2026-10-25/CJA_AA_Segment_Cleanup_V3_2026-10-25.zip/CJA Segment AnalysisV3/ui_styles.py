PAGE_STYLE = """
<style>
:root {
  --bg:#f4f7fb; --card:#fff; --text:#1d2939; --muted:#667085;
  --border:#d8e0ea; --accent:#4169f6; --accent-dark:#3158e6;
  --green:#2e7d32; --green-bg:#edf7ed; --red:#c62828; --red-bg:#fdecea;
}
* { box-sizing:border-box; }
body { margin:0; min-height:100vh; font-family:Arial,Helvetica,sans-serif; background:var(--bg); color:var(--text); }
.container { max-width:1400px; margin:0 auto; padding:70px 20px 44px; }
.panel { background:var(--card); padding:34px 20px; border-radius:8px; box-shadow:0 2px 9px rgba(0,0,0,.09); }
.panel h2 { margin:6px 0 20px; font-size:24px; }
.landing-shell { display:flex; justify-content:center; align-items:flex-start; min-height:100vh; padding:88px 24px 48px; }
.landing-card { width:100%; max-width:590px; padding:32px; border:1px solid #dde4ed; border-radius:12px; background:var(--card); box-shadow:0 4px 16px rgba(29,41,57,.08); }
.landing-card h1 { margin:0 0 5px; font-size:25px; line-height:1.25; font-weight:700; letter-spacing:-.2px; }
.landing-subtitle { margin:0 0 26px; color:var(--muted); font-size:14px; line-height:1.45; }
.field + .field { margin-top:18px; }
label { display:block; margin:0 0 7px; font-size:13px; line-height:1.3; font-weight:700; }
select, input { width:100%; height:42px; padding:9px 12px; border:1px solid var(--border); border-radius:7px; background:#fff; color:var(--text); font:14px Arial,Helvetica,sans-serif; }
select:focus, input:focus, button:focus-visible { outline:3px solid rgba(20,115,230,.22); outline-offset:1px; border-color:var(--accent); }
select:disabled { background:#f4f4f4; color:#999; }
.hint { margin-top:7px; color:var(--muted); font-size:12px; line-height:1.45; }
button { border:0; border-radius:7px; padding:11px 18px; font:600 14px Arial,Helvetica,sans-serif; cursor:pointer; }
button.primary { background:var(--accent); color:#fff; }
button.primary:hover:not(:disabled) { background:var(--accent-dark); }
button:disabled { opacity:.56; cursor:not-allowed; }
.generate-row { margin-top:23px; }
.generate-row .primary { width:100%; height:44px; }
.status { margin:0 0 18px; padding:0; font-size:13px; line-height:1.45; }
.status:empty { display:none; }
.status.error { padding:11px 13px; border-radius:5px; color:var(--red); background:var(--red-bg); }
.error-card { max-width:760px; margin:80px auto; }
a.back { display:inline-block; margin-top:18px; color:var(--accent); text-decoration:none; font-weight:600; }
</style>
"""
