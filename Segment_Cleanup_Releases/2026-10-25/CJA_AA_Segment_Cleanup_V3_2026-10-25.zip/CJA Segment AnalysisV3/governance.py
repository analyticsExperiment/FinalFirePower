"""Tri-state metadata: missing approval is never treated as Not Approved."""
import re


def approval_status(segment):
    tags = segment.get('tags') or []
    if segment.get('approved') is True or any(
        str(t.get('name', '') if isinstance(t, dict) else t).casefold() == 'approved' for t in tags
    ):
        return 'Approved'
    return 'Not Approved' if segment.get('approved') is False else 'Unknown'


def unpublished_confirmed(segment):
    status = segment.get('publishingStatus')
    return (status is False or isinstance(status, dict) and status.get('published') is False or
            isinstance(status, str) and status.casefold() in ('false', 'notpublished', 'not_published', 'unpublished'))


def valid_segment_id(value):
    return isinstance(value, str) and bool(re.fullmatch(r'[^\s\x00-\x1f\x7f]{1,200}', value)) and value not in ('.', '..')


def deletion_block_reason(segment, usage_map, usage_loaded, issue=''):
    if issue:
        return 'Definition or scope cannot be assessed.'
    approval = approval_status(segment)
    if approval == 'Approved':
        return 'Approved segment.'
    if approval == 'Unknown':
        return 'Approval status was not supplied; not verified.'
    if not unpublished_confirmed(segment):
        return 'Published or publishing status not verified.'
    if not usage_loaded:
        return 'Workspace usage is incomplete or unknown.'
    if usage_map.get(str(segment.get('id')), {}).get('count', 0):
        return 'Referenced by an accessible Workspace project.'
    if segment.get('usedIn') or (segment.get('usageSummary') or {}).get('count', 0):
        return 'Additional positive usage metadata was returned.'
    if segment.get('shares'):
        return 'Segment has positive sharing metadata; review dependencies.'
    return ''
