"""Adobe Analytics segment finder: API, analysis, report and exports in one file.

Consolidated from validated V3; no dynamic module loaders or sibling-app dependency.
Near scores concern definitions, not audience overlap. Writes are opt-in only.
"""


import re


# 1. Approval metadata and deletion eligibility (fail closed).
def approval_status(segment):
    tags = segment.get('tags') or []
    if segment.get('approved') is True or any(
        str(t.get('name', '') if isinstance(t, dict) else t).casefold() == 'approved' for t in tags
    ):
        return 'Approved'
    return 'Not Approved' if segment.get('approved') is False else 'Unknown'


def unpublished_confirmed(segment):
    status = segment.get('publishingStatus')
    return (status is False or isinstance(status, dict) and status.get('published') is False or
            isinstance(status, str) and status.casefold() in ('false', 'notpublished', 'not_published', 'unpublished'))


def valid_segment_id(value):
    return isinstance(value, str) and bool(re.fullmatch(r'[^\s\x00-\x1f\x7f]{1,200}', value)) and value not in ('.', '..')


def deletion_block_reason(segment, usage_map, usage_loaded, issue=''):
    if issue:
        return 'Definition or scope cannot be assessed.'
    approval = approval_status(segment)
    if approval == 'Approved':
        return 'Approved segment.'
    if approval == 'Unknown':
        return 'Approval status was not supplied; not verified.'
    if not unpublished_confirmed(segment):
        return 'Published or publishing status not verified.'
    if not usage_loaded:
        return 'Workspace usage is incomplete or unknown.'
    if usage_map.get(str(segment.get('id')), {}).get('count', 0):
        return 'Referenced by an accessible Workspace project.'
    if segment.get('usedIn') or (segment.get('usageSummary') or {}).get('count', 0):
        return 'Additional positive usage metadata was returned.'
    if segment.get('shares'):
        return 'Segment has positive sharing metadata; review dependencies.'
    return ''


from urllib.parse import quote
import requests


# 2. Fixed-endpoint, opt-in mutation; ordinary transport below stays read-only.
class SegmentMutationMixin:
    def _segment_url(self, segment_id):
        if not valid_segment_id(segment_id):
            raise ValueError('Invalid segment ID.')
        identifier = quote(segment_id, safe='')
        return 'https://analytics.adobe.io/api/' + quote(self.resolve_company(), safe='') + '/segments/' + identifier

    def get_segment(self, segment_id):
        return self._get(self._segment_url(segment_id), {'expansion':
            'definition,tags,compatibility,reportSuiteName,ownerFullName,modified,publishingStatus,definitionLastModified,categories,approved'})

    def delete_segment(self, segment_id):
        if not getattr(self.config, 'deletion_enabled', False):
            raise ValueError('Live deletion is disabled on this server.')
        url = self._segment_url(segment_id)
        try:
            response = self.session.request('DELETE', url, headers=self._headers(),
                                            timeout=(10, 45), allow_redirects=False)
        except requests.RequestException:
            return {'status': 'unknown', 'error': 'Delete response was lost. Do not retry automatically; check Adobe.'}
        if response.status_code == 204:
            return {'status': 'deleted', 'error': None}
        if response.status_code == 202:
            return {'status': 'pending', 'error': 'Adobe accepted the request; completion is not confirmed.'}
        if response.status_code == 200:
            try:
                payload = response.json()
            except ValueError:
                payload = None
            if isinstance(payload, dict) and payload.get('status') == 'ok' and not payload.get('error'):
                return {'status': 'deleted', 'error': None}
            return {'status': 'unknown', 'error': 'Adobe did not provide a recognised deletion confirmation.'}
        if response.status_code >= 500:
            return {'status': 'unknown', 'error': 'Adobe returned a server error. Completion is unknown; verify in Adobe.'}
        return {'status': 'failed', 'error': f'Adobe returned HTTP {response.status_code}. No success was confirmed. Check permissions or the segment in Adobe.'}


from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import quote
import hashlib
import json
import math
import os
import tempfile
import threading
import time

from dotenv import dotenv_values
import requests

APP_DIR = Path(__file__).resolve().parent
AA_BASE = "https://analytics.adobe.io"
IMS_URL = "https://ims-na1.adobelogin.com/ims/token/v3"
SEGMENT_EXPANSION = (
    "reportSuiteName,ownerFullName,modified,tags,compatibility,definition,"
    "publishingStatus,definitionLastModified,categories,approved"
)
PROJECT_EXPANSION = "reportSuiteName,ownerFullName,modified,tags,accessLevel,externalReferences,definition"


class AdobeError(RuntimeError):
    """Only sanitised messages may be returned to the UI or CLI."""


# 3. Server configuration, OAuth, private cache, API reads and pagination.
@dataclass(repr=False)
class Config:
    client_id: str = field(repr=False)
    client_secret: str = field(default="", repr=False)
    scopes: str = field(default="", repr=False)
    access_token: str = field(default="", repr=False)
    org_id: str = ""
    company_id: str = ""
    provider: str = "aa"
    token_cache: Path = APP_DIR / ".aa_token_cache.json"
    source: str = "environment"
    deletion_enabled: bool = False

    @classmethod
    def load(cls, provider="aa"):
        if provider != "aa":
            raise AdobeError("This finder supports Adobe Analytics only.")
        prefix = provider.upper()
        explicit = os.environ.get(prefix + "_ENV_FILE") or os.environ.get("SEGMENT_ENV_FILE")
        local = APP_DIR / ".env"
        existing = APP_DIR.parent / ("CJA Segment AnalysisV2" if provider == "cja" else "cja-segment-cleanup-poc") / ".env"
        path = Path(explicit).expanduser().resolve() if explicit else (local if local.is_file() else existing)
        if explicit and not path.is_file():
            raise AdobeError(f"{prefix}_ENV_FILE does not point to an existing configuration file.")
        values = dict(dotenv_values(path)) if path.is_file() else {}
        values.update(os.environ)  # Explicit process settings take precedence.

        def setting(*names):
            return next((str(values[n]).strip() for n in names if values.get(n)), "")

        config = cls(
            client_id=setting(prefix + "_CLIENT_ID", prefix + "_API_KEY", "ADOBE_CLIENT_ID"),
            client_secret=setting(prefix + "_CLIENT_SECRET", "ADOBE_CLIENT_SECRET"),
            scopes=setting(prefix + "_SCOPES", "ADOBE_SCOPES"),
            access_token=setting(prefix + "_ACCESS_TOKEN"),
            org_id=setting(prefix + "_ORG_ID", "ADOBE_ORG_ID"),
            company_id=setting("AA_GLOBAL_COMPANY_ID") if provider == "aa" else "",
            provider=provider,
            token_cache=APP_DIR / ("." + provider + "_token_cache.json"),
            source=str(path) if path.is_file() else "environment",
            deletion_enabled=setting(prefix + "_ENABLE_DELETION") == "1",
        )
        if not config.client_id or not (config.access_token or (config.client_secret and config.scopes)):
            raise AdobeError(f"Configure {prefix}_CLIENT_ID and {prefix}_CLIENT_SECRET + {prefix}_SCOPES (or {prefix}_ACCESS_TOKEN) on the server.")
        if provider == "cja" and not config.org_id:
            raise AdobeError("Configure CJA_ORG_ID on the server.")
        return config


class AdobeAnalyticsClient(SegmentMutationMixin):
    BASE_URL = AA_BASE

    def __init__(self, config, session=None, page_size=100):
        if config.provider != "aa":
            raise AdobeError("Use the CJA finder for CJA requests.")
        self.config = config
        self.session = session or requests.Session()
        self.page_size = page_size
        self.company_id = config.company_id
        self._token = config.access_token
        self._expires = float("inf") if config.access_token else 0
        self._lock = threading.RLock()

    @property
    def cache_identity(self):
        # Fingerprint only; never log or export this or any credential value.
        raw = "|".join([self.config.provider, self.config.client_id, self.config.org_id, self.config.scopes,
                        self.config.client_secret, self.config.access_token, self.config.company_id])
        return hashlib.sha256(raw.encode()).hexdigest()

    def _request(self, method, url, **kwargs):
        # There is deliberately no arbitrary URL or Analytics write interface.
        if not ((method == "GET" and url.startswith(self.BASE_URL + "/")) or
                (method == "POST" and url == IMS_URL)):
            raise AdobeError("This application permits only the selected Adobe provider's reads and IMS authentication.")
        for attempt in range(3):
            try:
                response = self.session.request(method, url, timeout=(10, 45), allow_redirects=False, **kwargs)
            except requests.RequestException:
                if attempt == 2:
                    raise AdobeError("Adobe could not be reached. Check connectivity and retry.") from None
                time.sleep(2 ** attempt)
                continue
            if response.status_code == 429 or 500 <= response.status_code < 600:
                if attempt < 2:
                    try:
                        delay = float(response.headers.get("Retry-After", 2 ** attempt))
                    except (ValueError, TypeError):
                        delay = 2 ** attempt
                    time.sleep(min(10, max(0, delay)) if math.isfinite(delay) else 2 ** attempt)
                    continue
            if not 200 <= response.status_code < 300:
                # Adobe error bodies can contain request or credential details. Do not echo them.
                hint = " Check the API product profile and token permissions." if response.status_code in (401, 403) else ""
                raise AdobeError(f"Adobe returned HTTP {response.status_code}.{hint}")
            try:
                data = response.json()
            except ValueError:
                raise AdobeError("Adobe returned a non-JSON response.") from None
            if isinstance(data, dict) and (data.get("error") or data.get("error_code")):
                raise AdobeError("Adobe returned an API error. Verify server configuration and permissions.")
            return data
        raise AdobeError("Adobe request could not be completed.")

    def token(self, force=False):
        with self._lock:
            if not force and self._token and time.time() < self._expires - 300:
                return self._token
            if self.config.access_token:
                return self.config.access_token
            if not force:
                try:
                    cached = json.loads(self.config.token_cache.read_text())
                    if cached.get("identity") == self.cache_identity and time.time() < cached["expires_at"] - 300:
                        self._token, self._expires = cached["access_token"], cached["expires_at"]
                        return self._token
                except (OSError, ValueError, KeyError, TypeError):
                    pass
            payload = self._request("POST", IMS_URL, data={
                "grant_type": "client_credentials", "client_id": self.config.client_id,
                "client_secret": self.config.client_secret, "scope": self.config.scopes,
            })
            if not isinstance(payload, dict) or not isinstance(payload.get("access_token"), str):
                raise AdobeError("IMS did not return an access token.")
            try:
                lifetime = float(payload.get("expires_in", 0))
                if lifetime > 7 * 86400:  # Some older IMS responses express milliseconds.
                    lifetime /= 1000
                if not math.isfinite(lifetime) or lifetime <= 0:
                    raise ValueError
            except (TypeError, ValueError):
                raise AdobeError("IMS returned an invalid token expiry.") from None
            self._token, self._expires = payload["access_token"], time.time() + lifetime
            # Atomic private token cache. Failure to cache does not fail authentication.
            temporary = None
            try:
                fd, temporary = tempfile.mkstemp(prefix=".aa-token-", dir=self.config.token_cache.parent)
                with os.fdopen(fd, "w") as handle:
                    json.dump({"identity": self.cache_identity, "access_token": self._token,
                               "expires_at": self._expires}, handle)
                os.replace(temporary, self.config.token_cache)
            except OSError:
                pass
            finally:
                if temporary and os.path.exists(temporary):
                    os.unlink(temporary)
            return self._token

    def _headers(self):
        return {"Accept": "application/json", "x-api-key": self.config.client_id,
                "Authorization": "Bearer " + self.token()}

    def _get(self, url, params=None):
        headers = self._headers()
        try:
            return self._request("GET", url, params=params, headers=headers)
        except AdobeError as error:
            if "HTTP 401" not in str(error) or self.config.access_token:
                raise
            headers["Authorization"] = "Bearer " + self.token(force=True)
            return self._request("GET", url, params=params, headers=headers)

    def resolve_company(self):
        with self._lock:
            if self.company_id:
                return self.company_id
            discovery = self._get(AA_BASE + "/discovery/me")
            companies = set()
            for org in discovery.get("imsOrgs", []) if isinstance(discovery, dict) else []:
                if self.config.org_id and org.get("imsOrgId") != self.config.org_id:
                    continue
                companies.update(str(c["globalCompanyId"]) for c in org.get("companies", []) if c.get("globalCompanyId"))
            if len(companies) != 1:
                raise AdobeError("Company selection is missing or ambiguous. Set AA_GLOBAL_COMPANY_ID for the required company.")
            self.company_id = companies.pop()
            return self.company_id

    def get(self, resource, params=None):
        if not resource.startswith(("reportsuites/collections/suites", "segments", "projects")) or ".." in resource:
            raise AdobeError("Unsupported read-only Analytics resource.")
        company = quote(self.resolve_company(), safe="")
        return self._get(f"{AA_BASE}/api/{company}/{resource}", params)

    def paged(self, resource, keys, params=None):
        """Bare-array and Spring-style envelope pagination; never silently truncate."""
        records, seen, page_fingerprints = [], set(), set()
        for page in range(1000):
            payload = self.get(resource, {**(params or {}), "page": page, "limit": self.page_size})
            if isinstance(payload, list):
                items, meta = payload, {}
            elif isinstance(payload, dict):
                items = next((payload[k] for k in ("content", *keys) if isinstance(payload.get(k), list)), None)
                meta = payload
                if items is None:
                    raise AdobeError("Adobe returned an unexpected paginated response.")
            else:
                raise AdobeError("Adobe returned an unexpected paginated response.")
            if any(not isinstance(item, dict) or not (item.get("id") or item.get("rsid")) for item in items):
                raise AdobeError("Adobe returned a record without a usable identifier.")
            fingerprint = tuple(str(i.get("id") or i.get("rsid")) for i in items)
            if items and fingerprint in page_fingerprints:
                raise AdobeError("Adobe repeated a page. Retrieval stopped to avoid reporting incomplete results.")
            page_fingerprints.add(fingerprint)
            for item in items:
                identity = str(item.get("id") or item.get("rsid"))
                if identity not in seen:
                    seen.add(identity)
                    records.append(item)
            total_pages = meta.get("totalPages")
            terminal = meta.get("lastPage") is True or (isinstance(total_pages, int) and page + 1 >= total_pages)
            if not items and not terminal and (meta.get("lastPage") is False or isinstance(total_pages, int) and page + 1 < total_pages):
                raise AdobeError("Adobe returned an empty non-final page. Retrieval is incomplete.")
            if terminal or (not items) or (len(items) < self.page_size and meta.get("lastPage") is not False and total_pages is None):
                total = meta.get("totalElements")
                if isinstance(total, int) and len(records) < total:
                    raise AdobeError("Adobe returned fewer records than its total. Analysis was not run on a partial inventory.")
                return records
        raise AdobeError("Adobe pagination exceeded the safety limit; retrieval is incomplete.")

    def get_report_suites(self):
        suites = self.paged("reportsuites/collections/suites", ("reportSuites", "suites"),
                            {"expansion": "name,currency,timezoneZoneinfo,calendarType,parentRsid"})
        return sorted(({**s, "id": str(s.get("rsid") or s["id"])} for s in suites),
                      key=lambda s: str(s.get("name") or s["id"]).casefold())

    def get_scopes(self):
        return self.get_report_suites()

    def get_segments(self, rsid=None):
        params = {"includeType": "all", "filterByPublishedSegments": "all", "expansion": SEGMENT_EXPANSION}
        if rsid:
            params["rsid"] = rsid  # Adobe Analytics uses singular rsid, not CJA dataviewIds.
        segments = self.paged("segments", ("segments",), params)
        result = []
        for segment in segments:
            if not segment.get("definition") or not segment.get("rsid"):
                try:
                    detail = self.get("segments/" + quote(str(segment["id"]), safe=""), {"expansion": SEGMENT_EXPANSION})
                    if isinstance(detail, dict) and detail.get("id") == segment["id"]:
                        segment = {**segment, **detail}
                except AdobeError:
                    segment = {**segment, "_retrieval_issue": "Definition or parent report suite could not be retrieved."}
            if rsid and segment.get("rsid") and str(segment["rsid"]) != str(rsid):
                continue  # Defensive check if Adobe ignores the query filter.
            if rsid and not segment.get("rsid"):
                segment = {**segment, "_retrieval_issue": "Parent report suite is unknown; excluded from comparison."}
            result.append(segment)
        return result

    def get_projects(self):
        return self.paged("projects", ("projects",), {"includeType": "all", "expansion": PROJECT_EXPANSION})

    def get_project(self, project_id):
        return self.get("projects/" + quote(str(project_id), safe=""), {"expansion": PROJECT_EXPANSION})


def data_view_id(segment):
    values = [segment.get(k) for k in ("rsid", "dataId", "dataID", "data_id")]
    for key in ("dataView", "dataview", "dataSource"):
        value = segment.get(key)
        if isinstance(value, dict):
            values.append(value.get("id"))
    return next((str(value) for value in values if value), "")

from dataclasses import dataclass


# 4. Product/scope labels. This file serves its own product only.
@dataclass(frozen=True)
class Provider:
    id: str
    title: str
    scope_singular: str
    scope_plural: str
    prefix: str


PROVIDER_ID = 'aa'
PROVIDERS = {'aa': Provider('aa', 'Adobe Analytics', 'Report Suite', 'Report Suites', 'AA')}


def get_provider(tool):
    if tool not in PROVIDERS:
        raise ValueError("Please choose CJA or Adobe Analytics.")
    return PROVIDERS[tool]




def normalize_segment(item, tool, scope_names):
    """Add internal scope metadata without rewriting the original definition."""
    get_provider(tool)
    segment = dict(item)
    scope_id = data_view_id(item) if tool == "cja" else str(item.get("rsid") or "")
    name = item.get("reportSuiteName")
    if tool == "cja":
        name = item.get("dataName") or item.get("dataViewName") or name
        for key in ("dataView", "dataview"):
            nested = item.get(key)
            if not name and isinstance(nested, dict):
                name = nested.get("name")
    segment.update({"_provider": tool, "_scope_id": scope_id,
                    "_scope_name": str(name or scope_names.get(scope_id) or scope_id or "Unknown scope")})
    return segment


def make_client(tool=PROVIDER_ID):
    get_provider(tool)
    return AdobeAnalyticsClient(Config.load(tool))


from collections import defaultdict
from html import escape as esc
from itertools import combinations
from pathlib import Path
import csv
import json
import math
import os



# 5. Validated definition comparison, grouping, Workspace usage and CSV export.
def json_key(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def predicate_sort_key(value):
    """Keep rules on the same component aligned when only literals change."""
    references = []

    def walk(item):
        if isinstance(item, dict):
            if item.get("func") in ("attr", "event") and isinstance(item.get("name"), str):
                references.append((item["func"], item["name"]))
            for child in item.values():
                walk(child)
        elif isinstance(item, list):
            for child in item:
                walk(child)
    walk(value)
    return (tuple(sorted(references)), json_key(value))


def canonicalize(value):
    if isinstance(value, list):
        return [canonicalize(item) for item in value]
    if not isinstance(value, dict):
        return value
    result = {key: canonicalize(value[key]) for key in sorted(value)}
    # Only ordinary boolean AND/OR predicate order is normalised. All sequence
    # streams, checkpoints, versions, and other arrays retain order/multiplicity.
    if result.get("func") in ("and", "or") and isinstance(result.get("preds"), list):
        result["preds"] = sorted(result["preds"], key=predicate_sort_key)
    return result


def get_scope_id(segment):
    return str(segment.get("_scope_id") or segment.get("rsid") or segment.get("dataId") or "")


def get_scope_name(segment):
    return str(segment.get("_scope_name") or segment.get("reportSuiteName") or segment.get("dataName") or get_scope_id(segment) or "Unknown scope")


def provider_scope_key(segment):
    return (segment.get("_provider", "aa"), get_scope_id(segment))


def get_owner_name(segment):
    owner = segment.get("owner")
    owner_info = owner if isinstance(owner, dict) else {}
    created_by = segment.get("createdBy")
    created_name = (created_by.get("name") or created_by.get("displayName")) if isinstance(created_by, dict) else created_by
    user = segment.get("user")
    user = user if isinstance(user, dict) else {}
    owner_id = owner_info.get("id") or owner_info.get("ownerId")
    return str(owner_info.get("fullName") or owner_info.get("name") or owner_info.get("displayName")
               or owner_info.get("login") or segment.get("ownerFullName") or segment.get("ownerName")
               or (owner if isinstance(owner, str) else None) or created_name or user.get("name")
               or user.get("displayName") or (f"Owner ID: {owner_id}" if owner_id else "-"))


def definition_issue(segment):
    if segment.get("_retrieval_issue"):
        return segment["_retrieval_issue"]
    if not segment.get("id") or not get_scope_id(segment):
        return "Segment ID or scope is missing."
    definition = segment.get("definition")
    if not isinstance(definition, dict) or not definition:
        return "Definition is missing or is not a JSON object."
    container = definition.get("container")
    is_cja = segment.get("_provider") == "cja"
    allowed_root = ("segment", "segment-def") if is_cja else ("segment",)
    allowed_container = ("container", "segment") if is_cja else ("container",)
    if definition.get("func") not in allowed_root or not isinstance(container, dict) or not container:
        return "Definition does not contain an Adobe segment/container structure."
    if container.get("func") not in allowed_container or container.get("context") not in ("hits", "visits", "visitors"):
        return "Container context is missing or unsupported."
    pred = container.get("pred")
    if not isinstance(pred, dict) or not pred.get("func"):
        return "Container predicate is missing."
    if pred.get("func") in ("and", "or") and not pred.get("preds"):
        return "Boolean predicate has no rules."
    try:
        json_key(definition)
    except (ValueError, TypeError, RecursionError):
        return "Definition is not valid finite JSON."
    return ""


def prepare_segments(segments):
    prepared = []
    for original in segments:
        segment = dict(original)
        if isinstance(segment.get("definition"), str):
            try:
                segment["definition"] = json.loads(segment["definition"])
            except (ValueError, TypeError):
                pass
        segment["_analysis_issue"] = definition_issue(segment)
        prepared.append(segment)
    return prepared


def normalized_definition(segment):
    return None if definition_issue(segment) else json_key(canonicalize(segment["definition"]))


def flatten_to_path_tokens(value, path, tokens):
    if isinstance(value, dict):
        if not value:
            tokens.add(path + "={}")
        for key, item in value.items():
            flatten_to_path_tokens(item, path + "/" + key.replace("~", "~0").replace("/", "~1"), tokens)
    elif isinstance(value, list):
        if not value:
            tokens.add(path + "=[]")
        for index, item in enumerate(value):
            # Array positions bind each value to its own predicate and sequence step.
            flatten_to_path_tokens(item, f"{path}/{index}", tokens)
    else:
        tokens.add(path + "=" + json_key(value))  # true, 1, "1", null stay distinct.


def tokenize(segment):
    if definition_issue(segment):
        return set()
    tokens = set()
    flatten_to_path_tokens(canonicalize(segment["definition"]), "", tokens)
    return tokens


def similarity_from_tokens(a, b):
    return 100 * len(a & b) / len(a | b) if a or b else 0.0


def differences_from_tokens(a, b):
    return {"onlyA": sorted(a - b), "onlyB": sorted(b - a)}


def validate_threshold(threshold):
    try:
        threshold = float(threshold)
        if not math.isfinite(threshold) or not 1 <= threshold <= 100:
            raise ValueError
        return threshold
    except (ValueError, TypeError):
        raise ValueError("Similarity threshold must be a finite number between 1 and 100.") from None


def find_duplicate_segments(segments, threshold=85, verbose=False):
    threshold = validate_threshold(threshold)
    prepared = [(s, normalized_definition(s), tokenize(s)) for s in segments]
    exact_groups, inverted = defaultdict(list), defaultdict(set)
    for index, (segment, norm, tokens) in enumerate(prepared):
        if norm is None:
            continue
        scope = provider_scope_key(segment)
        exact_groups[(scope, norm)].append(index)
        for token in tokens:
            inverted[(scope, token)].add(index)
    matches, exact_pairs = [], set()

    def match(i, j, kind, score):
        a, _, a_tokens = prepared[i]
        b, _, b_tokens = prepared[j]
        return {"type": kind, "similarity": score, "a": a, "b": b,
                "diff": differences_from_tokens(a_tokens, b_tokens)}

    for group in exact_groups.values():
        for i, j in combinations(group, 2):
            exact_pairs.add((i, j))
            matches.append(match(i, j, "Exact duplicate", 100.0))
    for i, (segment, norm, tokens) in enumerate(prepared):
        if norm is None:
            continue
        candidates = set()
        for token in tokens:
            candidates.update(inverted[(provider_scope_key(segment), token)])
        for j in sorted(candidates):
            if j <= i or (i, j) in exact_pairs:
                continue
            other = prepared[j][2]
            if 100 * min(len(tokens), len(other)) / max(len(tokens), len(other)) < threshold:
                continue
            score = similarity_from_tokens(tokens, other)
            if score >= threshold:
                matches.append(match(i, j, "Near duplicate", score))
    return sorted(matches, key=lambda m: (-m["similarity"], str(m["a"]["id"]), str(m["b"]["id"])))


def get_match_segment_key(segment):
    return (*provider_scope_key(segment), str(segment.get("id") or ""))


def count_distinct_segments_in_matches(matches, match_type):
    return len({get_match_segment_key(m[side]) for m in matches if m["type"] == match_type for side in ("a", "b")})


def count_unique_segments(segments, matches):
    matched = {get_match_segment_key(m[side]) for m in matches for side in ("a", "b")}
    return sum(not definition_issue(s) and get_match_segment_key(s) not in matched for s in segments)


def build_duplicate_groups(matches, match_type):
    parent, by_key = {}, {}

    def find(key):
        while parent[key] != key:
            parent[key] = parent[parent[key]]
            key = parent[key]
        return key

    for match in matches:
        if match["type"] != match_type:
            continue
        keys = []
        for side in ("a", "b"):
            segment = match[side]
            key = get_match_segment_key(segment)
            parent.setdefault(key, key)
            by_key[key] = segment
            keys.append(key)
        parent[find(keys[0])] = find(keys[1])
    groups = defaultdict(list)
    for key, segment in by_key.items():
        groups[find(key)].append(segment)
    return sorted(groups.values(), key=lambda group: (-len(group), str(group[0].get("id"))))


def collect_segment_ids_from_project(project, known_ids):
    found = set()

    def walk(value):
        if isinstance(value, str) and value in known_ids:
            found.add(value)
        elif isinstance(value, dict):
            for child in value.values():
                walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)
    for key in ("externalReferences", "definition"):
        value = project.get(key)
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except ValueError:
                pass
        walk(value)
    return found


def load_workspace_usage(segments, client, verbose=False):
    """Visible Workspace projects only; absence is never proof of global non-use."""
    known = {str(s["id"]) for s in segments}
    usage, complete = {}, True
    try:
        projects = client.get_projects()
        for project in projects:
            if not any(isinstance(project.get(k), (dict, list)) for k in ("externalReferences", "definition")):
                try:
                    detail = client.get_project(project["id"])
                    if isinstance(detail, dict) and detail.get("id") == project["id"]:
                        project = {**project, **detail}
                except AdobeError:
                    complete = False
            if not any(isinstance(project.get(k), (dict, list)) for k in ("externalReferences", "definition")):
                complete = False
                continue
            shared = bool(project.get("shares"))  # Never infer publishing from approval/curation.
            for segment_id in collect_segment_ids_from_project(project, known):
                item = usage.setdefault(segment_id, {"count": 0, "sharedPublishedCount": 0, "projectNames": [], "sharedPublishedProjectNames": []})
                item["count"] += 1
                item["sharedPublishedCount"] += int(shared)
                item["projectNames"].append(str(project.get("name") or project["id"]))
                if shared:
                    item["sharedPublishedProjectNames"].append(str(project.get("name") or project["id"]))
    except AdobeError:
        complete = False
    return usage, complete


def get_segment_usage(usage_map, segment):
    return usage_map.get(str(segment.get("id")), {"count": 0, "sharedPublishedCount": 0,
                                                "projectNames": [], "sharedPublishedProjectNames": []})


def is_protected(segment):
    tags = segment.get("tags") or []
    approved = segment.get("approved") is True or any(
        (isinstance(t, dict) and str(t.get("name", "")).lower() == "approved") or
        (isinstance(t, str) and t.lower() == "approved") for t in tags)
    publishing = segment.get("publishingStatus")
    published = (publishing is True or
                 isinstance(publishing, str) and publishing.lower() not in ("", "false", "notpublished", "not_published", "unpublished", "none") or
                 isinstance(publishing, dict) and bool(publishing) and publishing.get("published") is not False)
    return bool(approved or published)


def get_deletion_recommendation(match, usage_map, usage_loaded):
    used = [side.upper() for side in ("a", "b") if get_segment_usage(usage_map, match[side])["count"]]
    protected = [side.upper() for side in ("a", "b") if is_protected(match[side])]
    if used or protected:
        text = "Do not delete — " + ("in use: " + ", ".join(used) if used else "approved/published or protected")
    elif not usage_loaded:
        text = "Unable to verify — Workspace usage incomplete"
    elif match["type"] == "Exact duplicate":
        text = "Review consolidation — no references in accessible projects"
    else:
        text = "Review business rules — similarity is not equivalence"
    return {"text": text, "detail": (
        "Check owner approval and dependencies outside accessible Workspace projects before consolidation. "
        "Near matches need business-rule review. Deletion is disabled by default and requires a separate guarded workflow."
    )}


def get_recommendation_bucket(text):
    return "keep" if text.startswith("Do not delete") else "unknown" if text.startswith("Unable") else "review"


def get_group_deletion_recommendation(group_segments, is_exact, usage_map, usage_loaded):
    if any(is_protected(s) or get_segment_usage(usage_map, s)["count"] for s in group_segments):
        return {"text": "Do not delete used/approved/published segments. Review each pair and owner impact.", "class_name": "recommend-keep"}
    if not usage_loaded:
        return {"text": "Unable to verify — Workspace usage incomplete. Owner/dependency review required.", "class_name": "recommend-review"}
    return {"text": ("Review consolidation; retain a suitable canonical segment after owner approval. " if is_exact else
                     "Review each linked pair; not every member is similar to every other member. ") +
                    "No references found in accessible projects is not proof of global non-use.", "class_name": "recommend-review"}


def render_duplicate_group_rows(groups, is_exact, usage_map, usage_loaded):
    if not groups:
        return '<tr><td colspan="6"><span class="badge strong">No ' + ("exact-duplicate" if is_exact else "near-duplicate") + ' groups found.</span></td></tr>'
    rows = []
    for index, group in enumerate(groups, 1):
        names = "".join(f'<span class="group-segment-name">{esc(str(s.get("name") or "(No name)"))}</span>' for s in group)
        suites = "".join(f'<span class="group-segment-name">{esc(name)}</span>' for name in sorted({get_scope_name(s) for s in group}))
        rec = get_group_deletion_recommendation(group, is_exact, usage_map, usage_loaded)
        approval = "".join(f'<span class="group-segment-name">{esc(approval_status(s))}</span>' for s in group)
        usage = "".join(f'<span class="group-segment-name">{get_segment_usage(usage_map, s)["count"] if usage_loaded or get_segment_usage(usage_map, s)["count"] else "Unknown"}</span>' for s in group)
        rows.append(f'<tr><td>{index}</td><td>{names}</td><td>{suites}</td><td>{approval}</td><td>{usage}</td><td><span class="{rec["class_name"]}">{esc(rec["text"])}</span></td></tr>')
    return "".join(rows)


def spreadsheet_safe(value):
    text = str(value or "")
    return "'" + text if text.lstrip().startswith(("=", "+", "-", "@", "\t", "\r")) else text


def export_segment_csv(segments, path, tool="aa"):
    provider = get_provider(tool)
    with open(path, "w", encoding="utf-8-sig", newline="") as handle:
        os.chmod(path, 0o600)
        writer = csv.writer(handle)
        writer.writerow(["#", "Segment Name", "Segment ID", provider.scope_singular + " Name", provider.scope_singular + " ID", "Owner", "Description", "Definition (JSON)", "Analysis status", "Approved Status"])
        for index, segment in enumerate(segments, 1):
            values = [index, segment.get("name", ""), segment.get("id", ""), get_scope_name(segment), get_scope_id(segment),
                      get_owner_name(segment), segment.get("description", ""), json.dumps(segment.get("definition"), ensure_ascii=False),
                      definition_issue(segment) or "Assessed", approval_status(segment)]
            writer.writerow([spreadsheet_safe(v) for v in values])


def run_pipeline(client, threshold=85, output_dir=None, scope_selection="ALL", segments=None, scopes=None, tool="aa"):

    threshold = validate_threshold(threshold)
    provider = get_provider(tool)
    scopes = scopes if scopes is not None else client.get_scopes()
    selected = next((s for s in scopes if str(s["id"]) == str(scope_selection)), None)
    if str(scope_selection).upper() != "ALL" and selected is None:
        raise ValueError(f"Please select an accessible {provider.scope_singular}.")
    selected_id = str((selected.get("parentRsid") if tool == "aa" else None) or selected["id"]) if selected else None
    scope = str(selected.get("name") or selected["id"]) if selected else f"All {provider.scope_plural} (compared within each scope)"
    if tool == "aa" and selected and selected.get("parentRsid") and selected["parentRsid"] != selected["id"]:
        scope += " — parent-suite definitions; VRS population filters are not evaluated"
    raw = segments if segments is not None else client.get_segments(selected_id)
    names = {str(s["id"]): str(s.get("name") or s["id"]) for s in scopes}
    normal = [normalize_segment(s, tool, names) for s in raw]
    normal = [s for s in normal if not selected_id or not get_scope_id(s) or get_scope_id(s) == selected_id]
    segments = prepare_segments(normal)
    usage, usage_loaded = load_workspace_usage(segments, client) if segments else ({}, False)
    matches = find_duplicate_segments(segments, threshold)
    directory = Path(output_dir) if output_dir else Path(__file__).resolve().parent / "output" / "reports" / tool
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    csv_path, html_path = directory / f"{provider.prefix}_Segment_List.csv", directory / f"{provider.prefix}_Segment_Cleanup_Dashboard.html"
    export_segment_csv(segments, csv_path, tool)
    html = build_dashboard_html(segments, matches, usage, usage_loaded, threshold, csv_path.name, scope, tool=tool)
    html_path.write_text(html, encoding="utf-8")
    os.chmod(html_path, 0o600)
    summary = {"segment_count": len(segments), "assessed_count": sum(not definition_issue(s) for s in segments),
               "unassessed_count": sum(bool(definition_issue(s)) for s in segments), "match_count": len(matches),
               "exact_count": sum(m["type"] == "Exact duplicate" for m in matches),
               "near_count": sum(m["type"] == "Near duplicate" for m in matches),
               "unique_count": count_unique_segments(segments, matches), "usage_loaded": usage_loaded,
               "tool": tool, "scope": scope, "threshold": threshold}
    return {**summary, "segments": segments, "matches": matches, "usage_map": usage,
            "segment_csv_path": str(csv_path), "dashboard_html_path": str(html_path), "dashboard_html": html}


from collections import Counter
from html import escape
import json

STYLE = '''<style>
.approval-summary {display:flex;gap:16px;flex-wrap:wrap;margin:18px 0}
.approval-metric {padding:12px 18px;border:1px solid #d9e2ef;border-radius:8px;background:white;min-width:160px}
.approval-value {font-size:23px;font-weight:700;display:block;margin-top:5px}
#cleanupPanel input[type=checkbox],#cleanupDialog input[type=checkbox] {width:18px;height:18px;vertical-align:middle}
#cleanupPanel .cleanup-tools {display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:14px 0}
#cleanupPanel input[type=search] {padding:9px;min-width:260px;flex:1;border:1px solid #cbd5e1;border-radius:5px}
#cleanupPanel select {padding:8px;width:auto} #cleanupPanel button {padding:9px 12px;border:0;border-radius:5px;cursor:pointer}
#cleanupPanel .danger,#cleanupDialog .danger {background:#b42318;color:white}
#cleanupPanel button:disabled,#cleanupDialog button:disabled {opacity:.45;cursor:not-allowed}
#cleanupBody td {vertical-align:top;overflow-wrap:anywhere} #cleanupBody td:first-child {width:45px}
#cleanupDialog {width:min(760px,90vw);max-height:85vh;overflow:auto;border:1px solid #cbd5e1;border-radius:10px;padding:24px;color:#1d2939}
#cleanupDialog::backdrop {background:rgba(15,23,42,.45)} #cleanupDialog input[type=text] {padding:8px;width:150px;margin:8px}
#cleanupDialog .cleanup-preview {max-height:230px;overflow:auto;margin:12px 0} #cleanupDialog button {padding:10px 16px;margin:8px;border:0;border-radius:5px;cursor:pointer}
#cleanupMessage {white-space:pre-wrap;margin:12px 0;padding:10px;border:1px solid #d8e0ea;border-radius:6px}
[hidden] {display:none!important}
</style>'''

SCRIPT = r'''<script>
(() => {
 const data=CLEANUP_DATA, context=/*CLEANUP_CONTEXT*/null;
 const selected=new Set(); let filtered=data.slice(),page=1,size=10,plan=null,busy=false;
 const $=id=>document.getElementById(id), message=$('cleanupMessage'), dialog=$('cleanupDialog');
 const note='Owner approval and dependencies outside accessible Workspace projects must be checked. A similarity score is not permission to delete.';
 function text(tag,value) {const e=document.createElement(tag);e.textContent=String(value??'');return e;}
 function status(value) {message.textContent=value;message.hidden=false;}
 function render() {
   const query=$('cleanupSearch').value.trim().toLocaleLowerCase();
   filtered=data.filter(s=>(s.name+' '+s.id+' '+s.reason).toLocaleLowerCase().includes(query));
   page=Math.max(1,Math.min(page,Math.max(1,Math.ceil(filtered.length/size))));
   const rows=filtered.slice((page-1)*size,page*size), body=$('cleanupBody');body.replaceChildren();
   for(const s of rows) {
     const tr=document.createElement('tr'), check=text('td',''), box=document.createElement('input');
     box.type='checkbox';box.checked=selected.has(s.id);box.disabled=Boolean(s.reason)||busy||!context;
     box.setAttribute('aria-label','Select segment '+s.name);box.addEventListener('change',()=>{box.checked?selected.add(s.id):selected.delete(s.id);render();});check.append(box);tr.append(check);
     const name=text('td',s.name);name.append(text('div',s.id));tr.append(name);
     for(const value of [s.scope,s.owner,s.approval,s.usage,s.reason||'Ready for fresh preflight'])tr.append(text('td',value));
     const action=text('td',''),button=text('button','Delete');button.type='button';button.className='danger';button.disabled=Boolean(s.reason)||busy||!context;
     button.setAttribute('aria-label','Review deletion of '+s.name);button.addEventListener('click',()=>preview([s.id]));action.append(button);tr.append(action);body.append(tr);
   }
   if(!rows.length){const tr=document.createElement('tr'),td=text('td','No segments match this search.');td.colSpan=8;tr.append(td);body.append(tr);}
   $('cleanupPagination').textContent=`Page ${page} of ${Math.max(1,Math.ceil(filtered.length/size))} — ${filtered.length} rows`;
   $('cleanupSelection').textContent=selected.size+' selected';$('cleanupPreview').disabled=busy||!selected.size||!context;
   $('cleanupPrevious').disabled=page===1||busy;$('cleanupNext').disabled=page*size>=filtered.length||busy;
 }
 async function request(path,payload) {
   if(!context)throw new Error('This is an offline report. Generate a fresh report in the running application.');
   const response=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-Cleanup-Token':context.token},body:JSON.stringify({tool:context.tool,...payload})});
   const value=await response.json();if(!response.ok)throw new Error(value.error||'Server could not complete cleanup.');return value;
 }
 async function preview(ids) {
   if(busy)return;if(ids.length>200){status('Select at most 200 segments per operation. Nothing was deleted.');return;}
   busy=true;render();status('Checking current definitions, approval, publishing and accessible Workspace usage...');
   try {
     plan=await request('/api/segments/delete-preview',{ids});$('cleanupPreviewList').replaceChildren();
     for(const row of plan.results)$('cleanupPreviewList').append(text('p',row.name+' ['+row.id+']: '+row.reason));
     $('cleanupType').value='';$('cleanupOwner').checked=false;
     $('cleanupConfirm').disabled=true;
     $('cleanupMode').textContent=plan.enabled?'Live deletion is enabled for this provider.':'Live deletion is DISABLED. This preview performs reads only.';
     dialog.showModal();$('cleanupCancel').focus();status('Preview complete. No segments have been deleted.');
   }catch(error){status(error.message);}finally{busy=false;render();}
 }
 function confirmation(){ $('cleanupConfirm').disabled=busy||!plan?.enabled||!plan.ids.length||$('cleanupType').value!=='DELETE'||!$('cleanupOwner').checked; }
 $('cleanupSearch').addEventListener('input',()=>{page=1;render();});
 $('cleanupPageSize').addEventListener('change',()=>{size=Number($('cleanupPageSize').value);page=1;render();});
 $('cleanupPrevious').addEventListener('click',()=>{page--;render();});$('cleanupNext').addEventListener('click',()=>{page++;render();});
 function choose(rows){const ids=rows.filter(s=>!s.reason).map(s=>s.id);if(new Set([...selected,...ids]).size>200){status('Selection would exceed 200. Narrow the search or select a page.');return;}ids.forEach(id=>selected.add(id));render();}
 $('cleanupSelectPage').addEventListener('click',()=>choose(filtered.slice((page-1)*size,page*size)));
 $('cleanupSelectFiltered').addEventListener('click',()=>choose(filtered));$('cleanupClearSelection').addEventListener('click',()=>{selected.clear();render();});
 $('cleanupClearSearch').addEventListener('click',()=>{$('cleanupSearch').value='';page=1;render();});
 $('cleanupPreview').addEventListener('click',()=>preview([...selected]));
 $('cleanupType').addEventListener('input',confirmation);$('cleanupOwner').addEventListener('change',confirmation);
 $('cleanupCancel').addEventListener('click',()=>{if(!busy){dialog.close();plan=null;}});
 dialog.addEventListener('cancel',event=>{if(busy)event.preventDefault();});
 $('cleanupConfirm').addEventListener('click',async()=>{
   if($('cleanupConfirm').disabled)return;busy=true;confirmation();$('cleanupCancel').disabled=true;
   try {
     const result=await request('/api/segments/delete',{ids:plan.ids,plan:plan.plan,confirmation:$('cleanupType').value,owner_review_confirmed:$('cleanupOwner').checked});
     const note=result.results.map(r=>r.name+': '+r.status+(r.error?' — '+r.error:'')).join('\n');
     status(note);dialog.close();plan=null;
     if(result.refresh_required){try{sessionStorage.setItem('cleanup-result-'+context.tool,JSON.stringify({message:note,time:Date.now()}));}catch(e){}window.location.assign(context.refresh);}
   }catch(error){status(error.message+' Refresh the report and verify Adobe before retrying.');dialog.close();plan=null;}
   finally{busy=false;$('cleanupCancel').disabled=false;render();}
 });
 $('cleanupNote').textContent=note+(context?(context.enabled?' Live writes are enabled for this provider.':' Live writes are disabled; preview only.'):' Offline report: deletion controls are inactive.');
 if(context){try{const key='cleanup-result-'+context.tool,prior=JSON.parse(sessionStorage.getItem(key)||'null');sessionStorage.removeItem(key);if(prior&&Date.now()-prior.time<120000)status(prior.message);}catch(e){}}
 render();
})();
</script>'''


def json_safe(value):
    return json.dumps(value, ensure_ascii=False).replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')


# 6. Embedded report controls. Static exports never contain a live cleanup token.
def augment_report(html, segments, usage_map, usage_loaded, scope_fn, owner_fn, issue_fn):
    counts=Counter(approval_status(s) for s in segments)
    summary='<div class="approval-summary" aria-label="Approval summary">'+''.join(
        '<div class="approval-metric">'+escape(label)+'<span class="approval-value">'+str(counts[label])+'</span></div>'
        for label in ('Approved','Not Approved','Unknown'))+'</div><p class="note">Approval is reported only when explicit metadata is available. Unknown is not Not Approved.</p>'
    rows=[{'id':str(s['id']), 'name':str(s.get('name') or s['id']), 'scope':scope_fn(s), 'owner':owner_fn(s),
           'approval':approval_status(s), 'usage':usage_map.get(str(s['id']),{}).get('count',0) if usage_loaded else 'Unknown',
           'reason':deletion_block_reason(s,usage_map,usage_loaded,issue_fn(s))} for s in segments]
    panel='''<section class="section" id="cleanupPanel">
<details><summary><h2 style="display:inline">Segment Deletion</h2></summary>
<p class="note" id="cleanupNote"></p><p class="note">The list includes blocked rows so the reason is visible. Only explicitly Not Approved, confirmed unpublished, assessable segments with no accessible references can reach preflight. Retain one exact copy. Maximum 200 per operation.</p>
<div id="cleanupMessage" role="status" aria-live="polite" hidden></div>
<div class="cleanup-tools"><input type="search" id="cleanupSearch" aria-label="Search cleanup segments" placeholder="Search by name, ID or blocking reason"><button id="cleanupClearSearch">Clear Search</button><label for="cleanupPageSize">Rows per page</label><select id="cleanupPageSize"><option>10</option><option>20</option><option>50</option><option>100</option></select></div>
<div class="cleanup-tools"><button id="cleanupSelectPage">Select Page</button><button id="cleanupSelectFiltered">Select All Filtered</button><button id="cleanupClearSelection">Clear Selection</button><span id="cleanupSelection"></span><button id="cleanupPreview">Preview Selected</button></div>
<div class="table-wrap"><table><thead><tr><th>Select</th><th>Segment and ID</th><th>Scope ID</th><th>Owner</th><th>Approval</th><th>Workspace references</th><th>Preflight status</th><th>Action</th></tr></thead><tbody id="cleanupBody"></tbody></table></div>
<div class="cleanup-tools"><button id="cleanupPrevious">Previous</button><span id="cleanupPagination"></span><button id="cleanupNext">Next</button></div>
</details></section>
<dialog id="cleanupDialog" aria-labelledby="cleanupDialogTitle"><h2 id="cleanupDialogTitle">Review segment deletion</h2><p id="cleanupMode"></p><p>Blocked rows will not be sent for deletion. Review the exact IDs below. Deletion affects availability in Adobe; do not assume it can be undone.</p><div class="cleanup-preview" id="cleanupPreviewList"></div><p><label><input type="checkbox" id="cleanupOwner"> I confirm owner approval and have checked dependencies outside accessible Workspace projects.</label></p><p><label for="cleanupType">Type DELETE to confirm</label><input id="cleanupType" type="text" autocomplete="off" spellcheck="false"></p><button id="cleanupCancel">Cancel</button><button class="danger" id="cleanupConfirm" disabled>Delete Confirmed Segments</button></dialog>'''
    html=html.replace('</head>',STYLE+'</head>',1)
    html=html.replace('    <p class="note">Not assessed:',summary+'    <p class="note">Not assessed:',1)
    html=html.replace('  <div class="section">\n    <h2 class="card-header-row"',panel+'\n  <div class="section">\n    <h2 class="card-header-row"',1)
    script=SCRIPT.replace('CLEANUP_DATA',json_safe(rows),1)
    return html.replace('</body>',script+'</body>',1)


def bind_live(html, token, tool, enabled, refresh):
    return html.replace('/*CLEANUP_CONTEXT*/null',json_safe({'token':token,'tool':tool,'enabled':enabled,'refresh':refresh}),1)


import json
from datetime import datetime
from html import escape as esc

REC_CLASS_BY_BUCKET = {
    "cleanup": "recommend-delete",
    "review": "recommend-review",
    "keep": "recommend-keep",
    "unknown": "recommend-review",
}

# A near-duplicate pair can differ by hundreds of tokens. The table shows the
# first N so a row stays readable; the Excel export always carries the full
# list for anyone who needs to audit the whole difference.
DIFF_DISPLAY_LIMIT = 30

DASHBOARD_CSS = """
:root {
  --bg:#f4f7fb; --card:#fff; --text:#172033; --muted:#687386;
  --border:#dfe5ee; --accent:#315efb; --green:#137a4b;
  --greenbg:#e8f7ef; --amber:#996c00; --amberbg:#fff5d9;
  --blue:#1e5bd6; --bluebg:#eaf1ff;
}
* { box-sizing:border-box; }
body { margin:0; font-family:Segoe UI,Arial,sans-serif; background:var(--bg); color:var(--text); }
.container { max-width:1500px; margin:0 auto; padding:32px; }
.header { margin-bottom:24px; }
h1 { margin:0 0 8px; font-size:28px; }
.subtitle { color:var(--muted); font-size:15px; }
.meta { margin-top:10px; color:var(--muted); font-size:13px; }
.toolbar { display:flex; gap:12px; flex-wrap:wrap; margin-top:18px; }
.toolbar button {
  display:inline-flex; align-items:center; gap:6px;
  background:var(--accent); color:#fff; border:0; cursor:pointer;
  font-family:inherit; padding:10px 16px; border-radius:8px; font-size:13px; font-weight:600;
}
.toolbar button.secondary { background:var(--green); }
.toolbar a.change-view {
  display:inline-flex; align-items:center; gap:6px; text-decoration:none;
  background:#5a6575; color:#fff; padding:10px 16px; border-radius:8px;
  font-size:13px; font-weight:600;
}
.toolbar button:hover { opacity:.9; }
.toolbar a.change-view:hover { opacity:.9; }
.cards { display:flex; flex-wrap:wrap; gap:16px; margin:24px 0; }
.card { background:var(--card); border:1px solid var(--border); border-radius:14px; padding:18px; box-shadow:0 2px 8px rgba(30,50,80,.04); flex:1 1 190px; }
.card .label { color:var(--muted); font-size:12.5px; }
.card .value { font-size:27px; font-weight:700; margin-top:6px; }
.card .value.exact-value { color:#c62828; }
.card .value.near-value { color:#ef6c00; }
.card .value.unique-value { color:#137a4b; }
.section { background:var(--card); border:1px solid var(--border); border-radius:14px; padding:22px; margin-top:20px; }
.section h2 { margin:0 0 15px; font-size:20px; }
.section.highlight { background:#fbfcfe; border:1px solid var(--border); }
.table-wrap { overflow-x:auto; }
table { width:100%; border-collapse:collapse; font-size:13px; }
th { text-align:left; background:#f7f9fc; color:#4d586a; padding:12px; border-bottom:2px solid var(--border); white-space:nowrap; }
td { padding:14px 12px; border-bottom:1px solid var(--border); vertical-align:top; line-height:1.45; }
.muted { color:var(--muted); font-size:11px; word-break:break-all; }
.score { font-weight:700; font-size:16px; }
.badge { display:inline-block; padding:6px 9px; border-radius:999px; font-size:11px; font-weight:700; white-space:nowrap; }
.badge.strong { background:var(--greenbg); color:var(--green); }
.badge.review { background:var(--amberbg); color:var(--amber); }
.badge.keep { background:var(--bluebg); color:var(--blue); }
.badge.exact { background:#fdecec; color:#c62828; }
.badge.near { background:#fff3e0; color:#ef6c00; }
.usage-badge { display:inline-block; padding:3px 8px; margin:2px 0; border-radius:6px; background:#f1f4f9; color:#3c4658; font-size:11.5px; }
.usage-note { color:var(--muted); font-size:11.5px; margin-top:6px; }
.empty { padding:30px; text-align:center; color:var(--muted); background:#f8fafc; border-radius:10px; }
.note { color:var(--muted); font-size:13px; line-height:1.6; }
.duplicate-groups-section { margin-top:4px; }
.duplicate-groups-section h3 { margin-bottom:4px; margin-top:22px; }
.group-subtitle { color:var(--muted); font-size:13px; margin-bottom:6px; }
.group-table td { vertical-align:top; }
.group-segment-name { display:block; padding:2px 0; }
.recommend-delete { color:#c62828; font-weight:700; }
.recommend-keep { color:#2e7d32; font-weight:700; }
.recommend-review { color:#ef6c00; font-weight:700; }

/* Collapsible section headers */
h2.card-header-row { display:flex; align-items:center; justify-content:space-between; gap:10px; cursor:pointer; user-select:none; }
h2.card-header-row:hover { color:var(--accent); }
.collapse-toggle { font-size:12.5px; font-weight:600; color:#4d586a; border:1px solid var(--border); border-radius:6px; padding:3px 10px; background:#f7f9fc; white-space:nowrap; }
.collapsible-body.collapsed { display:none; }

/* Per-section toolbar: search, rows-per-page, actions */
.table-toolbar { display:flex; align-items:flex-end; justify-content:space-between; gap:14px; flex-wrap:wrap; margin-bottom:14px; }
.search-box { flex:1 1 340px; }
.search-box input { width:100%; padding:9px 12px; border:1px solid var(--border); border-radius:8px; font-size:13px; font-family:inherit; }
.page-size-control { display:flex; align-items:center; gap:8px; }
.page-size-control label { font-size:12.5px; color:var(--muted); white-space:nowrap; }
.page-size-control select { padding:9px 10px; border:1px solid var(--border); border-radius:8px; font-size:13px; font-family:inherit; background:#fff; }
.btn { border:0; cursor:pointer; font-family:inherit; font-size:12.5px; font-weight:600; padding:9px 14px; border-radius:8px; color:#fff; background:var(--accent); }
.btn:hover { opacity:.9; }
.btn.grey { background:#5a6575; }
.btn.green { background:var(--green); }

/* Numbered pagination */
.pagination { display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; margin-top:14px; }
.pagination-info { color:var(--muted); font-size:12.5px; }
.pagination-buttons { display:flex; gap:5px; flex-wrap:wrap; }
.pagination-buttons button { background:#fff; border:1px solid var(--border); color:var(--text); padding:7px 12px; border-radius:7px; font-size:12.5px; font-family:inherit; cursor:pointer; }
.pagination-buttons button:hover:not(:disabled) { background:#f0f4fb; }
.pagination-buttons button.active { background:var(--accent); border-color:var(--accent); color:#fff; }
.pagination-buttons button:disabled { color:#b7bfcc; cursor:not-allowed; }

/* Long segment names / difference lists wrap instead of forcing the wide
   tables into a horizontal scrollbar. */
table.fixed { table-layout:fixed; }
table.fixed th, table.fixed td { white-space:normal; overflow-wrap:anywhere; word-break:break-word; }

@media(max-width:1100px) {
  .card { flex-basis:45%; }
}
@media(max-width:600px) {
  .container { padding:16px; }
  .card { flex-basis:100%; }
  table.fixed th, table.fixed td { padding:8px 6px; font-size:12px; }
}
"""

DASHBOARD_JS = """
// --- Shared helpers -------------------------------------------------

function escapeHtmlJs(value) {
    const div = document.createElement("div");
    div.textContent = String(value ?? "");
    return div.innerHTML;
}

function csvEscape(value) {
    let text = String(value ?? "");
    if (/^[\\s]*[=+@-]/.test(text) || /^[\\t\\r\\n]/.test(text)) text = "'" + text;
    value = text;
    return '"' + String(value ?? "").replace(/"/g, '""') + '"';
}

function xmlEscape(value) {
    return String(value ?? "").replace(/[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]/g, "")
        .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

function xmlCell(value) {
    return `<Cell><Data ss:Type="String">${xmlEscape(value)}</Data></Cell>`;
}

function timestamp() {
    return new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");
}

function downloadBlob(content, filename, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
}

// SpreadsheetML 2003 opens straight into Excel and needs no JS library, so
// the dashboard stays a single self-contained file.
function downloadWorkbook(sheetName, header, rows, filenamePrefix) {
    const body = rows.map(row => `<Row>${row.map(xmlCell).join("")}</Row>`).join("");
    const xml = `<?xml version="1.0"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
<Worksheet ss:Name="${xmlEscape(sheetName)}">
<Table>
<Row>${header.map(xmlCell).join("")}</Row>
${body}
</Table>
</Worksheet>
</Workbook>`;
    downloadBlob(xml, filenamePrefix + timestamp() + ".xls", "application/vnd.ms-excel");
}

function toggleSection(sectionId) {
    const body = document.getElementById(sectionId + "-body");
    const icon = document.getElementById(sectionId + "-icon");
    if (!body) return;
    const heading = document.querySelector('[aria-controls="' + sectionId + '-body"]');
    if (heading) heading.setAttribute('aria-expanded', String(body.classList.contains('collapsed')));
    const collapsed = body.classList.toggle("collapsed");
    if (icon) icon.textContent = collapsed ? "\\u25B8 Expand" : "\\u25BE Collapse";
}

function renderPagination(containerId, page, totalPages, totalItems, startIndex, visibleCount, callbackName) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const from = totalItems ? startIndex + 1 : 0;
    const to = startIndex + visibleCount;

    const buttons = [
        `<button ${page <= 1 ? "disabled" : ""} onclick="${callbackName}(${page - 1})">Previous</button>`
    ];

    const maxButtons = 7;
    const last = Math.min(totalPages, Math.max(1, page - 3) + maxButtons - 1);
    const first = Math.max(1, last - maxButtons + 1);

    for (let p = first; p <= last; p++) {
        buttons.push(`<button class="${p === page ? "active" : ""}" onclick="${callbackName}(${p})">${p}</button>`);
    }

    buttons.push(`<button ${page >= totalPages ? "disabled" : ""} onclick="${callbackName}(${page + 1})">Next</button>`);

    container.innerHTML =
        `<div class="pagination-info">Showing ${from}-${to} of ${totalItems}</div>` +
        `<div class="pagination-buttons">${buttons.join("")}</div>`;
}

// --- Available Adobe Analytics segments ----------------------------------------

const segmentState = { filtered: SEGMENTS_DATA.slice(), page: 1, pageSize: 10 };

function renderSegmentPage() {
    const total = segmentState.filtered.length;
    const totalPages = Math.max(1, Math.ceil(total / segmentState.pageSize));
    if (segmentState.page > totalPages) segmentState.page = totalPages;

    const start = (segmentState.page - 1) * segmentState.pageSize;
    const pageItems = segmentState.filtered.slice(start, start + segmentState.pageSize);

    document.getElementById("segmentBody").innerHTML = total === 0
        ? '<tr><td colspan="6"><div class="empty">No segments match this search.</div></td></tr>'
        : pageItems.map((s, i) => `<tr>
            <td>${start + i + 1}</td>
            <td><b>${escapeHtmlJs(s.name)}</b><div class="muted">${escapeHtmlJs(s.id)}</div></td>
            <td>${escapeHtmlJs(s.scopeName)}<div class="muted">${escapeHtmlJs(s.scopeId)}</div></td>
            <td>${escapeHtmlJs(s.owner)}</td>
            <td>${escapeHtmlJs(s.approval)}</td>
            <td>${escapeHtmlJs(s.description || "-")}<div class="muted">${escapeHtmlJs(s.analysisStatus)}</div></td>
          </tr>`).join("");

    renderPagination("segmentPagination", segmentState.page, totalPages, total,
                     start, pageItems.length, "gotoSegmentPage");
}

function gotoSegmentPage(page) {
    segmentState.page = page;
    renderSegmentPage();
}

function filterSegments() {
    const search = (document.getElementById("segmentSearch").value || "").trim().toLowerCase();
    segmentState.filtered = SEGMENTS_DATA.filter(s => String(s.name || "").toLowerCase().includes(search));
    segmentState.page = 1;
    renderSegmentPage();
}

function clearSegmentSearch() {
    document.getElementById("segmentSearch").value = "";
    filterSegments();
}

function changeSegmentPageSize() {
    segmentState.pageSize = Number(document.getElementById("segmentPageSize").value) || 10;
    segmentState.page = 1;
    renderSegmentPage();
}

function downloadSegmentsExcel() {
    if (!segmentState.filtered.length) {
        alert("There is no segment data available to download.");
        return;
    }
    downloadWorkbook(
        "Available Segments",
        ["Segment Name", "Segment ID", REPORT_CONFIG.scopeLabel + " Name", REPORT_CONFIG.scopeLabel + " ID", "Owner", "Description", "Analysis status", "Approved Status"],
        segmentState.filtered.map(s => [s.name, s.id, s.scopeName, s.scopeId, s.owner, s.description, s.analysisStatus, s.approval]),
        REPORT_CONFIG.prefix + "_Available_Segments_"
    );
}

// --- Duplicate / near-duplicate comparison --------------------------

const comparisonState = { filtered: MATCHES_DATA.slice(), page: 1, pageSize: 10 };

function renderComparisonPage() {
    const total = comparisonState.filtered.length;
    const totalPages = Math.max(1, Math.ceil(total / comparisonState.pageSize));
    if (comparisonState.page > totalPages) comparisonState.page = totalPages;

    const start = (comparisonState.page - 1) * comparisonState.pageSize;
    const pageItems = comparisonState.filtered.slice(start, start + comparisonState.pageSize);

    document.getElementById("comparisonBody").innerHTML = total === 0
        ? '<tr><td colspan="8"><div class="empty">No duplicate or near-duplicate segments were identified.</div></td></tr>'
        : pageItems.map((m, i) => `<tr>
            <td>${start + i + 1}</td>
            <td><span class="badge ${m.type === "Exact duplicate" ? "exact" : "near"}">${escapeHtmlJs(m.type)}</span></td>
            <td><span class="score">${m.similarity.toFixed(1)}%</span></td>
            <td><b>${escapeHtmlJs(m.aName)}</b><div class="muted">${escapeHtmlJs(m.aId)}</div><div class="muted">${escapeHtmlJs(m.aScopeId)}</div></td>
            <td><b>${escapeHtmlJs(m.bName)}</b><div class="muted">${escapeHtmlJs(m.bId)}</div><div class="muted">${escapeHtmlJs(m.bScopeId)}</div></td>
            <td>
              <span class="usage-badge">A approval: ${escapeHtmlJs(m.aApproval)}</span><br>
              <span class="usage-badge">B approval: ${escapeHtmlJs(m.bApproval)}</span><br>
              <span class="usage-badge">A: <b>${m.aCount}</b> dashboard(s)</span><br>
              <span class="usage-badge">B: <b>${m.bCount}</b> dashboard(s)</span><br>
              <span class="usage-badge">A known shared: <b>${m.aShared}</b></span><br>
              <span class="usage-badge">B known shared: <b>${m.bShared}</b></span>
            </td>
            <td>
              <span class="${m.recClass}">${escapeHtmlJs(m.recText)}</span>
              <div class="usage-note">${escapeHtmlJs(m.recDetail)}</div>
            </td>
            <td>
              <b>Only in A:</b> ${escapeHtmlJs(m.onlyADisplay || "None")}
              <br><br>
              <b>Only in B:</b> ${escapeHtmlJs(m.onlyBDisplay || "None")}
            </td>
          </tr>`).join("");

    renderPagination("comparisonPagination", comparisonState.page, totalPages, total,
                     start, pageItems.length, "gotoComparisonPage");
}

function gotoComparisonPage(page) {
    comparisonState.page = page;
    renderComparisonPage();
}

function filterComparisonResults() {
    const search = (document.getElementById("comparisonSearch").value || "").trim().toLowerCase();
    comparisonState.filtered = MATCHES_DATA.filter(m =>
        String(m.aName || "").toLowerCase().includes(search) ||
        String(m.bName || "").toLowerCase().includes(search)
    );
    comparisonState.page = 1;
    renderComparisonPage();
}

function clearComparisonSearch() {
    document.getElementById("comparisonSearch").value = "";
    filterComparisonResults();
}

function changeComparisonPageSize() {
    comparisonState.pageSize = Number(document.getElementById("comparisonPageSize").value) || 10;
    comparisonState.page = 1;
    renderComparisonPage();
}

function comparisonRows(matches) {
    return matches.map(m => [
        m.type, m.similarity.toFixed(1), m.aName, m.aId, m.aScopeId, m.aCount, m.aShared,
        m.bName, m.bId, m.bScopeId, m.bCount, m.bShared, m.recText, m.recDetail, m.onlyA, m.onlyB, m.aApproval, m.bApproval,
    ]);
}

const COMPARISON_HEADER = [
    "Type", "Similarity (%)", "Segment A Name", "Segment A ID", "Segment A " + REPORT_CONFIG.scopeLabel + " ID",
    "Segment A Dashboard Count", "Segment A Known Shared Count",
    "Segment B Name", "Segment B ID", "Segment B " + REPORT_CONFIG.scopeLabel + " ID", "Segment B Dashboard Count",
    "Segment B Known Shared Count", "Cleanup Recommendation",
    "Recommendation Detail", "Only in A", "Only in B", "Segment A Approved Status", "Segment B Approved Status",
];

function downloadComparisonExcel(matches) {
    const rows = matches || MATCHES_DATA;
    if (!rows.length) {
        alert("There is no comparison data available to download.");
        return;
    }
    downloadWorkbook("Comparison Results", COMPARISON_HEADER, comparisonRows(rows),
                     REPORT_CONFIG.prefix + "_Segment_Comparison_");
}

function downloadFilteredComparisonExcel() {
    downloadComparisonExcel(comparisonState.filtered);
}

// --- Full segment list (includes the definition JSON, which the Excel
// --- export above deliberately leaves out to stay readable) ----------

function downloadSegmentsCsv() {
    const header = ["#", "Segment Name", "Segment ID", REPORT_CONFIG.scopeLabel + " Name", REPORT_CONFIG.scopeLabel + " ID", "Owner", "Description", "Definition (JSON)", "Analysis status", "Approved Status"]
        .map(csvEscape).join(",");

    const rows = SEGMENTS_DATA.map((s, i) =>
        [i + 1, s.name, s.id, s.scopeName, s.scopeId, s.owner, s.description, s.definition, s.analysisStatus, s.approval].map(csvEscape).join(",")
    );

    downloadBlob(header + "\\n" + rows.join("\\n") + "\\n",
                 REPORT_CONFIG.prefix + "_Segment_List_" + timestamp() + ".csv", "text/csv;charset=utf-8;");
}

renderSegmentPage();
renderComparisonPage();
"""


# 7. Self-contained grouped dashboard and browser exports.
def build_dashboard_html(
    segments,
    matches,
    usage_map,
    usage_loaded,
    threshold,
    segment_csv_filename,
    scope_label=None,
    tool="aa",
):
    provider = get_provider(tool)
    scope_label = scope_label or "All " + provider.scope_plural
    total_segments = len(segments)

    # Data embedded directly in the page so the downloads, search and
    # pagination all work purely in-browser, regardless of how many segments
    # there are or where the HTML file is opened from. This avoids the
    # file:// "download" attribute restriction that browsers apply to plain
    # links pointing at local files, and lets both big tables render a page
    # at a time instead of as one giant static table.
    segments_for_js = [
        {
            "name": s.get("name", "(No name)"),
            "id": s.get("id", "(No ID)"),
            "scopeName": get_scope_name(s),
            "scopeId": get_scope_id(s),
            "owner": get_owner_name(s),
            "description": s.get("description", "") or "",
            "definition": json.dumps(s.get("definition"), ensure_ascii=False),
            "analysisStatus": definition_issue(s) or "Assessed",
            "approval": approval_status(s),
        }
        for s in segments
    ]

    matches_for_js = []

    for match in matches:
        a, b = match["a"], match["b"]
        usage_a = get_segment_usage(usage_map, a)
        usage_b = get_segment_usage(usage_map, b)
        recommendation = get_deletion_recommendation(match, usage_map, usage_loaded)
        bucket = get_recommendation_bucket(recommendation["text"])

        only_a = match["diff"]["onlyA"]
        only_b = match["diff"]["onlyB"]

        matches_for_js.append(
            {
                "type": match["type"],
                "aApproval": approval_status(a),
                "bApproval": approval_status(b),
                "similarity": round(match["similarity"], 1),
                "aName": a.get("name", ""),
                "aId": a.get("id", ""),
                "aScopeId": get_scope_id(a),
                "aCount": usage_a["count"] if usage_loaded or usage_a["count"] else "Unknown",
                "aShared": usage_a["sharedPublishedCount"] or "Not verified",
                "bName": b.get("name", ""),
                "bId": b.get("id", ""),
                "bScopeId": get_scope_id(b),
                "bCount": usage_b["count"] if usage_loaded or usage_b["count"] else "Unknown",
                "bShared": usage_b["sharedPublishedCount"] or "Not verified",
                "recText": recommendation["text"],
                "recDetail": recommendation["detail"],
                "recClass": REC_CLASS_BY_BUCKET[bucket],
                "onlyA": ", ".join(only_a),
                "onlyB": ", ".join(only_b),
                "onlyADisplay": ", ".join(only_a[:DIFF_DISPLAY_LIMIT]),
                "onlyBDisplay": ", ".join(only_b[:DIFF_DISPLAY_LIMIT]),
                "bucket": bucket,
            }
        )

    # Scorecards show the count of DISTINCT segments involved in each
    # duplicate type, not the number of pairwise comparison rows - same as
    # countDistinctSegmentsInMatches() in the HTML tool. A segment that
    # appears in several duplicate pairs is only counted once, and a
    # segment can count toward both "exact" and "near" if it has both.
    exact_distinct_count = count_distinct_segments_in_matches(matches, "Exact duplicate")
    near_distinct_count = count_distinct_segments_in_matches(matches, "Near duplicate")
    unique_segment_count = count_unique_segments(segments, matches)
    unassessed_count = sum(bool(definition_issue(s)) for s in segments)

    # Duplicate "clusters" via connected components - same grouping logic
    # as the HTML tool: if A=B and B=C, A, B and C are shown as one group
    # instead of two separate pairwise rows.
    exact_groups = build_duplicate_groups(matches, "Exact duplicate")
    near_groups = build_duplicate_groups(matches, "Near duplicate")
    exact_group_rows_html = render_duplicate_group_rows(exact_groups, True, usage_map, usage_loaded)
    near_group_rows_html = render_duplicate_group_rows(near_groups, False, usage_map, usage_loaded)

    usage_status = (
        "Accessible projects checked (not organisation-wide proof of non-use)"
        if usage_loaded
        else "Could not be verified this run (recommendations default to Review)"
    )
    generated = datetime.now().strftime("%d %b %Y, %I:%M %p")

    def js_safe(data):
        # Prevent a literal "</script>" inside embedded JSON from closing
        # the surrounding <script> tag early.
        return json.dumps(data, ensure_ascii=False).replace("</", "<\\/")

    segments_json = js_safe(segments_for_js)
    matches_json = js_safe(matches_for_js)
    report_config_json = js_safe({"tool": tool, "title": provider.title, "scopeLabel": provider.scope_singular, "prefix": provider.prefix})

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{esc(provider.title)} Segment Cleanup Dashboard</title>
<style>{DASHBOARD_CSS}</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>{esc(provider.title)} Segment Cleanup Dashboard</h1>
    <div class="subtitle">Definition-based analysis with accessible Workspace references; deletion requires explicit server enablement</div>
    <div class="meta">
      Generated: {generated} &nbsp; | &nbsp; Scope: {esc(scope_label)} &nbsp; | &nbsp;
      Segments analyzed: {total_segments} &nbsp; | &nbsp;
      Similarity threshold: {threshold:g}% &nbsp; | &nbsp; Workspace usage: {usage_status}
    </div>
    <div class="toolbar">
      <a class="change-view" href="/?tool={provider.id}">&#8592; Change {esc(provider.scope_singular)}</a>
      <a class="change-view" href="/">Change Tool</a>
      <button onclick="downloadSegmentsCsv()">&#11015; Download Full Segment List (CSV)</button>
      <button class="secondary" onclick="downloadComparisonExcel()">&#11015; Download Comparison Results (Excel)</button>
    </div>
  </div>

  <div class="section highlight">
    <h2>{esc(provider.title)} Segment Summary</h2>
    <div class="cards">
      <div class="card"><div class="label">Total segments</div><div class="value">{total_segments}</div></div>
      <div class="card"><div class="label">Exact duplicates</div><div class="value exact-value">{exact_distinct_count}</div></div>
      <div class="card"><div class="label">Near duplicates</div><div class="value near-value">{near_distinct_count}</div></div>
      <div class="card"><div class="label">Unique segments (at this threshold)</div><div class="value unique-value">{unique_segment_count}</div></div>
    </div>

    <p class="note">Not assessed: <b>{unassessed_count}</b> (missing/unsupported definitions or scope). These are not counted as unique.
    Exact/near cards count distinct members and can overlap; pair counts are in the comparison table.
    Scopes are compared separately within the selected tool. Similarity is structural Jaccard, not audience overlap or proof of equivalent business intent.</p>
    <div class="duplicate-groups-section">
      <h3>Exact Duplicate Groups</h3>
      <div class="group-subtitle">
        Segments chained together through exact-duplicate matches are grouped into a single row
        (e.g. if A = B and B = C, then A, B and C appear together).
      </div>
      <div class="table-wrap">
        <table class="group-table">
          <thead>
            <tr>
              <th style="width:5%">#</th>
              <th style="width:25%">Segment Names</th>
              <th style="width:20%">{esc(provider.scope_singular)} Name</th>
              <th style="width:12%">Approved Status</th>
              <th style="width:13%">Workspace Usage</th>
              <th style="width:25%">Cleanup Recommendation</th>
            </tr>
          </thead>
          <tbody>{exact_group_rows_html}</tbody>
        </table>
      </div>

      <h3>Near-Duplicate Groups</h3>
      <div class="group-subtitle">
        Connected near-match pairs at the selected threshold. A ~ B and B ~ C does not guarantee A ~ C; review the pairwise table.
      </div>
      <div class="table-wrap">
        <table class="group-table">
          <thead>
            <tr>
              <th style="width:5%">#</th>
              <th style="width:25%">Segment Names</th>
              <th style="width:20%">{esc(provider.scope_singular)} Name</th>
              <th style="width:12%">Approved Status</th>
              <th style="width:13%">Workspace Usage</th>
              <th style="width:25%">Cleanup Recommendation</th>
            </tr>
          </thead>
          <tbody>{near_group_rows_html}</tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="section">
    <h2 class="card-header-row" role="button" tabindex="0" aria-expanded="false" aria-controls="segmentsCard-body" onkeydown="if(event.key==='Enter'||event.key===' '){{event.preventDefault();this.click();}}" onclick="toggleSection('segmentsCard')">
      <span>Available {esc(provider.title)} Segments</span>
      <span class="collapse-toggle" id="segmentsCard-icon">&#9656; Expand</span>
    </h2>
    <div class="collapsible-body collapsed" id="segmentsCard-body">
      <div class="table-toolbar">
        <div class="search-box">
          <input id="segmentSearch" type="text" placeholder="Search by segment name..." oninput="filterSegments()">
        </div>
        <div class="page-size-control">
          <label for="segmentPageSize">Rows per page</label>
          <select id="segmentPageSize" onchange="changeSegmentPageSize()">
            <option value="10" selected>10</option>
            <option value="20">20</option>
            <option value="30">30</option>
            <option value="40">40</option>
            <option value="50">50</option>
            <option value="100">100</option>
          </select>
        </div>
        <button class="btn grey" onclick="clearSegmentSearch()">Clear Search</button>
        <button class="btn green" onclick="downloadSegmentsExcel()">Download Excel</button>
      </div>
      <div class="table-wrap">
        <table class="fixed">
          <thead>
            <tr>
              <th style="width:5%">#</th>
              <th style="width:27%">Segment Name</th>
              <th style="width:18%">{esc(provider.scope_singular)} Name</th>
              <th style="width:14%">Owner</th>
              <th style="width:12%">Approved Status</th>
              <th style="width:24%">Description</th>
            </tr>
          </thead>
          <tbody id="segmentBody"></tbody>
        </table>
      </div>
      <div class="pagination" id="segmentPagination"></div>
    </div>
  </div>

  <div class="section">
    <h2 class="card-header-row" role="button" tabindex="0" aria-expanded="false" aria-controls="comparisonCard-body" onkeydown="if(event.key==='Enter'||event.key===' '){{event.preventDefault();this.click();}}" onclick="toggleSection('comparisonCard')">
      <span>Duplicate / Near-Duplicate Segments</span>
      <span class="collapse-toggle" id="comparisonCard-icon">&#9656; Expand</span>
    </h2>
    <div class="collapsible-body collapsed" id="comparisonCard-body">
      <div class="table-toolbar">
        <div class="search-box">
          <input id="comparisonSearch" type="text" placeholder="Search comparison results by segment name..." oninput="filterComparisonResults()">
        </div>
        <div class="page-size-control">
          <label for="comparisonPageSize">Rows per page</label>
          <select id="comparisonPageSize" onchange="changeComparisonPageSize()">
            <option value="10" selected>10</option>
            <option value="20">20</option>
            <option value="30">30</option>
            <option value="40">40</option>
            <option value="50">50</option>
            <option value="100">100</option>
          </select>
        </div>
        <button class="btn grey" onclick="clearComparisonSearch()">Clear Search</button>
        <button class="btn green" onclick="downloadFilteredComparisonExcel()">Download Excel</button>
      </div>
      <div class="table-wrap">
        <table class="fixed">
          <thead>
            <tr>
              <th style="width:5%">#</th>
              <th style="width:11%">Type</th>
              <th style="width:8%">Similarity</th>
              <th style="width:15%">Segment A</th>
              <th style="width:15%">Segment B</th>
              <th style="width:14%">Workspace Dashboard Usage</th>
              <th style="width:15%">Cleanup Recommendation</th>
              <th style="width:17%">Differences</th>
            </tr>
          </thead>
          <tbody id="comparisonBody"></tbody>
        </table>
      </div>
      <div class="pagination" id="comparisonPagination"></div>
    </div>
  </div>

  <div class="section">
    <h2>Reviewing the full segment library</h2>
    <p class="note">Report exports are read-only. The running app has a separate opt-in guarded deletion workflow. Workspace counts include only projects visible to the API account.
    Known shared counts show positive share evidence only; "Not verified" means share metadata was unavailable or no positive evidence was supplied.
    Zero accessible references does not mean globally unused. Approval, publishing and all other dependencies require owner verification.
    Excel downloads use Excel-compatible SpreadsheetML (.xls), not native .xlsx.</p>
    <p class="note">
      "Available {esc(provider.title)} Segments" above lists every segment pulled from {esc(provider.title)}, including ones with no
      duplicate match. Its Excel download covers the rows currently shown by the search filter.
      For a full offline review that also includes each segment's <b>definition JSON</b>, use the
      "Download Full Segment List (CSV)" button at the top of the page.
    </p>
  </div>
</div>

<script>
const REPORT_CONFIG = {report_config_json};
const SEGMENTS_DATA = {segments_json};
const MATCHES_DATA = {matches_json};
</script>
<script>{DASHBOARD_JS}</script>

</body>
</html>"""
    return augment_report(html, segments, usage_map, usage_loaded, get_scope_id, get_owner_name, definition_issue)


# 8. Optional read-only CLI, without a separate runner file.
def main():
    """Read-only CLI; the three-file web application is started with app.py."""
    import argparse
    import sys
    parser=argparse.ArgumentParser(description=get_provider(PROVIDER_ID).title+' segment analysis')
    parser.add_argument('--scope',default='ALL')
    parser.add_argument('--threshold',type=float,default=85)
    parser.add_argument('--output-dir')
    parser.add_argument('--json',action='store_true')
    args=parser.parse_args()
    try:
        result=run_pipeline(make_client(),tool=PROVIDER_ID,scope_selection=args.scope,
                            threshold=args.threshold,output_dir=args.output_dir)
        result.pop('dashboard_html',None)
        if not args.json:
            for key in ('segments','matches','usage_map'):result.pop(key,None)
        print(json.dumps(result,ensure_ascii=False,indent=2))
        return 0
    except (AdobeError,ValueError) as error:
        print(json.dumps({'error':str(error)}),file=sys.stderr)
        return 1


if __name__=='__main__':
    raise SystemExit(main())
