"""Segment Cleanup V5: exactly three application Python files."""
import argparse
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
from html import escape
from pathlib import Path
import hashlib
import json
import logging
import os
import secrets
import sys
import threading
import time
import webbrowser
from urllib.parse import urlencode
from flask import Flask, jsonify, render_template_string, request
import cja_segment_finder as cja
import aa_segment_finder as aa

FINDERS={'cja':cja,'aa':aa}
def get_provider(tool):
    if not isinstance(tool,str) or tool not in FINDERS:
        raise ValueError('Please choose CJA or Adobe Analytics.')
    return FINDERS[tool].get_provider(tool)

def make_client(tool):
    get_provider(tool)
    return FINDERS[tool].make_client(tool)

def run_pipeline(client, tool='aa', **options):
    get_provider(tool)
    return FINDERS[tool].run_pipeline(client, tool=tool, **options)

def normalize_segment(item,tool,names):
    get_provider(tool)
    return FINDERS[tool].normalize_segment(item,tool,names)

AdobeError=(cja.AdobeError,aa.AdobeError)
APP_DIR=Path(__file__).resolve().parent
HOST='127.0.0.1'
PORT=int(os.environ.get('SEGMENT_PORT','5005'))
CACHE_TTL_SECONDS=120
app=Flask(__name__)
app.config['MAX_CONTENT_LENGTH']=65536
logging.getLogger('werkzeug').setLevel(logging.WARNING)
_clients={}
_scope_cache={}
_cache_lock=threading.RLock()
_pipeline_locks={'cja':threading.Lock(),'aa':threading.Lock()}


from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import secrets
import threading
import time

MAX_BULK_DELETE = 200


class DeletionError(ValueError):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def fingerprint(segment):
    fields = {k: segment.get(k) for k in ('id', 'rsid', 'dataId', 'dataID', 'data_id', 'definition',
              'approved', 'tags', 'publishingStatus', 'modified', 'definitionLastModified', 'owner', 'usedIn', 'usageSummary', 'shares')}
    return hashlib.sha256(json.dumps(fields, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()


class DeletionWorkflow:
    def __init__(self, core, output_root):
        self.core, self.output_root = core, output_root
        self.reports, self.recent, self.pending = {}, {}, {}
        self.lock = threading.RLock()

    def scope(self, segment):
        return getattr(self.core, 'get_scope_id', getattr(self.core, 'get_report_suite_id', None))(segment)

    def identity(self, tool, client):
        return tool, client.cache_identity

    def register(self, tool, client, result, selection):
        with self.lock:
            now = time.monotonic()
            self.reports = {k:v for k,v in self.reports.items() if v['expires'] > now}
            # Bound server memory; old tabs then require a fresh report.
            while len(self.reports) >= 12:
                self.reports.pop(next(iter(self.reports)))
            token = secrets.token_urlsafe(32)
            self.reports[token] = {'tool':tool, 'client':client, 'identity':self.identity(tool, client),
                'segments':{str(s['id']):deepcopy(s) for s in result['segments']},
                'groups':[{str(s['id']) for s in g} for g in self.core.build_duplicate_groups(result['matches'], 'Exact duplicate')],
                'expires':now+1200, 'plans':{}, 'selection':selection, 'threshold':result['threshold']}
            return token

    def context(self, token, tool):
        report = self.reports.get(token)
        if not report or report['expires'] <= time.monotonic() or report['tool'] != tool:
            raise DeletionError('Report expired or does not match the tool. Generate a fresh report.', 409)
        if self.identity(tool, report['client']) != report['identity']:
            raise DeletionError('Server credentials changed. Generate a fresh report.', 409)
        return report

    def ids(self, payload, report):
        raw = payload.get('ids')
        if not isinstance(raw, list) or not raw or len(raw) > MAX_BULK_DELETE:
            raise DeletionError('Select between 1 and 200 segments per operation.')
        if any(not self.core.valid_segment_id(s) for s in raw):
            raise DeletionError('Invalid segment ID.')
        ids = list(dict.fromkeys(raw))
        if any(s not in report['segments'] for s in ids):
            raise DeletionError('A selected ID is not in this report.', 403)
        return ids

    def prepare_fresh(self, segment, tool):
        # Apply the same read-side aliases/JSON parsing used to build the report.
        # In V3 this also identifies legacy CJA definition/container structures.
        if hasattr(self.core, 'get_scope_id'):
            segment = self.core.normalize_segment(segment, tool, {})
        return self.core.prepare_segments([segment])[0]

    def recheck(self, report, ids):
        rows, fresh = {}, []
        client = report['client']
        for sid in ids:
            old = report['segments'][sid]
            row = rows[sid] = {'id':sid, 'name':str(old.get('name') or sid), 'eligible':False}
            try:
                item = client.get_segment(sid)
                if not isinstance(item, dict) or str(item.get('id') or '') != sid:
                    row['reason'] = 'Returned segment identity did not match.'
                    continue
                item = self.prepare_fresh(item, report['tool'])
                if self.scope(item) != self.scope(old):
                    row['reason'] = 'Segment scope changed or is unknown.'
                elif fingerprint(item) != fingerprint(old):
                    row['reason'] = 'Segment changed since this report. Generate a fresh report.'
                elif self.pending.get((*report['identity'], sid), 0) > time.monotonic():
                    row['reason'] = 'A prior deletion is pending or uncertain. Verify in Adobe before retrying.'
                else:
                    fresh.append(item)
            except Exception:
                row['reason'] = 'Could not re-read the segment. Nothing was deleted.'
        try:
            usage, loaded = self.core.load_workspace_usage(fresh, client) if fresh else ({}, False)
        except Exception:
            usage, loaded = {}, False
        for item in fresh:
            row = rows[str(item['id'])]
            reason = self.core.deletion_block_reason(item, usage, loaded, self.core.definition_issue(item))
            row.update(eligible=not reason, reason=reason or 'Fresh checks passed; owner and outside-dependency review still required.')
        eligible = {sid for sid,row in rows.items() if row['eligible']}
        # Do not remove every known copy of an exact definition in one operation.
        for group in report['groups']:
            if group and group <= eligible:
                keeper = sorted(group)[0]
                rows[keeper].update(eligible=False, reason='Retain at least one member of this exact group.')
                eligible.remove(keeper)
        return [rows[sid] for sid in ids]

    def preview(self, token, tool, payload):
        with self.lock:
            report = self.context(token, tool)
            ids = self.ids(payload, report)
            rows = self.recheck(report, ids)
            eligible = [r['id'] for r in rows if r['eligible']]
            nonce = secrets.token_urlsafe(24)
            now = time.monotonic()
            report['plans'] = {k:v for k,v in report['plans'].items() if v[0] > now}
            while len(report['plans']) >= 12:
                report['plans'].pop(next(iter(report['plans'])))
            report['plans'][nonce] = (now+300, eligible)
            return {'results':rows, 'ids':eligible, 'plan':nonce,
                    'enabled':bool(getattr(report['client'].config, 'deletion_enabled', False))}

    def record(self, tool, data):
        path = Path(self.output_root()) / 'output' / 'audit' / 'segment-deletions.jsonl'
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        fd = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
        with os.fdopen(fd, 'a') as stream:
            os.chmod(path, 0o600)
            stream.write(json.dumps({'time_utc':datetime.now(timezone.utc).isoformat(), 'tool':tool, **data})+'\n')
            stream.flush()
            os.fsync(stream.fileno())

    def execute(self, token, tool, payload):
        with self.lock:
            report = self.context(token, tool)
            if not getattr(report['client'].config, 'deletion_enabled', False):
                raise DeletionError('Live deletion is disabled on this server.', 403)
            if payload.get('confirmation') != 'DELETE' or payload.get('owner_review_confirmed') is not True:
                raise DeletionError('Type DELETE and confirm owner approval and outside-dependency review.')
            ids = self.ids(payload, report)
            if not isinstance(payload.get('plan'), str):
                raise DeletionError('A fresh preview plan is required.')
            plan = report['plans'].pop(payload.get('plan'), None)
            if not plan or plan[0] <= time.monotonic() or plan[1] != ids:
                raise DeletionError('Preview expired or selection changed. Run a fresh preview.', 409)
            rows = self.recheck(report, ids)
            batch = secrets.token_hex(12)
            # Refuse all writes if the initial durable audit cannot be saved.
            self.record(tool, {'batch':batch, 'phase':'preflight', 'results':rows})
            attempted = False
            try:
                for row in rows:
                    row.update(success=False, status='blocked', error=row['reason'])
                    if not row['eligible']:
                        continue
                    # Persist intent before each independent write. No automatic retry.
                    self.record(tool, {'batch':batch, 'phase':'intent', 'id':row['id']})
                    attempted = True
                    try:
                        outcome = report['client'].delete_segment(row['id'])
                        if not isinstance(outcome, dict) or outcome.get('status') not in ('deleted','pending','failed','unknown'):
                            outcome = {'status':'unknown','error':'Deletion outcome not recognised. Verify in Adobe.'}
                    except Exception:
                        outcome = {'status':'unknown','error':'Deletion could not be confirmed. Verify in Adobe before retrying.'}
                    row.update(status=outcome['status'], success=outcome['status']=='deleted', error=outcome.get('error'))
                    identity = (*report['identity'], row['id'])
                    if row['success']:
                        self.recent[identity] = time.monotonic()+600
                    elif row['status'] in ('pending','unknown'):
                        self.pending[identity] = time.monotonic()+600
                    self.record(tool, {'batch':batch, 'phase':'result', **row})
            finally:
                # Even a late disk/audit failure must invalidate old tabs and plans.
                if attempted:
                    self.reports = {k:v for k,v in self.reports.items() if v['identity'] != report['identity']}
            return {'success':all(r['success'] for r in rows), 'results':rows, 'refresh_required':attempted}

    def view_client(self, tool, client):
        manager = self
        class View:
            def __getattr__(self, name):
                return getattr(client, name)
            def get_segments(self, *args, **kwargs):
                records = client.get_segments(*args, **kwargs)
                now = time.monotonic()
                with manager.lock:
                    manager.recent = {k:v for k,v in manager.recent.items() if v > now}
                    hidden = {key[2] for key in manager.recent if key[:2] == manager.identity(tool,client)}
                return [s for s in records if str(s.get('id')) not in hidden]
        return View()



_cleanups={tool:DeletionWorkflow(finder,lambda:APP_DIR) for tool,finder in FINDERS.items()}

def deletion_request(preview):
    payload=request.get_json(silent=True)
    if not isinstance(payload,dict):return jsonify(error='A JSON object is required.'),400
    tool=payload.get('tool','')
    if not isinstance(tool,str) or tool not in FINDERS:return jsonify(error='Choose a valid tool.'),400
    if request.headers.get('Sec-Fetch-Site') not in (None,'same-origin','none'):
        return jsonify(error='Cross-site cleanup requests are not allowed.'),403
    try:
        with _pipeline_locks[tool]:
            manager=_cleanups[tool]
            fn=manager.preview if preview else manager.execute
            return jsonify(fn(request.headers.get('X-Cleanup-Token',''),tool,payload))
    except DeletionError as error:
        return jsonify(error=str(error)),error.status
    except Exception:
        return jsonify(error='Cleanup could not complete. Do not assume any deletion succeeded; verify in Adobe and refresh.'),500

@app.post('/api/segments/delete-preview')
def deletion_preview():return deletion_request(True)

@app.post('/api/segments/delete')
def deletion_execute():return deletion_request(False)


PAGE_STYLE = """
<style>
:root {
  --bg:#f4f7fb; --card:#fff; --text:#1d2939; --muted:#667085;
  --border:#d8e0ea; --accent:#4169f6; --accent-dark:#3158e6;
  --green:#2e7d32; --green-bg:#edf7ed; --red:#c62828; --red-bg:#fdecea;
}
* { box-sizing:border-box; }
body { margin:0; min-height:100vh; font-family:Arial,Helvetica,sans-serif; background:var(--bg); color:var(--text); }
.container { max-width:1400px; margin:0 auto; padding:70px 20px 44px; }
.panel { background:var(--card); padding:34px 20px; border-radius:8px; box-shadow:0 2px 9px rgba(0,0,0,.09); }
.panel h2 { margin:6px 0 20px; font-size:24px; }
.landing-shell { display:flex; justify-content:center; align-items:flex-start; min-height:100vh; padding:88px 24px 48px; }
.landing-card { width:100%; max-width:590px; padding:32px; border:1px solid #dde4ed; border-radius:12px; background:var(--card); box-shadow:0 4px 16px rgba(29,41,57,.08); }
.landing-card h1 { margin:0 0 5px; font-size:25px; line-height:1.25; font-weight:700; letter-spacing:-.2px; }
.landing-subtitle { margin:0 0 26px; color:var(--muted); font-size:14px; line-height:1.45; }
.field + .field { margin-top:18px; }
label { display:block; margin:0 0 7px; font-size:13px; line-height:1.3; font-weight:700; }
select, input { width:100%; height:42px; padding:9px 12px; border:1px solid var(--border); border-radius:7px; background:#fff; color:var(--text); font:14px Arial,Helvetica,sans-serif; }
select:focus, input:focus, button:focus-visible { outline:3px solid rgba(20,115,230,.22); outline-offset:1px; border-color:var(--accent); }
select:disabled { background:#f4f4f4; color:#999; }
.hint { margin-top:7px; color:var(--muted); font-size:12px; line-height:1.45; }
button { border:0; border-radius:7px; padding:11px 18px; font:600 14px Arial,Helvetica,sans-serif; cursor:pointer; }
button.primary { background:var(--accent); color:#fff; }
button.primary:hover:not(:disabled) { background:var(--accent-dark); }
button:disabled { opacity:.56; cursor:not-allowed; }
.generate-row { margin-top:23px; }
.generate-row .primary { width:100%; height:44px; }
.status { margin:0 0 18px; padding:0; font-size:13px; line-height:1.45; }
.status:empty { display:none; }
.status.error { padding:11px 13px; border-radius:5px; color:var(--red); background:var(--red-bg); }
.error-card { max-width:760px; margin:80px auto; }
a.back { display:inline-block; margin-top:18px; color:var(--accent); text-decoration:none; font-weight:600; }
</style>
"""

PICKER_STYLE = """<style>
.suite-picker { position:relative; width:100%; }
.suite-picker[hidden], .suite-picker [hidden] { display:none !important; }
.suite-picker .suite-trigger {
  display:flex; align-items:center; justify-content:space-between; gap:12px;
  width:100%; height:42px; padding:9px 12px; border:1px solid var(--border,#d8e0ea);
  border-radius:7px; background:#fff; color:var(--text,#1d2939);
  font:14px Arial,Helvetica,sans-serif; text-align:left; cursor:pointer;
}
.suite-picker .suite-trigger:disabled { opacity:1; background:#f4f4f4; color:#999; cursor:not-allowed; }
.suite-picker .suite-value { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.suite-picker .suite-arrow { flex:none; font-size:12px; color:#667085; }
.suite-picker .suite-popup {
  position:absolute; top:calc(100% + 5px); left:0; right:0; z-index:1000;
  border:1px solid #cbd5e1; border-radius:8px; background:#fff;
  box-shadow:0 8px 24px rgba(29,41,57,.16); overflow:hidden;
}
.suite-picker .suite-search-wrap { padding:10px; border-bottom:1px solid #e6ebf2; }
.suite-picker .suite-search { height:36px; font-size:13px; }
.suite-picker .suite-options {
  max-height:250px; overflow-y:auto; overflow-x:hidden; overscroll-behavior:contain;
  scrollbar-gutter:stable; padding:4px 0; scroll-behavior:auto;
}
.suite-picker .suite-option {
  padding:9px 12px; font:14px/1.35 Arial,Helvetica,sans-serif;
  color:#1d2939; overflow-wrap:anywhere; cursor:pointer;
}
.suite-picker .suite-option:hover, .suite-picker .suite-option.is-active { background:#edf2ff; }
.suite-picker .suite-option[aria-selected="true"] { color:#244dcb; font-weight:600; }
.suite-picker .suite-empty { padding:12px; color:#667085; font-size:13px; }
.suite-picker .suite-count { padding:7px 12px; border-top:1px solid #e6ebf2; color:#667085; font-size:11px; }
</style>"""

PICKER_SCRIPT = r"""<script>
// A bounded DOM list replaces the platform-native popup, not its form value.
class ReportSuitePicker {
  constructor(select) {
    this.select = select;
    this.originalRequired = select.required;
    this.enabled = false;
    this.activeIndex = -1;
    this.matches = [];
    this.label = select.labels && select.labels[0];
    if (this.label && !this.label.id) this.label.id = select.id + '-label';

    this.root = document.createElement('div');
    this.root.className = 'suite-picker';
    this.root.hidden = true;
    this.root.innerHTML = '<button type="button" class="suite-trigger" role="combobox" aria-haspopup="dialog" aria-expanded="false">' +
      '<span class="suite-value"></span><span class="suite-arrow" aria-hidden="true">▾</span></button>' +
      '<div class="suite-popup" role="dialog" aria-label="Choose a Report Suite" hidden>' +
      '<div class="suite-search-wrap"><input class="suite-search" type="search" autocomplete="off" spellcheck="false" aria-label="Search Report Suites" placeholder="Search by suite name or ID..."></div>' +
      '<div class="suite-options" role="listbox" aria-label="Report Suites"></div>' +
      '<div class="suite-count" role="status" aria-live="polite"></div></div>';
    select.insertAdjacentElement('afterend', this.root);
    this.button = this.root.querySelector('.suite-trigger');
    this.value = this.root.querySelector('.suite-value');
    this.popup = this.root.querySelector('.suite-popup');
    this.search = this.root.querySelector('.suite-search');
    this.list = this.root.querySelector('.suite-options');
    this.count = this.root.querySelector('.suite-count');
    this.popup.id = select.id + '-suite-popup';
    this.list.id = select.id + '-suite-options';
    this.button.setAttribute('aria-controls', this.popup.id);
    this.search.setAttribute('aria-controls', this.list.id);
    if (this.label) this.button.setAttribute('aria-labelledby', this.label.id);
    else this.button.setAttribute('aria-label', 'Report Suite');

    this.button.addEventListener('click', () => this.popup.hidden ? this.open() : this.close());
    this.button.addEventListener('keydown', event => this.keydown(event));
    this.search.addEventListener('keydown', event => this.keydown(event));
    this.search.addEventListener('input', () => this.renderOptions());
    this.list.addEventListener('click', event => {
      const option = event.target.closest('[data-suite-index]');
      if (option && this.list.contains(option)) this.choose(Number(option.dataset.suiteIndex));
    });
    // No blur/mouseleave/wheel dismissal: scrollbar clicks and wheel scrolling
    // inside this root must never close the menu or commit a different value.
    document.addEventListener('pointerdown', event => {
      if (!this.popup.hidden && !this.root.contains(event.target) && event.target !== this.label) this.close(false);
    });
    if (this.label) this.label.addEventListener('click', event => {
      if (this.enabled) { event.preventDefault(); this.button.focus(); }
    });
    select.addEventListener('change', () => this.updateValue());
    window.addEventListener('resize', () => { if (!this.popup.hidden) this.position(); });
  }

  setEnabled(enabled) {
    this.close(false);
    this.enabled = Boolean(enabled);
    this.root.hidden = !this.enabled;
    this.select.hidden = this.enabled;
    // Hidden required controls cannot receive native validation focus. Existing
    // form handlers validate the selected value; CJA restores native required.
    this.select.required = this.enabled ? false : this.originalRequired;
    this.button.setAttribute('aria-required', String(this.originalRequired));
    this.refresh();
  }

  updateValue() {
    const selected = this.select.options[this.select.selectedIndex];
    this.value.textContent = selected ? selected.textContent : 'Choose a Report Suite';
    this.button.title = this.value.textContent;
    this.button.disabled = this.select.disabled || !this.enabled;
  }

  refresh() {
    this.close(false);
    this.updateValue();
  }

  open() {
    if (!this.enabled || this.select.disabled) return;
    this.search.value = '';
    this.popup.hidden = false;
    this.button.setAttribute('aria-expanded', 'true');
    this.renderOptions();
    this.position();
    this.search.focus({preventScroll:true});
  }

  close(restoreFocus=true) {
    const wasOpen = !this.popup.hidden;
    this.popup.hidden = true;
    this.button.setAttribute('aria-expanded', 'false');
    this.search.removeAttribute('aria-activedescendant');
    if (wasOpen && restoreFocus && this.enabled && !this.select.disabled) this.button.focus({preventScroll:true});
  }

  position() {
    const rect = this.root.getBoundingClientRect();
    const below = window.innerHeight - rect.bottom - 12;
    const above = rect.top - 12;
    const up = below < 220 && above > below;
    this.popup.style.top = up ? 'auto' : 'calc(100% + 5px)';
    this.popup.style.bottom = up ? 'calc(100% + 5px)' : 'auto';
    this.list.style.maxHeight = Math.max(80, Math.min(250, (up ? above : below) - 90)) + 'px';
    this.ensureActiveVisible();
  }

  renderOptions() {
    const query = this.search.value.trim().toLocaleLowerCase();
    this.matches = Array.from(this.select.options).map((option, index) => ({option, index})).filter(item =>
      !item.option.disabled && item.option.value &&
      (!query || (item.option.textContent + ' ' + item.option.value).toLocaleLowerCase().includes(query)));
    const fragment = document.createDocumentFragment();
    for (const [index, item] of this.matches.entries()) {
      const row = document.createElement('div');
      row.className = 'suite-option';
      row.id = this.select.id + '-suite-option-' + item.index;
      row.dataset.suiteIndex = String(index);
      row.setAttribute('role', 'option');
      row.setAttribute('aria-selected', String(item.option.value === this.select.value));
      row.textContent = item.option.textContent;
      fragment.appendChild(row);
    }
    if (!this.matches.length) {
      const empty = document.createElement('div');
      empty.className = 'suite-empty';
      empty.textContent = 'No Report Suites match this search.';
      fragment.appendChild(empty);
    }
    this.list.replaceChildren(fragment);
    this.count.textContent = this.matches.length + (this.matches.length === 1 ? ' option' : ' options');
    const selectedIndex = this.matches.findIndex(item => item.option.value === this.select.value);
    this.setActive(selectedIndex >= 0 ? selectedIndex : this.matches.length ? 0 : -1);
  }

  setActive(index) {
    this.activeIndex = index;
    const rows = this.list.querySelectorAll('[role="option"]');
    rows.forEach((row, i) => row.classList.toggle('is-active', i === index));
    const active = rows[index];
    if (active) this.search.setAttribute('aria-activedescendant', active.id);
    else this.search.removeAttribute('aria-activedescendant');
    this.ensureActiveVisible();
  }

  ensureActiveVisible() {
    const active = this.list.querySelector('.is-active');
    if (!active || this.popup.hidden) return;
    const row = active.getBoundingClientRect(), list = this.list.getBoundingClientRect();
    if (row.top < list.top) this.list.scrollTop -= list.top - row.top;
    else if (row.bottom > list.bottom) this.list.scrollTop += row.bottom - list.bottom;
  }

  choose(index) {
    const item = this.matches[index];
    if (!item || this.select.disabled) return;
    this.select.value = item.option.value;
    this.select.dispatchEvent(new Event('change', {bubbles:true}));
    this.close();
  }

  keydown(event) {
    if (event.key === 'Escape' && !this.popup.hidden) { event.preventDefault(); this.close(); return; }
    if (event.key === 'Tab') { this.close(false); return; }
    if (event.target === this.search && this.search.value && ['Home','End'].includes(event.key)) return;
    if (['ArrowDown','ArrowUp','Home','End'].includes(event.key)) {
      event.preventDefault();
      if (this.popup.hidden) { this.open(); return; }
      const last = this.matches.length - 1;
      if (last < 0) return;
      this.setActive(event.key === 'Home' ? 0 : event.key === 'End' ? last :
        Math.max(0, Math.min(last, this.activeIndex + (event.key === 'ArrowDown' ? 1 : -1))));
    } else if (event.key === 'Enter' && !this.popup.hidden) {
      event.preventDefault(); this.choose(this.activeIndex);
    }
  }
}
window.ReportSuitePicker = ReportSuitePicker;
</script>"""


LANDING_HTML = r'''<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Segment Cleanup — CJA and Adobe Analytics</title>
{{ picker_style|safe }}
<style>
:root{--bg:#f5f7fb;--card:#fff;--text:#17243b;--muted:#63738b;--border:#dce4ef;--accent:#3e61ed;--accent-dark:#2f4ed0}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:15px/1.5 Arial,Helvetica,sans-serif;min-height:100vh}
[hidden]{display:none!important}button,input,select{font:inherit}button{cursor:pointer}button:disabled{cursor:not-allowed;opacity:.55}
:focus-visible{outline:3px solid #a9bcff;outline-offset:3px}a{color:var(--accent)}
.page-shell{max-width:1080px;margin:auto;padding:30px 32px 48px}.brandbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:44px}
.brand{display:flex;align-items:center;gap:11px;font-weight:700;font-size:17px;letter-spacing:-.25px}.brand-mark{width:34px;height:34px;display:grid;place-items:center;background:#233c81;color:#fff;border-radius:9px;font-size:12px;letter-spacing:.7px}
.workspace-label{color:var(--muted);font-size:12px}.hero{margin-bottom:28px}.eyebrow{color:#48609a;font-size:11px;letter-spacing:1.7px;text-transform:uppercase;font-weight:700;margin:0 0 10px}
h1{font-size:34px;line-height:1.2;letter-spacing:-1px;margin:0 0 12px}.intro{color:var(--muted);max-width:640px;margin:0;font-size:15px;line-height:1.65}
.workspace{background:var(--card);border:1px solid var(--border);border-radius:17px;box-shadow:0 9px 26px #1d345408;overflow:visible}
.product-tabs{display:grid;grid-template-columns:1fr 1fr;padding:9px;gap:8px;background:#edf1f8;border-bottom:1px solid var(--border);border-radius:17px 17px 0 0}
.product-tab{display:flex;align-items:center;gap:13px;border:1px solid transparent;border-radius:11px;padding:15px 20px;text-align:left;background:transparent;color:#5d6e87;min-height:75px}
.product-tab[aria-selected=true]{background:white;color:#213c80;border-color:#d7e1f2;box-shadow:0 2px 5px #1d34540b}.tab-icon{font-size:13px;font-weight:700;background:#e4eaf6;color:#49618a;width:37px;height:37px;border-radius:9px;display:grid;place-items:center;flex:none}
.product-tab[aria-selected=true] .tab-icon{background:#e9edff;color:#3554d5}.tab-label{font-size:15px;display:block;font-weight:700}.tab-description{font-size:11px;display:block;margin-top:3px;font-weight:400;color:#6b7a90}.selected-dot{margin-left:auto;width:7px;height:7px;background:#4265ed;border-radius:50%;opacity:0}.product-tab[aria-selected=true] .selected-dot{opacity:1}
.product-panel{padding:31px 34px 30px}.panel-heading{display:flex;align-items:flex-start;justify-content:space-between;gap:20px;margin-bottom:24px}.panel-heading h2{font-size:19px;letter-spacing:-.25px;margin:0 0 5px}.panel-heading p{font-size:13px;color:var(--muted);margin:0}.product-tag{font-size:10px;line-height:1.4;letter-spacing:.5px;text-transform:uppercase;color:#48609a;background:#f0f3fb;padding:7px 10px;border-radius:6px;white-space:nowrap}
.form-grid{display:grid;grid-template-columns:minmax(0,1fr) 238px;gap:25px;align-items:start}.field label{display:block;font-size:12px;font-weight:700;margin:0 0 9px}.field input,.field select{height:46px;width:100%;padding:10px 13px;border:1px solid #d5deeb;border-radius:8px;color:var(--text);background:white;font-size:14px}.field select:disabled{background:#f7f8fb;color:#8b97a9}.field .suite-trigger{height:46px;border-color:#d5deeb;border-radius:8px}.field .suite-search{width:100%;height:36px}.hint{font-size:11px;line-height:1.6;color:#728097;margin-top:8px;min-height:35px}
.threshold-wrap{position:relative}.threshold-wrap input{padding-right:35px}.percent{position:absolute;right:14px;top:11px;color:#77859a;font-size:14px;pointer-events:none}.status{font-size:12px;color:#65758e;margin:18px 0 0;min-height:18px;display:flex;align-items:center;gap:9px}.status.error{color:#a32c2c}.status[data-state=loading]:before{content:'';width:11px;height:11px;border:2px solid #dae2fa;border-top-color:#4265ed;border-radius:50%;animation:spin 1s linear infinite}.status[data-state=ready]:before{content:'';width:6px;height:6px;border-radius:50%;background:#2c8870}
.retry{background:white;border:1px solid #d5deeb;border-radius:6px;padding:6px 10px;color:#3d5486;font-size:11px;margin-top:9px}.action-row{display:flex;align-items:center;justify-content:space-between;gap:22px;border-top:1px solid #edf0f5;margin-top:23px;padding-top:23px}.report-hint{color:#6b7a90;font-size:11px;line-height:1.65;max-width:430px}.report-hint strong{color:#4a5e7a;font-weight:600}.generate{display:inline-flex;align-items:center;justify-content:center;gap:16px;background:var(--accent);border:0;border-radius:8px;color:white;min-width:210px;height:46px;padding:10px 20px;font-size:13px;font-weight:700;white-space:nowrap}.generate:hover:not(:disabled){background:var(--accent-dark)}.generate .arrow{font-size:19px;font-weight:400}
.steps{display:flex;justify-content:center;align-items:center;gap:24px;margin-top:26px;color:#708099;font-size:11px}.step{display:flex;align-items:center;gap:8px}.step-number{display:grid;place-items:center;background:#e9eef7;border:1px solid #dce4f1;color:#647697;border-radius:50%;width:21px;height:21px;font-size:10px}.step-separator{width:40px;height:1px;background:#d6deeb}.footer-note{text-align:center;color:#8290a4;font-size:10px;margin:28px 0 0}
@keyframes spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.status[data-state=loading]:before{animation:none}}
</style></head><body>
<main class="page-shell">
<header class="brandbar"><div class="brand"><span class="brand-mark" aria-hidden="true">SC</span>Segment Cleanup</div><span class="workspace-label">Segment analysis workspace</span></header>
<section class="hero"><p class="eyebrow">Less duplication. Clearer decisions.</p><h1>Find duplicate segment definitions.</h1><p class="intro">Choose your Adobe product, select the scope and review a grouped report.<br>One product at a time. The same simple workflow.</p></section>
<section class="workspace" aria-label="Configure segment analysis">
<div class="product-tabs" role="tablist" aria-label="Adobe product">
<button class="product-tab" type="button" id="tab-cja" role="tab" aria-label="CJA" aria-controls="panel-cja" aria-selected="{{ 'true' if initial_tool == 'cja' else 'false' }}" tabindex="{{ '0' if initial_tool == 'cja' else '-1' }}"><span class="tab-icon" aria-hidden="true">CJA</span><span><span class="tab-label">CJA</span><span class="tab-description">Customer Journey Analytics</span></span><span class="selected-dot" aria-hidden="true"></span></button>
<button class="product-tab" type="button" id="tab-aa" role="tab" aria-label="Adobe Analytics" aria-controls="panel-aa" aria-selected="{{ 'true' if initial_tool == 'aa' else 'false' }}" tabindex="{{ '0' if initial_tool == 'aa' else '-1' }}"><span class="tab-icon" aria-hidden="true">AA</span><span><span class="tab-label">Adobe Analytics</span><span class="tab-description">Report Suite analysis</span></span><span class="selected-dot" aria-hidden="true"></span></button>
</div>
{% for tool, label, plural, title in [('cja','Data View','Data Views','CJA'),('aa','Report Suite','Report Suites','Adobe Analytics')] %}
<section class="product-panel" id="panel-{{tool}}" role="tabpanel" aria-labelledby="tab-{{tool}}" {% if tool != initial_tool %}hidden{% endif %}>
<div class="panel-heading"><div><h2>{{title}} segment analysis</h2><p>Select a {{label|lower}} and choose how closely definitions should match.</p></div><span class="product-tag">{{plural}}</span></div>
<form class="analysis-form" id="form-{{tool}}" action="/generate" method="post">
<input type="hidden" name="tool" value="{{tool}}">
<div class="form-grid"><div class="field"><label id="scope-{{tool}}-label" for="scope-{{tool}}">{{label}}</label><select name="scope_selection" id="scope-{{tool}}" disabled required><option value="">Loading {{plural}}...</option></select><div class="hint" id="scope-hint-{{tool}}">Choose one {{label|lower}} or analyse all accessible {{plural|lower}}.</div></div>
<div class="field"><label for="threshold-{{tool}}">Similarity Threshold (%)</label><div class="threshold-wrap"><input type="number" id="threshold-{{tool}}" name="threshold" min="1" max="100" step="1" value="85" required aria-describedby="threshold-hint-{{tool}}"><span class="percent" aria-hidden="true">%</span></div><div class="hint" id="threshold-hint-{{tool}}">85% is a starting point for review.<br>Exact duplicates are also included.</div></div></div>
<div class="status" id="status-{{tool}}" role="status" aria-live="polite" data-state="loading">Loading accessible {{plural|lower}}...</div><button class="retry" id="retry-{{tool}}" type="button" hidden>Try again</button>
<div class="action-row"><div class="report-hint"><strong>Your report includes</strong><br>Exact and near-duplicate groups, unique segments, rule differences and Workspace references.</div><button class="generate" id="generate-{{tool}}" type="submit" disabled><span class="button-label">Generate Report</span><span class="arrow" aria-hidden="true">→</span></button></div>
</form></section>
{% endfor %}
</section>
<div class="steps" aria-label="Analysis steps"><span class="step"><span class="step-number">1</span>Choose scope</span><span class="step-separator" aria-hidden="true"></span><span class="step"><span class="step-number">2</span>Set similarity</span><span class="step-separator" aria-hidden="true"></span><span class="step"><span class="step-number">3</span>Review findings</span></div>
<p class="footer-note">Definition similarity supports review. It does not measure audience overlap.</p>
</main>
{{ picker_script|safe }}
<script>
const labels={cja:{singular:'Data View',plural:'Data Views'},aa:{singular:'Report Suite',plural:'Report Suites'}};
const states={cja:{loaded:false,loading:false,version:0},aa:{loaded:false,loading:false,version:0}};
const pickers={aa:new ReportSuitePicker(document.getElementById('scope-aa'))};pickers.aa.setEnabled(true);
let active={{initial_tool|tojson}};
const $=id=>document.getElementById(id);
function remember(tool){try{sessionStorage.setItem('segment-cleanup-v5-'+tool,JSON.stringify({scope:$('scope-'+tool).value,threshold:$('threshold-'+tool).value}));}catch(e){}}
function restore(tool){try{return JSON.parse(sessionStorage.getItem('segment-cleanup-v5-'+tool)||'null');}catch(e){return null;}}
function status(tool,text,state){const e=$('status-'+tool);e.textContent=text;e.className='status'+(state==='error'?' error':'');e.dataset.state=state;}
function ready(tool){$('generate-'+tool).disabled=!states[tool].loaded||states[tool].loading||!$('scope-'+tool).value;}
async function loadScopes(tool,force=false){
 const state=states[tool];if(state.loading||state.loaded&&!force)return;
 state.loading=true;state.loaded=false;const version=++state.version;
 const select=$('scope-'+tool),label=labels[tool],prior=select.value||restore(tool)?.scope;
 select.disabled=true;select.replaceChildren(new Option('Loading '+label.plural+'...',''));ready(tool);pickers[tool]?.refresh();$('retry-'+tool).hidden=true;
 status(tool,'Loading accessible '+label.plural.toLowerCase()+'...','loading');
 try{
  const response=await fetch('/api/scopes?tool='+tool,{headers:{Accept:'application/json'}}),payload=await response.json();
  if(version!==state.version)return;
  if(!response.ok)throw new Error(payload.error||'Unable to load '+label.plural+'.');
  if(payload.tool!==tool)throw new Error('The product list did not match. Please try again.');
  if(!Array.isArray(payload.scopes)||!payload.scopes.length)throw new Error('No accessible '+label.plural+' were returned.');
  select.replaceChildren(new Option('All '+label.plural,'ALL'));
  for(const item of payload.scopes)select.add(new Option(item.name||item.id,String(item.id)));
  select.value=Array.from(select.options).some(o=>o.value===prior)?prior:'ALL';select.disabled=false;state.loaded=true;
  $('scope-hint-'+tool).textContent='Choose one '+label.singular.toLowerCase()+' or all '+payload.scopes.length+' accessible '+label.plural.toLowerCase()+'.';
  status(tool,payload.scopes.length+' '+label.plural.toLowerCase()+' ready to analyse.','ready');
 }catch(error){if(version!==state.version)return;select.replaceChildren(new Option('Unable to load '+label.plural,''));status(tool,error.message,'error');$('retry-'+tool).hidden=false;}
 finally{if(version===state.version){state.loading=false;ready(tool);pickers[tool]?.refresh();}}
}
function activate(tool,focus=false){
 if(!labels[tool])return;active=tool;pickers.aa.close(false);
 for(const product of Object.keys(labels)){const selected=product===tool,tab=$('tab-'+product);tab.setAttribute('aria-selected',String(selected));tab.tabIndex=selected?0:-1;$('panel-'+product).hidden=!selected;}
 if(focus)$('tab-'+tool).focus();loadScopes(tool);
}
for(const tool of Object.keys(labels)){
 const saved=restore(tool);if(saved&&Number.isFinite(Number(saved.threshold))&&Number(saved.threshold)>=1&&Number(saved.threshold)<=100)$('threshold-'+tool).value=saved.threshold;
 $('tab-'+tool).addEventListener('click',()=>activate(tool));
 $('tab-'+tool).addEventListener('keydown',event=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){event.preventDefault();activate(event.key==='Home'?'cja':event.key==='End'?'aa':tool==='cja'?'aa':'cja',true);}});
 $('scope-'+tool).addEventListener('change',()=>{ready(tool);remember(tool);});$('threshold-'+tool).addEventListener('input',()=>remember(tool));
 $('retry-'+tool).addEventListener('click',()=>loadScopes(tool,true));
 $('form-'+tool).addEventListener('submit',event=>{
  if(active!==tool||!states[tool].loaded||states[tool].loading||!$('scope-'+tool).value){event.preventDefault();status(tool,'Wait for the '+labels[tool].plural.toLowerCase()+' to load.','error');return;}
  if(!$('form-'+tool).reportValidity()){event.preventDefault();return;}
  remember(tool);$('generate-'+tool).disabled=true;$('generate-'+tool).querySelector('.button-label').textContent='Generating report...';status(tool,'Fetching definitions and checking accessible Workspace references. This may take a little time.','loading');
 });
}
window.addEventListener('pageshow',event=>{if(event.persisted)for(const tool of Object.keys(labels)){$('generate-'+tool).querySelector('.button-label').textContent='Generate Report';ready(tool);}});
activate(active);
</script></body></html>'''


def get_client(tool):
    get_provider(tool)
    with _cache_lock:
        if tool not in _clients:
            _clients[tool] = make_client(tool)
        return _clients[tool]


def get_scopes_cached(tool, client):
    key = (tool, client.cache_identity)
    with _cache_lock:
        cached = _scope_cache.get(key)
        if cached and time.monotonic() - cached[0] < CACHE_TTL_SECONDS:
            return cached[1]
    scopes = client.get_scopes()
    with _cache_lock:
        _scope_cache[key] = (time.monotonic(), scopes)
    return scopes


@app.before_request
def restrict_local_requests():
    if request.host.split(":")[0] not in ("127.0.0.1", "localhost"):
        return "Local access only", 403
    origin = request.headers.get("Origin")
    if origin and origin != request.host_url.rstrip("/"):
        return "Cross-origin requests are not allowed", 403


@app.after_request
def privacy_headers(response):
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "same-origin"
    response.headers["X-Frame-Options"] = "DENY"
    return response


@app.get("/")
def index():
    tool = request.args.get("tool", "")
    tool = tool if tool in _pipeline_locks else "cja"
    return render_template_string(LANDING_HTML, style=PAGE_STYLE, initial_tool=tool,
                                  picker_style=PICKER_STYLE, picker_script=PICKER_SCRIPT)


@app.get("/api/scopes")
def api_scopes():
    try:
        tool = request.args.get("tool", "")
        provider = get_provider(tool)
        scopes = get_scopes_cached(tool, get_client(tool))
        names = Counter(str(s.get("name") or s["id"]) for s in scopes)
        clean = [{"id": str(s["id"]), "name": str(s.get("name") or s["id"]) +
                  (f' ({s["id"]})' if names[str(s.get("name") or s["id"])] > 1 else "")} for s in scopes]
        return jsonify({"tool": tool, "scopeLabel": provider.scope_singular, "scopes": clean, "count": len(clean)})
    except ValueError as error:
        return jsonify({"error": str(error)}), 400
    except AdobeError as error:
        return jsonify({"error": str(error)}), 502
    except Exception:
        return jsonify({"error": "Unable to load the selected tool's list. Check its server configuration."}), 502


@app.get("/favicon.ico")
def favicon():
    return "", 204


def render_report(values):
    tool = values.get("tool", "")
    try:
        provider = get_provider(tool)
        selection = (values.get("scope_selection") or "").strip()
        if not selection:
            raise ValueError(f"Please select a {provider.scope_singular} before generating the report.")
        threshold = FINDERS[tool].validate_threshold(values.get("threshold", "85"))
        client = get_client(tool)
        scopes = get_scopes_cached(tool, client)
        with _pipeline_locks[tool]:
            cleanup = _cleanups[tool]
            result = run_pipeline(cleanup.view_client(tool, client), tool=tool, threshold=threshold,
                                       output_dir=APP_DIR / "output" / "reports" / tool,
                                       scope_selection=selection, scopes=scopes)
            token = cleanup.register(tool, client, result, selection)
        refresh = '/dashboard?' + urlencode({'tool':tool, 'scope_selection':selection, 'threshold':threshold})
        return FINDERS[tool].bind_live(result["dashboard_html"], token, tool,
                         bool(getattr(getattr(client, 'config', None), 'deletion_enabled', False)), refresh)
    except ValueError as error:
        return error_page(str(error), tool=tool)
    except AdobeError as error:
        return error_page(str(error), tool=tool, status=502)
    except Exception:
        return error_page("The report could not be generated. No Adobe data was changed.", tool=tool, status=500)


@app.post("/generate")
def generate():
    return render_report(request.form)


@app.get("/dashboard")
def dashboard():
    # Refresh performs reads only; no deletion is possible through navigation.
    return render_report(request.args)


def error_page(message, tool="", status=400):
    target = "/?tool=" + tool if tool in _pipeline_locks else "/"
    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<title>Segment Cleanup — Error</title>{PAGE_STYLE}</head><body>
<main class="container error-card"><section class="panel"><h1>Could not generate the report</h1>
<div class="status error">{escape(str(message))}</div>
<a class="back" href="{target}">&larr; Back to Segment Cleanup</a></section></main></body></html>""", status



def main():
    """Optional unified read-only CLI, retained without a fourth application file."""
    parser=argparse.ArgumentParser(description='CJA + Adobe Analytics segment analysis')
    parser.add_argument('--tool',choices=('cja','aa'),required=True)
    parser.add_argument('--scope',default='ALL')
    parser.add_argument('--threshold',type=float,default=85)
    parser.add_argument('--output-dir')
    parser.add_argument('--json',action='store_true')
    args=parser.parse_args()
    try:
        result=run_pipeline(make_client(args.tool),tool=args.tool,
            scope_selection=args.scope,threshold=args.threshold,output_dir=args.output_dir)
        result.pop('dashboard_html',None)
        if not args.json:
            for key in ('segments','matches','usage_map'):result.pop(key,None)
        print(json.dumps(result,ensure_ascii=False,indent=2))
        return 0
    except (*AdobeError,ValueError) as error:
        print(json.dumps({'error':str(error)}),file=sys.stderr)
        return 1

if __name__=='__main__':
    if len(sys.argv)>1:
        raise SystemExit(main())
    print(f'Segment Cleanup V5: http://{HOST}:{PORT}')
    if os.environ.get('SEGMENT_OPEN_BROWSER','1')=='1':
        threading.Timer(1,lambda:webbrowser.open(f'http://{HOST}:{PORT}')).start()
    app.run(host=HOST,port=PORT,debug=False,threaded=True)
