from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import app as web
from aa_segment_finder import AdobeError
from tests.fixtures import FixtureClient, CjaFixtureClient


class AppTests(unittest.TestCase):
    def setUp(self):
        self.http = web.app.test_client()
        web._clients.clear(); web._scope_cache.clear()
        self.clients = {"aa": FixtureClient(), "cja": CjaFixtureClient()}
        self.config = patch("app.make_client", side_effect=lambda tool: self.clients[tool])
        self.make = self.config.start()
        self.directory = tempfile.TemporaryDirectory()
        self.path = patch("app.APP_DIR", Path(self.directory.name)); self.path.start()

    def tearDown(self):
        self.config.stop(); self.path.stop(); self.directory.cleanup()

    def get(self, path):
        return self.http.get(path, base_url="http://127.0.0.1")

    def post(self, **data):
        return self.http.post("/generate", data=data, base_url="http://127.0.0.1")

    def test_initial_screen_only_tool_choice_no_adobe_request(self):
        response=self.get('/')
        self.assertEqual(response.status_code,200)
        html=response.get_data(as_text=True)
        self.assertEqual(html.count('role="tab"'),2)
        self.assertIn('role="tablist"',html)
        self.assertNotIn('id="toolSelect"',html)
        self.assertIn('let active="cja"',html)
        self.assertNotIn('Show Data Views',html)
        self.make.assert_not_called()

    def test_provider_specific_lists_and_independent_cache(self):
        cja = self.get("/api/scopes?tool=cja").json
        aa = self.get("/api/scopes?tool=aa").json
        again = self.get("/api/scopes?tool=cja").json
        self.assertEqual(cja["scopeLabel"], "Data View")
        self.assertEqual(aa["scopeLabel"], "Report Suite")
        self.assertEqual(cja, again)
        self.assertEqual(self.make.call_count, 2)
        self.assertNotEqual(cja["scopes"][0]["id"], aa["scopes"][0]["id"])
        self.assertEqual(set(cja["scopes"][0]), {"id", "name"})

    def test_custom_picker_only_enabled_for_analytics(self):
        html=self.get('/?tool=aa').get_data(as_text=True)
        self.assertIn('id="scope-aa"',html)
        self.assertIn('id="scope-cja"',html)
        self.assertIn("pickers.aa.setEnabled(true)",html)
        self.assertIn('class ReportSuitePicker',html)
        self.assertIn('let active="aa"',html)

    def test_cache_separation_even_when_client_fingerprints_collide(self):
        self.clients["aa"].cache_identity = "same-fingerprint"
        self.clients["cja"].cache_identity = "same-fingerprint"
        cja = self.get("/api/scopes?tool=cja").json
        aa = self.get("/api/scopes?tool=aa").json
        self.assertEqual(cja["scopes"][0]["id"], "dv_one")
        self.assertEqual(aa["scopes"][0]["id"], "demo_suite")

    def test_invalid_tool_never_loads_credentials(self):
        for tool in ("", "both", "<script>"):
            self.assertEqual(self.get("/api/scopes?tool=" + tool).status_code, 400)
            self.assertEqual(self.post(tool=tool, scope_selection="ALL").status_code, 400)
        self.make.assert_not_called()

    def test_required_selection_and_valid_threshold(self):
        self.assertEqual(self.post(tool="cja").status_code, 400)
        for value in ("nan", "inf", "0", "101", "bad"):
            self.assertEqual(self.post(tool="cja", scope_selection="ALL", threshold=value).status_code, 400)

    def test_foreign_scope_cannot_be_used_on_other_tool(self):
        self.assertEqual(self.post(tool="cja", scope_selection="demo_suite").status_code, 400)
        self.assertEqual(self.post(tool="aa", scope_selection="dv_one").status_code, 400)

    def test_reports_and_outputs_separate_for_each_tool(self):
        for tool, heading, link in [("cja", "CJA Segment Cleanup Dashboard", "Change Data View"), ("aa", "Adobe Analytics Segment Cleanup Dashboard", "Change Report Suite")]:
            response = self.post(tool=tool, scope_selection="ALL", threshold="85")
            self.assertEqual(response.status_code, 200)
            html = response.get_data(as_text=True)
            self.assertIn(heading, html)
            self.assertIn(link, html)
            self.assertIn('href="/?tool=' + tool + '"', html)
            self.assertIn('href="/">Change Tool', html)
            self.assertIn("Unique segments", html)
        root = Path(self.directory.name) / "output" / "reports"
        self.assertTrue((root / "cja" / "CJA_Segment_List.csv").is_file())
        self.assertTrue((root / "aa" / "AA_Segment_List.csv").is_file())

    def test_empty_scope_renders_successfully_both_tools(self):
        for tool, scope in [("cja", "dv_empty"), ("aa", "empty_suite")]:
            response = self.post(tool=tool, scope_selection=scope)
            self.assertEqual(response.status_code, 200)
            self.assertIn("No exact-duplicate groups found", response.get_data(as_text=True))

    def test_provider_failure_does_not_disable_other_tool(self):
        with patch("app.make_client", side_effect=lambda tool: (_ for _ in ()).throw(AdobeError("No CJA permission")) if tool == "cja" else self.clients["aa"]):
            self.assertEqual(self.get("/api/scopes?tool=cja").status_code, 502)
            self.assertEqual(self.get("/api/scopes?tool=aa").status_code, 200)

    def test_unexpected_errors_do_not_leak_secret(self):
        with patch("app.make_client", side_effect=RuntimeError("private-secret")):
            response = self.get("/api/scopes?tool=aa")
        self.assertEqual(response.status_code, 502)
        self.assertNotIn("private-secret", response.get_data(as_text=True))

    def test_duplicate_labels_and_return_preselection(self):
        with patch.object(self.clients["cja"], "get_scopes", return_value=[{"id": "one", "name": "Same"}, {"id": "two", "name": "Same"}]):
            self.assertEqual([s["name"] for s in self.get("/api/scopes?tool=cja").json["scopes"]], ["Same (one)", "Same (two)"])
        html = self.get("/?tool=cja").get_data(as_text=True)
        self.assertIn('let active="cja"', html)

    def test_security_headers_host_origin_favicon_and_no_delete_route(self):
        response = self.get("/")
        self.assertEqual(response.headers["Cache-Control"], "no-store")
        self.assertEqual(response.headers["Referrer-Policy"], "same-origin")
        self.assertEqual(self.get("/favicon.ico").status_code, 204)
        self.assertEqual(self.http.get("/", base_url="http://evil.example").status_code, 403)
        self.assertEqual(self.http.post("/generate", base_url="http://127.0.0.1", headers={"Origin": "https://evil.example"}).status_code, 403)
        self.assertEqual(self.http.delete("/segments/a", base_url="http://127.0.0.1").status_code, 404)


if __name__ == "__main__": unittest.main()
