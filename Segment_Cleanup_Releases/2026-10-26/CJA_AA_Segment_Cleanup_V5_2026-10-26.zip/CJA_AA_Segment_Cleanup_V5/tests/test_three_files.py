"""Three-file boundaries, per-product isolation and fresh-folder execution."""
import ast
from copy import deepcopy
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import app
import cja_segment_finder as cja
import aa_segment_finder as aa
from tests.fixtures import segment
from tests.test_deletion import FakeClient

class ThreeFileTests(unittest.TestCase):
    def test_exactly_three_application_python_files(self):
        self.assertEqual(sorted(p.name for p in Path(app.__file__).parent.glob('*.py')),['aa_segment_finder.py','app.py','cja_segment_finder.py'])

    def test_find_modules_do_not_import_other_local_code(self):
        for module in (cja,aa):
            tree=ast.parse(Path(module.__file__).read_text())
            for n in ast.walk(tree):
                if isinstance(n,ast.ImportFrom):
                    self.assertIn(n.module,('urllib.parse','dataclasses','pathlib','dotenv','collections','html','itertools','datetime'))
                if isinstance(n,ast.Import):
                    for name in n.names:self.assertIn(name.name,('re','requests','hashlib','json','math','os','tempfile','threading','time','csv','argparse','sys'))
                if isinstance(n,ast.Call) and isinstance(n.func,ast.Name):self.assertNotIn(n.func.id,('exec','eval','__import__'))

    def test_v4_v5_finder_files_are_identical(self):
        # Package-local frozen parity fixture; the other version is not required.
        import hashlib
        expected={'aa_segment_finder.py': '8073da4330e604fdf7d378bcefc931cedd9b148b1285e347e1e5daf4df2e08c0', 'cja_segment_finder.py': 'c96a9d926ad92cf7d157b1eff1cdadbb9cef836c414903ccd5dce3ab4b1b94eb'}
        for name, expected_sha in expected.items():
            self.assertEqual(hashlib.sha256((Path(app.__file__).parent/name).read_bytes()).hexdigest(),expected_sha)

    def test_product_config_load_rejects_other_product(self):
        with self.assertRaises(cja.AdobeError):cja.Config.load('aa')
        with self.assertRaises(aa.AdobeError):aa.Config.load('cja')

    def test_product_client_rejects_other_product_credentials(self):
        with self.assertRaises(cja.AdobeError):cja.CjaClient(aa.Config(client_id='fake',access_token='fake',org_id='fake'))
        with self.assertRaises(aa.AdobeError):aa.AdobeAnalyticsClient(cja.Config(client_id='fake',access_token='fake',org_id='fake'))

    def test_aa_only_configuration_does_not_load_cja(self):
        with patch.dict(os.environ,{'AA_CLIENT_ID':'fixture','AA_ACCESS_TOKEN':'fake','AA_GLOBAL_COMPANY_ID':'fixture-company'},clear=True),patch('aa_segment_finder.dotenv_values',return_value={}),patch('cja_segment_finder.dotenv_values',return_value={}):
            self.assertEqual(aa.make_client().config.provider,'aa')
            with self.assertRaises(cja.AdobeError):cja.make_client()

    def test_cja_only_configuration_does_not_load_aa(self):
        with patch.dict(os.environ,{'CJA_CLIENT_ID':'fixture','CJA_ACCESS_TOKEN':'fake','CJA_ORG_ID':'fixture-org'},clear=True),patch('aa_segment_finder.dotenv_values',return_value={}),patch('cja_segment_finder.dotenv_values',return_value={}):
            self.assertEqual(cja.make_client().config.provider,'cja')
            with self.assertRaises(aa.AdobeError):aa.make_client()

    def test_per_product_deletion_enablement_and_default_deny(self):
        values={'CJA_CLIENT_ID':'fixture','CJA_ACCESS_TOKEN':'fake','CJA_ORG_ID':'fixture-org','AA_CLIENT_ID':'fixture','AA_ACCESS_TOKEN':'fake'}
        with patch.dict(os.environ,values,clear=True),patch('aa_segment_finder.dotenv_values',return_value={}),patch('cja_segment_finder.dotenv_values',return_value={}):
            self.assertFalse(cja.Config.load().deletion_enabled);self.assertFalse(aa.Config.load().deletion_enabled)
            os.environ['CJA_ENABLE_DELETION']='1'
            self.assertTrue(cja.Config.load().deletion_enabled);self.assertFalse(aa.Config.load().deletion_enabled)
            os.environ['CJA_ENABLE_DELETION']='true'
            self.assertFalse(cja.Config.load().deletion_enabled)

    def test_guarded_mock_deletion_for_each_product(self):
        for tool,module in (('cja',cja),('aa',aa)):
            with self.subTest(tool=tool),tempfile.TemporaryDirectory() as path:
                raw=segment('b',approved=False,publishingStatus={'published':False})
                prepared=module.prepare_segments([module.normalize_segment(raw,tool,{})])
                client=FakeClient([raw]);manager=app.DeletionWorkflow(module,lambda:Path(path))
                token=manager.register(tool,client,{'segments':prepared,'matches':[],'threshold':85},'demo_suite')
                plan=manager.preview(token,tool,{'ids':['b']})
                self.assertEqual(plan['ids'],['b']);self.assertEqual(client.deleted,[])
                client.records['b']['approved']=True
                outcome=manager.execute(token,tool,{'ids':plan['ids'],'plan':plan['plan'],'confirmation':'DELETE','owner_review_confirmed':True})
                self.assertEqual(outcome['results'][0]['status'],'blocked');self.assertEqual(client.deleted,[])

    def test_report_token_cannot_cross_product_managers(self):
        raw=segment('b',approved=False,publishingStatus={'published':False});fake=FakeClient([raw])
        with tempfile.TemporaryDirectory() as path:
            left=app.DeletionWorkflow(cja,lambda:Path(path));right=app.DeletionWorkflow(aa,lambda:Path(path))
            token=left.register('cja',fake,{'segments':[raw],'matches':[],'threshold':85},'demo_suite')
            with self.assertRaises(app.DeletionError):right.preview(token,'aa',{'ids':['b']})
            self.assertEqual(fake.deleted,[])

    def test_fresh_folder_with_only_three_files_serves_both_reports(self):
        code='''import sys,requests
def denied(*args,**kw):raise AssertionError('Network forbidden')
requests.sessions.Session.request=denied
import app
from types import SimpleNamespace
class Fake:
 cache_identity='fresh-three-file-fixture'
 config=SimpleNamespace(deletion_enabled=False)
 def get_scopes(self):return [{'id':'scope','name':'Synthetic'}]
 def get_projects(self):return []
 def get_segments(self,scope=None):return [{'id':'one','rsid':'scope','name':'Synthetic','definition':{'func':'segment','container':{'func':'container','context':'visits','pred':{'func':'streq','val':{'func':'attr','name':'variables/page'},'str':'home'}}}}]
app._clients={'cja':Fake(),'aa':Fake()}
http=app.app.test_client()
assert http.get('/',base_url='http://127.0.0.1').status_code==200
for tool in ('cja','aa'):
 assert http.get('/api/scopes?tool='+tool,base_url='http://127.0.0.1').status_code==200
 result=http.post('/generate',data={'tool':tool,'scope_selection':'ALL','threshold':'85'},base_url='http://127.0.0.1')
 assert result.status_code==200,(tool,result.status_code)
 assert 'Unique segments' in result.text and 'Segment Deletion' in result.text
 assert app.__file__.startswith(str(__import__('pathlib').Path.cwd()))
print('fresh-three-file PASS')'''
        with tempfile.TemporaryDirectory() as directory:
            for filename in ('app.py','cja_segment_finder.py','aa_segment_finder.py'):
                shutil.copy2(Path(app.__file__).parent/filename,Path(directory)/filename)
            env=dict(os.environ);env.pop('PYTHONPATH',None);env['PYTHONDONTWRITEBYTECODE']='1'
            result=subprocess.run([sys.executable,'-B','-c',code],cwd=directory,env=env,capture_output=True,text=True,timeout=30)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertIn('fresh-three-file PASS',result.stdout)

    def test_cli_help_available_from_all_three_entry_points(self):
        for filename in ('app.py','cja_segment_finder.py','aa_segment_finder.py'):
            result=subprocess.run([sys.executable,'-B',filename,'--help'],cwd=Path(app.__file__).parent,capture_output=True,text=True,timeout=10)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertIn('--scope',result.stdout)
