# Release verification

Verified on 26 October 2026.

- The three distributed application source files match the local verified version byte for byte. No app logic was changed for packaging.
- Fresh extraction passed 154 offline regression tests with unmocked external HTTP blocked. These cover both products, isolated configuration, API pagination, comparison, groups, unique counts, UI routes, reports, exports and mocked guarded deletion.
- A fresh-folder test inside the suite runs both product reports from only the three Python files. No older application directory is needed.
- Prior desktop browser checks passed search, paging, full and filtered export readback, scope changes, accessible empty scopes and Report Suite wheel/search selection. V5 additionally passed keyboard tab navigation, independent scope/threshold state, lazy loading and product failure recovery.
- The latest independent same-snapshot comparison found no pair-ID, type, score, token-difference or group mismatch between V3, V4 and V5 for CJA or Analytics. Real captures and private output reports are not distributed here.
- Live read adapters returned the expected inventories and selected scopes in the approved read-only check. No live Adobe DELETE or other resource write was performed.
- No secrets, populated .env, token caches or private generated exports are included. The blank example leaves live deletion disabled.

The included tests are synthetic. They do not certify audience equivalence, full organisational dependency visibility, all Adobe rule-language semantics, live deletion permissions, Windows, native Excel, mobile views or production hosting/load.
