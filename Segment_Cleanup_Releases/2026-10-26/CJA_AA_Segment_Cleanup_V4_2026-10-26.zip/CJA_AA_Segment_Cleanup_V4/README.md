# CJA and Adobe Analytics Segment Cleanup V4

Release 26 October 2026.

Product dropdown. Choose CJA or Adobe Analytics, then select the Data View or Report Suite and threshold.

## What is included

The `application` folder has exactly three Python source files:

- `app.py` starts the local Flask app and handles the UI, routes and guarded cleanup workflow.
- `cja_segment_finder.py` contains the CJA API client, comparison logic, groups, usage checks, reports and exports.
- `aa_segment_finder.py` contains the separate Adobe Analytics implementation.

All HTML, CSS and JavaScript are embedded in those files. No V2, V3, sibling app or hidden helper module is required. Tests and setup files are outside the application folder.

## Quick start on Linux or macOS

Extract the complete ZIP. Open a terminal in this package folder, where this README and requirements.txt are present. Python 3.10 or later is recommended; verification used Python 3.13.

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
cp .env.example application/.env
```

Edit `application/.env` with your authorised credentials. Configure only the product needed by the client. Leave both deletion flags at `0`. Then start:

```bash
.venv/bin/python application/app.py
```

Open http://127.0.0.1:5004. Keep the terminal running. The app binds to localhost only. `SEGMENT_OPEN_BROWSER=0` disables automatic browser opening; `SEGMENT_PORT` changes the port. This is a local desktop/demo tool, not a production hosting package.

Windows users can create the environment with `py -m venv .venv`, use `.venv\Scripts\python.exe` for the commands, and copy `.env.example` to `application\.env` using File Explorer. Windows execution is not certified by this release.

## Credentials

CJA uses `CJA_CLIENT_ID`, `CJA_CLIENT_SECRET`, `CJA_SCOPES` and `CJA_ORG_ID`. A supplied `CJA_ACCESS_TOKEN` is an alternative to automatic OAuth refresh. Analytics uses the corresponding `AA_` settings; `AA_GLOBAL_COMPANY_ID` can select the authorised company directly. Use the scopes assigned in Adobe Developer Console, not guessed scopes.

Credentials remain on the server. Keep the populated `.env`, private token caches, generated reports and audit files local. You may instead set process environment values or point `CJA_ENV_FILE`, `AA_ENV_FILE` or `SEGMENT_ENV_FILE` to your authorised configuration file. Do not commit or share real credentials.

## Read only CLI

```bash
.venv/bin/python application/cja_segment_finder.py --scope ALL --threshold 85 --json
.venv/bin/python application/aa_segment_finder.py --scope YOUR_RSID --threshold 85 --json
.venv/bin/python application/app.py --tool aa --scope YOUR_RSID --threshold 85 --json
```

These commands fetch private segment and Workspace information. Do not publish their output. The CLI is read-only; deletion is a separate opt-in browser workflow.

## Offline regression tests

On Linux or macOS, from this package folder:

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=application .venv/bin/python -B -m unittest discover -s tests -t . -v
```

The tests use synthetic data and mocked HTTP responses. No Adobe credentials are needed. This package passed all 154 tests after fresh extraction with unmocked external HTTP blocked. The cross-version finder parity test checks the recorded identical source hashes so it does not require the other ZIP to be installed.

## Safety and limits

Live deletion is disabled by default. No Adobe segment was deleted during verification. Do not enable deletion merely because a segment is listed as an exact or near match. Approval, publication, accessible Workspace usage, owner approval and dependencies outside those projects must be checked. Unknown metadata blocks guarded execution. Batches are not atomic, and live write permissions were not certified.

Similarity is structural Jaccard, not audience overlap. Data Views and report suites are compared separately; CJA is not compared with Analytics. Near groups are connected components, not a guarantee that every member matches every other member. Zero accessible project references is not proof of organisation-wide non-use.

Excel-compatible exports are SpreadsheetML `.xls`, not native `.xlsx`. No mobile, native Excel, Windows or production-load certification is claimed. See VERIFICATION.md for the tested coverage.

This archive excludes populated environment files, tokens, virtual environments, captured inventories, generated reports, audit logs, screenshots and private QA documents. `PACKAGE_MANIFEST.json` records every included file hash except its own.
