# CJA Segment Cleanup Delivery

This delivery contains the Python application and the latest updated presentation in separate folders.

## Folder structure

- `01_Python_App/` contains the Flask application, segment analysis logic, pinned Python requirements, launchers, and automated tests.
- `02_Updated_Presentation/` contains the latest Adobe-template presentation with the explained architecture slide.

## Run the Python application

1. Open a terminal in `01_Python_App`.
2. Create and activate a Python virtual environment.
3. Install the dependencies with `python -m pip install -r requirements.txt`.
4. The real `.env` is already included in this sensitive package. Replace it only if the Adobe CJA credentials change.
5. Run `python app.py`, or use `start_demo.bat` on Windows or `start_demo.sh` on Linux.

This ZIP contains live Adobe CJA credentials. Keep it private, do not commit it to source control, and share it only through an approved secure channel.

## Verification

The packaged Python source passed all 13 automated tests in an isolated environment using the pinned dependencies. The presentation passed slide rendering, overflow, font, package-integrity, and import checks.
