@echo off
title CJA Segment Cleanup
cd /d "%~dp0"
echo Starting CJA Segment Cleanup...
echo A browser tab will open automatically in a few seconds.
echo Keep this window open during the demo - closing it stops the app.
echo.
python app.py
pause
