# Design QA

## Scope

- Desktop web experience only, as requested. Mobile and responsive-breakpoint review were intentionally excluded.
- Reference: `cja-segment-finder-V5-Grouping Logic Update.html`.
- Implementation: Python/Flask application at `http://127.0.0.1:18766/` during verification.
- Reference evidence: `/tmp/cja-v5-live-review.J7ycPT/01-initial-screen.png` and `/tmp/cja-v5-live-review.J7ycPT/03-all-summary.png`.
- Live comparison viewport: the same connected Chrome desktop window was used for both the reference and implementation.

## Required surfaces reviewed

| Surface | Result |
| --- | --- |
| Initial finder screen | Matches the V5 hierarchy, typography, spacing, card treatment, controls, and color system. The former credentials notice and Show Data Views button have been removed. |
| Data View loading state | Data Views load automatically on page entry, with clear loading feedback, a live status region, and error handling. |
| Loaded Data View picker | Six live Data Views plus All Data Views displayed; All Data Views is selected by default and Generate Report is enabled. |
| Grouped report | Total, exact, near-duplicate, and unique-segment summary cards; duplicate groups; data-view names; and recommendation colors/layout match the V5 report structure. |
| Detailed tables | Expand/collapse, search, page-size control, pagination, clear search, and downloads verified. |
| Navigation | Change Data View returns to the first screen without exposing credentials. |

## Functional and data checks

- Live All Data Views run: 143 segments, 57 comparison pairs, 48 exact groups, and 3 near-duplicate groups.
- Live selected Data View run (`CJA - MCP Analysis - SD`): 127 segments and 43 comparison pairs.
- The final Python report and V5 export contain the same 57 pair IDs with zero mismatches across type, similarity, recommendation, Only in A, and Only in B.
- CSV export produced 143 data rows plus its header. Excel comparison export produced 57 data rows plus its header.
- Browser checks found no console-visible application failures.
- Live request trace contained only read-only Adobe calls: IMS token (when needed), Data Views, Segments, and Projects. No create, update, or delete calls were made.
- Latest targeted live run (`Segmentation Analysis`): 15 total segments, 6 exact-duplicate participants, 0 near-duplicate participants, and 9 unique segments.

## Iteration history

1. Replaced the eager segment-fetch form with a V5-style Show Data Views workflow.
2. Added the dedicated Data Views endpoint so empty accessible Data Views are included.
3. Scoped segment retrieval with `dataviewIds` and added the V5 client-side safety filter.
4. Matched the grouped report controls and added Change Data View navigation.
5. Fixed OAuth expiry-unit handling and private token-cache permissions.
6. Corrected six recommendation punctuation differences so the final semantic comparison is exact.
7. Restored automatic Data View loading, defaulted the picker to All Data Views, and removed the credentials warning and Show/Clear controls.
8. Added the Unique Segments scorecard, counting segments absent from all exact and threshold-qualified near-duplicate matches.

## Issue review

- P0: none.
- P1: none.
- P2: none.
- Intentional difference: Python keeps API credentials server-side instead of rendering credential fields in the browser.

## Final result

passed
